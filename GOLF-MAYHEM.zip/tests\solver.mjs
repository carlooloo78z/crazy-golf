import {predict} from '../src/physics.js';
import {CLUBS,terrainAt} from '../src/courses.js';

// Search real shot parameters; no teleportation or artificial cup completion.
export function solveShot(ball,hole,time=0,allowed=null){
 const distance=Math.hypot(hole.cup.x-ball.x,hole.cup.z-ball.z),baseAngle=Math.atan2(hole.cup.x-ball.x,hole.cup.z-ball.z);
 let best=null,bestCost=Infinity;
 function consider(club,power,angle,loft){const shot={club,power,angle,loft},p=predict(ball,hole,shot,time).ball;if(p.sunk){best=shot;bestCost=-100;return true;}const hazard=p.events.includes('hazard'),d=Math.hypot(hole.cup.x-p.x,hole.cup.z-p.z),terrain=terrainAt(hole,p.x,p.z,time+p.age);const cost=d+(hazard?200:0)+(terrain.type==='sand'?2:terrain.type==='rough'?.4:0);if(cost<bestCost){best=shot;bestCost=cost;}return false;}
 const clubs=allowed|| (distance<13?['putter','wedge']:distance<40?['iron','wedge','driver']:['driver','iron']);
 for(const club of clubs){const lofts=club==='putter'?[0]:club==='wedge'?[45,60,70]:club==='iron'?[25,40,55]:[16,30,45];for(const loft of lofts)for(let p=.06;p<=1.001;p+=.035)if(consider(club,p,baseAngle,loft))return best;}
 if(best){const initial={...best};for(let angle=-.06;angle<=.061;angle+=.015)for(let power=-.035;power<=.0351;power+=.0035)if(consider(initial.club,Math.max(.02,Math.min(1,initial.power+power)),initial.angle+angle,initial.loft))return best;}
 if(bestCost>distance*.6){for(const offset of [-.65,-.4,-.2,.2,.4,.65])for(const club of clubs)for(const power of [.35,.5,.65,.8,1])if(consider(club,power,baseAngle+offset,CLUBS[club].loft))return best;}
 return best;
}
