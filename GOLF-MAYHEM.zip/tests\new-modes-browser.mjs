import assert from 'node:assert/strict';
import {browser,sleep} from './cdp.mjs';
const b=await browser(),state=()=>b.evaluate('golfQA.state()');
try{
 await b.send('Page.addScriptToEvaluateOnNewDocument',{source:'sessionStorage.clear()'});await b.send('Emulation.setDeviceMetricsOverride',{width:1180,height:860,deviceScaleFactor:1,mobile:false});
 await b.send('Page.navigate',{url:'http://127.0.0.1:5173/?qa=1'});for(let i=0;i<100;i++){if(await b.evaluate('Boolean(window.golfQA)'))break;await sleep(150);}
 await b.evaluate('sessionStorage.clear()');assert.equal(await b.evaluate('document.querySelectorAll(".mode-card").length'),9);assert.equal(await b.evaluate('document.querySelectorAll(".online-card").length'),2);
 await b.click('[data-action="settings"]');await b.evaluate('document.querySelector("#setting-quality").value="low";document.querySelector("#setting-quality").dispatchEvent(new Event("input",{bubbles:true}))');await b.click('[data-action="close"]');
 await b.screenshot('new-modes-home');
 for(const mode of ['survival','shuffle','daily']){
  await b.click('[data-action="mode"][data-id="'+mode+'"]');await b.click('[data-action="start"]');
  let s=await state(),holes=s.round.indices.length;assert.equal(s.round.mode,mode);if(mode==='daily'){assert.equal(holes,6);assert.ok(s.round.dailyDay);}
  for(let h=0;h<holes;h++){
   if(mode==='shuffle'){assert.equal(s.round.allowedClubs.length,1);assert.equal(await b.evaluate('document.querySelectorAll(".club-button:disabled").length'),3);}
   for(let shot=0;shot<8;shot++){s=await state();if(s.ball.sunk||s.round.failure)break;await b.evaluate('(async()=>{const {solveShot}=await import("/tests/solver.mjs");const c=golfQA.candidates();golfQA.shoot(solveShot(c.ball,c.hole,c.time,c.allowed));golfQA.advance();})()');}
   s=await state();assert.ok(s.ball.sunk,mode+' hole '+h+' should finish');await b.evaluate('golfQA.next()');s=await state();
  }
  assert.equal(s.overlay,'round-result');assert.ok(s.round.earned>0);if(mode==='survival')assert.equal(s.round.lives,3);if(mode==='daily')assert.ok(s.progress.records['daily-'+s.round.dailyDay]);console.log('PASS '+mode+' full round, score and rewards');await b.click('[data-action="quit"]');
 }
 await b.evaluate('golfQA.start("survival","classic",0,undefined,{chaos:"chill"})');
 for(let h=0;h<3;h++){await b.evaluate('for(let i=0;i<8;i++){golfQA.shoot({club:"putter",power:.025,angle:0,loft:0});golfQA.advance()}');assert.equal((await state()).round.lives,2-h);await b.click('[data-action="next"]');}
 assert.equal((await state()).overlay,'round-result');assert.ok(await b.evaluate('document.querySelector(".modal").textContent.includes("OUT OF LIVES")'));console.log('PASS Survival ends after exactly three failed holes');
 await b.click('[data-action="quit"]');await b.click('[data-action="online"][data-id="duel"]');await sleep(2000);assert.equal((await state()).overlay,'online-queue');assert.ok(await b.evaluate('document.querySelector(".queue-view").textContent.includes("Waiting for another real player")'));await b.screenshot('online-queue');await b.click('[data-action="online-cancel"]');assert.equal((await state()).screen,'home');console.log('PASS Matchmaking waits for real players and Cancel works');
 await b.send('Emulation.setDeviceMetricsOverride',{width:390,height:844,deviceScaleFactor:1,mobile:true});await b.evaluate('document.querySelector(".online-lobby").scrollIntoView()');await b.screenshot('online-home-mobile');assert.ok(await b.evaluate('document.documentElement.scrollWidth<=innerWidth'));assert.deepEqual(b.errors,[]);console.log('PASS Mobile new modes and no browser errors');
}finally{await b.close();}
