export class GolfAudio {
  constructor(settings){this.settings=settings;this.ctx=null;this.next=0;this.note=0;}
  unlock(){try{this.ctx ||= new (window.AudioContext||window.webkitAudioContext)();if(this.ctx.state==='suspended')this.ctx.resume();}catch{}}
  tone(frequency,duration=.15,type='sine',volume=.2,delay=0){if(!this.ctx||!this.settings.sound)return;const t=this.ctx.currentTime+delay,o=this.ctx.createOscillator(),g=this.ctx.createGain();o.type=type;o.frequency.setValueAtTime(frequency,t);g.gain.setValueAtTime(0,t);g.gain.linearRampToValueAtTime(volume*this.settings.volume,t+.012);g.gain.exponentialRampToValueAtTime(.001,t+duration);o.connect(g);g.connect(this.ctx.destination);o.start(t);o.stop(t+duration+.02);}
  play(name){
    if(name==='bird'){[1100,1500,900,1650,1200].forEach((n,i)=>this.tone(n,.12,'sawtooth',.07,i*.16));}
    else if(name==='duck'){[320,250,320,240].forEach((n,i)=>this.tone(n,.13,'square',.07,i*.19));}
    else if(name==='crab'){[620,410,730,450].forEach((n,i)=>this.tone(n,.09,'triangle',.2,i*.13));}
    else if(name==='hit'){this.tone(190,.1,'triangle',.5);this.tone(650,.06,'sine',.2,.03);}
    else if(name==='cup'||name==='win'){[523,659,784,1047].forEach((n,i)=>this.tone(n,.35,'triangle',.35,i*.12));this.crowd();}
    else if(name==='hazard'){this.tone(200,.3,'sawtooth',.07);this.tone(120,.4,'triangle',.2,.12);}
    else if(name==='perfect'){this.tone(880,.15,'sine',.25);this.tone(1320,.25,'sine',.2,.1);}
    else if(name==='bounce'){this.tone(420,.16,'triangle',.2);}
    else this.tone(540,.065,'sine',.1);
  }
  crowd(){if(!this.ctx||!this.settings.sound)return;const size=this.ctx.sampleRate*.7,b=this.ctx.createBuffer(1,size,this.ctx.sampleRate),d=b.getChannelData(0);for(let i=0;i<size;i++)d[i]=(Math.random()-.5)*.08*Math.sin(Math.PI*i/size);const s=this.ctx.createBufferSource(),g=this.ctx.createGain(),filter=this.ctx.createBiquadFilter();s.buffer=b;filter.type='bandpass';filter.frequency.value=1000;g.gain.value=this.settings.volume;s.connect(filter);filter.connect(g);g.connect(this.ctx.destination);s.start();}
  update(){if(!this.ctx||!this.settings.music||!this.settings.sound)return;const t=this.ctx.currentTime;if(t>this.next){const notes=[261.63,329.63,392,329.63,293.66,349.23,440,349.23,220,261.63,329.63,392,196,246.94,293.66,392];this.tone(notes[this.note%16],.8,'sine',.055);if(this.note%4===0)this.tone(notes[this.note%16]/2,1.2,'triangle',.05);this.note++;this.next=t+.38;}}
}
