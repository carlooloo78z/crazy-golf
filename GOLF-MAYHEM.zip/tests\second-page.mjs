import {sleep} from './cdp.mjs';
export async function secondPage(browser){
 const {targetId}=await browser.send('Target.createTarget',{url:'about:blank'});const list=await(await fetch('http://127.0.0.1:9225/json')).json(),target=list.find(t=>t.id===targetId),ws=new WebSocket(target.webSocketDebuggerUrl);
 await new Promise(resolve=>ws.addEventListener('open',resolve,{once:true}));let id=0;const pending=new Map(),errors=[];
 ws.addEventListener('message',e=>{const d=JSON.parse(e.data);if(d.id){const p=pending.get(d.id);if(p){pending.delete(d.id);d.error?p.reject(d.error):p.resolve(d.result);}}if(d.method==='Runtime.exceptionThrown')errors.push(d.params.exceptionDetails.exception?.description||d.params.exceptionDetails.text);});
 const send=(method,params={})=>new Promise((resolve,reject)=>{const n=++id;pending.set(n,{resolve,reject});ws.send(JSON.stringify({id:n,method,params}));});
 const evaluate=async expression=>{const r=await send('Runtime.evaluate',{expression,returnByValue:true,awaitPromise:true,userGesture:true});if(r.exceptionDetails)throw Error(r.exceptionDetails.exception?.description||r.exceptionDetails.text);return r.result.value;};
 await send('Runtime.enable');await send('Page.enable');
 return {send,evaluate,errors,click:async selector=>{await evaluate(`document.querySelector(${JSON.stringify(selector)}).click()`);await sleep(100);},close:()=>ws.close()};
}
