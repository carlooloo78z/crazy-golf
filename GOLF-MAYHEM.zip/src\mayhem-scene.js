import * as THREE from '../vendor/three.module.min.js';

export function buildMayhem(view,hole){
 view.mayhemVisuals=[];
 const glow=(color,extra={})=>({emissive:color,emissiveIntensity:.5,roughness:.35,...extra});
 for(const b of hole.boosts){
  view.box(b.w,.08,b.d,0x192e37,b.x,.04,b.z);
  for(const side of [-1,1])view.box(.10,.06,b.d,0x52edec,b.x+side*(b.w/2-.1),.10,b.z);
  for(let i=0;i<3;i++){for(const side of [-1,1]){const stripe=view.box(.12,.04,.95,0xc6ff72,b.x+side*.31,.12,b.z-1.2+i*.9);stripe.rotation.y=side*.75;stripe.material.emissive.set(0x91ea52);stripe.material.emissiveIntensity=.7;}}
 }
 for(const b of hole.bumpers){
  view.add(new THREE.CylinderGeometry(b.r,b.r,.38,28),0x263b43,b.x,.19,b.z);
  view.add(new THREE.CylinderGeometry(b.r*.76,b.r*.85,b.h-.4,28),0xd95da8,b.x,(b.h+.3)/2,b.z,glow(0x842f79));
  const cap=view.add(new THREE.SphereGeometry(b.r,24,12,0,Math.PI*2,0,Math.PI/2),0xf6c554,b.x,b.h,b.z,glow(0x976319));cap.scale.y=.28;
  const ring=view.add(new THREE.TorusGeometry(b.r,.09,8,32),0x87fff2,b.x,.55,b.z,glow(0x26bdc5));ring.rotation.x=-Math.PI/2;view.mayhemVisuals.push({type:'bumper',object:ring,data:b});
 }
 for(const t of hole.tornadoes){
  const group=new THREE.Group();group.position.set(t.x,0,t.z);view.world.add(group);
  for(let i=0;i<12;i++){const radius=.35+i*.17,ring=view.mesh(new THREE.TorusGeometry(radius,.07+i*.012,6,32),0xc6b1fa,{transparent:true,opacity:.25+i*.025,emissive:0x8266b1,emissiveIntensity:.4});ring.rotation.x=Math.PI/2;ring.position.y=.4+i*.5;group.add(ring);}
  for(let i=0;i<12;i++){const stone=view.mesh(new THREE.IcosahedronGeometry(.13,0),i%2?0xbccf90:0xb6a4d2);group.add(stone);}
  view.mayhemVisuals.push({type:'tornado',object:group,data:t});
 }
 for(const z of hole.gravityZones){
  const dome=view.add(new THREE.SphereGeometry(z.r,24,14,0,Math.PI*2,0,Math.PI/2),0x72d7ff,z.x,.02,z.z,{transparent:true,opacity:.08,depthWrite:false,side:THREE.DoubleSide,emissive:0x4499c9,emissiveIntensity:.5});dome.castShadow=false;
  for(let i=0;i<3;i++){const ring=view.add(new THREE.TorusGeometry(z.r,.025,5,48),0x92dcff,z.x,.1,z.z,glow(0x3fa7d0));ring.rotation.x=Math.PI/2+i*.35;ring.rotation.z=i*Math.PI/3;ring.castShadow=false;view.mayhemVisuals.push({type:'moon',object:ring,data:z,phase:i});}
 }
 for(const ring of hole.coinRings){const mesh=view.add(new THREE.TorusGeometry(ring.r,.09,8,40),0xffdc71,ring.x,ring.y,ring.z,glow(0xc68b14));mesh.castShadow=false;view.mayhemVisuals.push({type:'coin',object:mesh,data:ring});}
 view.powerAura=view.mesh(new THREE.SphereGeometry(.30,16,12),0x81e6fa,{transparent:true,opacity:.22,depthWrite:false,emissive:0x48b7e0,emissiveIntensity:.7});view.world.add(view.powerAura);view.powerAura.visible=false;
}

export function animateMayhem(view,ball,time){
 for(const v of view.mayhemVisuals||[]){
  if(v.type==='coin'){v.object.visible=!(ball.collectedRings||[]).includes(v.data.id);v.object.rotation.y=Math.sin(time*.8)*.25;v.object.material.emissiveIntensity=.45+Math.sin(time*3)*.15;}
  if(v.type==='bumper'){v.object.position.y=.55+Math.sin(time*3+v.data.z)*.12;}
  if(v.type==='moon'){v.object.rotation.z=time*.2+v.phase*Math.PI/3;}
  if(v.type==='tornado'){for(let i=0;i<12;i++){const ring=v.object.children[i];ring.position.x=Math.sin(time*2+i*.4)*.25;ring.position.z=Math.cos(time*2+i*.4)*.25;ring.rotation.z=time*3+i;}for(let i=12;i<24;i++){const s=v.object.children[i],a=time*3+i;s.position.set(Math.cos(a)*(1+(i-12)*.1),.5+(i-12)*.45,Math.sin(a)*(1+(i-12)*.1));s.rotation.y=a;}}
 }
 if(view.powerAura){view.powerAura.visible=ball.moving&&!!ball.powerUp;view.powerAura.position.set(ball.x,ball.y,ball.z);view.powerAura.material.color.set(ball.powerUp==='rocket'?0xffa65d:ball.powerUp==='magnet'?0xf6a3e3:0x81e6fa);view.powerAura.scale.setScalar(1+Math.sin(time*10)*.08);}
 view.trailLine.material.color.set(ball.powerUp==='rocket'?0xffb565:ball.powerUp==='magnet'?0xf0a8f4:0xffffff);
}
