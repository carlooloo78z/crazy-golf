import {predict} from '../src/physics.js';
export function solveSecret(ball,hole,secret=hole.secrets[0],time=0){
 const angle=Math.atan2(secret.x-ball.x,secret.z-ball.z),clubs=secret.y<.6?{putter:[0],iron:[15,25,35],driver:[8,16]}:{iron:[25,35,45,55],wedge:[45,55,65],driver:[16,30]};
 for(const offset of [0,-.015,.015,-.035,.035,-.06,.06,-.1,.1])for(const [club,lofts] of Object.entries(clubs))for(const loft of lofts)for(let i=12;i<=100;i++){
  const shot={club,power:i/100,angle:angle+offset,loft,style:'straight',powerUp:null},result=predict(ball,hole,shot,time).ball;
  if(result.foundSecrets?.includes(secret.id))return shot;
 }
 throw Error('No secret shot found: '+secret.id+' / '+hole.index);
}
