import * as THREE from '../vendor/three.module.min.js';
import {seeded,terrainAt,roughHeightAt} from './courses.js';
import {grainTexture} from './natural.js';

export function buildSurroundings(view,hole){
  view.sceneryActors=[];view.sceneryCounts={animals:0,people:0,lakes:hole.sceneryLakes.length,islands:hole.sceneryIslands.length+hole.sceneryLakes.length,trees:0};
  const rng=seeded(hole.seed+612),sphere=new THREE.SphereGeometry(1,12,8),cylinder=new THREE.CylinderGeometry(1,1,1,8),box=new THREE.BoxGeometry(1,1,1),materials=new Map();
  const material=color=>{if(!materials.has(color))materials.set(color,new THREE.MeshStandardMaterial({color,roughness:.8}));return materials.get(color);};
  function part(root,geometry,color,x,y,z,sx,sy,sz){const m=new THREE.Mesh(geometry,material(color));m.position.set(x,y,z);m.scale.set(sx,sy,sz);m.castShadow=m.receiveShadow=true;root.add(m);return m;}
  function animal(type){
    const root=new THREE.Group(),legs=[],wings=[],head=new THREE.Group();root.add(head);
    if(type==='bird'){
      part(root,sphere,0xf0e9ce,0,0,0,.24,.13,.55);part(root,box,0xe6aa42,0,.03,.59,.1,.07,.2);
      for(const side of [-1,1]){const wing=new THREE.Group();wing.position.x=side*.15;root.add(wing);part(wing,box,0xd9e2df,side*.48,0,-.06,1,.035,.36).rotation.y=side*.28;wings.push(wing);}
    }else if(type==='duck'){
      part(root,sphere,0xf1e5be,0,.22,0,.4,.28,.62);part(head,sphere,0x357754,0,.63,.37,.25,.26,.24);part(head,box,0xf2ac34,0,.58,.65,.24,.08,.28);
      for(const side of [-1,1]){part(root,sphere,0xa6976b,side*.30,.30,-.08,.12,.16,.43);part(head,sphere,0x162621,side*.19,.7,.50,.035,.035,.035);}
    }else{
      const rabbit=type==='rabbit',color=rabbit?0xe2d8be:type==='fox'?0xc87943:0xab8960;
      part(root,sphere,color,0,.94,0,.38,.47,.8);head.position.set(0,1.35,.66);part(head,sphere,color,0,.16,.14,.29,.33,.38);part(head,sphere,rabbit?0xf1e7d1:0xc5a783,0,.02,.43,.22,.16,.22);part(head,sphere,0x282b28,0,.07,.63,.075,.055,.045);
      for(const side of [-1,1]){part(head,sphere,color,side*.2,rabbit?.72:.48,.08,.09,rabbit?.43:.22,.12).rotation.z=side*-.2;part(head,sphere,0x181c19,side*.24,.23,.35,.04,.04,.04);}
      if(type==='deer')for(const side of [-1,1]){part(head,cylinder,0xd6c5a1,side*.2,.75,-.04,.035,.65,.035).rotation.z=side*-.3;part(head,cylinder,0xd6c5a1,side*.30,.86,.07,.025,.35,.025).rotation.x=.7;}
      for(let i=0;i<4;i++){const leg=new THREE.Group();leg.position.set(i%2?.25:-.25,.83,i<2?-.48:.48);root.add(leg);part(leg,cylinder,color,0,-.34,0,.075,.7,.075);part(leg,box,0x4e4437,0,-.69,.04,.12,.12,.19);legs.push(leg);}
      const tail=part(root,sphere,rabbit?0xf8f0db:color,0,rabbit?.95:1,-.85,rabbit?.18:.19,rabbit?.18:.2,rabbit?.18:.6);if(type==='fox')tail.rotation.x=.35;
      if(rabbit)root.scale.setScalar(.48);if(type==='fox')root.scale.setScalar(.72);
    }
    return {root,legs,wings,head};
  }
  function person(color){
    const root=new THREE.Group(),arms=[],legs=[];
    part(root,sphere,color,0,1.23,0,.27,.38,.17);part(root,sphere,0xcda47e,0,1.77,0,.19,.23,.18);part(root,sphere,0xe9e3cf,0,1.94,0,.21,.09,.20);part(root,box,0xe9e3cf,0,1.92,.16,.35,.035,.24);
    for(const side of [-1,1]){
      const arm=new THREE.Group();arm.position.set(side*.27,1.48,0);root.add(arm);part(arm,cylinder,color,0,-.12,0,.085,.28,.085);part(arm,cylinder,0xcda47e,0,-.40,0,.06,.32,.06);part(arm,sphere,0xcda47e,0,-.59,0,.075,.09,.07);arms.push(arm);
      const leg=new THREE.Group();leg.position.set(side*.13,.93,0);root.add(leg);part(leg,cylinder,0x3c5360,0,-.39,0,.09,.78,.09);part(leg,sphere,0xe6e4d9,0,-.84,.07,.12,.07,.22);legs.push(leg);
    }
    return {root,arms,legs};
  }
  function spawnAnimal(type,x,z,options={}){const a={...animal(type),kind:'animal',type,x,z,phase:rng()*6,radius:options.radius??1.6,...options};a.root.position.set(x,options.y??terrainAt(hole,x,z).height,z);view.world.add(a.root);view.sceneryActors.push(a);view.sceneryCounts.animals++;return a;}
  function spawnPerson(x,z,options={}){const a={...person([0xeab16e,0x87b8a5,0xe3d7c2,0xaf8dbb,0x7497bd][Math.floor(rng()*5)]),kind:'person',x,z,phase:rng()*6,radius:options.radius??1.2,...options};a.root.position.set(x,options.y??terrainAt(hole,x,z).height,z);view.world.add(a.root);view.sceneryActors.push(a);view.sceneryCounts.people++;return a;}
  function islandTree(x,y,z,type='tree',scale=.75){const start=view.world.children.length;view.decorate(x,z,scale,type,rng);for(const child of view.world.children.slice(start))child.position.y+=y;view.sceneryCounts.trees++;}
  for(const lake of hole.sceneryLakes){
    const water=view.disc(lake.rx,lake.rz,hole.courseId==='neon'?0x49648d:0x377f87,lake.x,lake.level,lake.z,{roughness:.15,metalness:.4,envMapIntensity:1,bumpMap:grainTexture('water'),bumpScale:.055});water.name='scenery-lake';view.water.push(water);
    const island=lake.island;
    for(const side of [-1,1]){const x=island.x+side*1.1,z=island.z;islandTree(x,roughHeightAt(hole,x,z),z,hole.courseId==='tropical'?'palm':'tree',.65);}
    spawnAnimal('rabbit',island.x,island.z+1,{radius:.7});
    for(let i=0;i<3;i++)spawnAnimal('duck',lake.x,lake.z,{radius:lake.rx*.68,orbitZ:lake.rz*.68,y:lake.level,phase:i*2.1,swimming:true});
    for(let i=0;i<14;i++){const a=i*Math.PI*2/14,x=lake.x+Math.cos(a)*lake.rx*1.08,z=lake.z+Math.sin(a)*lake.rz*1.08,y=roughHeightAt(hole,x,z);const reed=view.add(new THREE.CylinderGeometry(.035,.045,1.0,5),0x69834c,x,y+.5,z);reed.rotation.z=Math.sin(a)*.1;view.add(new THREE.SphereGeometry(.09,6,5),0x705539,x,y+1,z).scale.y=2.4;}
  }
  for(const island of hole.sceneryIslands){
    const rock=view.add(new THREE.CylinderGeometry(1,.83,1,28),0x89908e,island.x,island.y-.56,island.z);rock.scale.set(island.rx,1,island.rz);
    const base=view.add(new THREE.ConeGeometry(1,7,11),0x77838b,island.x,island.y-4,island.z);base.rotation.x=Math.PI;base.scale.set(island.rx*.85,1,island.rz*.85);
    const land=view.disc(island.rx,island.rz,0x719457,island.x,island.y,island.z,{map:grainTexture(),roughness:1});land.name='scenery-island';view.groundMeshes.push(land);
    for(const side of [-1,1])islandTree(island.x+side*2.3,island.y,island.z+1.5,'tree',.8);
    spawnAnimal('rabbit',island.x-2,island.z-2,{y:island.y,radius:1});spawnPerson(island.x+1,island.z-2,{y:island.y,radius:1.2});
  }
  if(hole.courseId!=='sky'){
    for(let i=0;i<6;i++){const x=(i%2?1:-1)*(23+i*.7),z=5+(i/6)*hole.length;spawnAnimal(hole.courseId==='desert'?'fox':i%3===0?'rabbit':'deer',x,z,{radius:1.4});}
    for(let i=0;i<10;i++){const x=(i%2?1:-1)*23.5,z=4+(i/10)*hole.length;spawnPerson(x,z,{radius:i%3?1.2:0,walking:i%3!==0});}
    for(const side of [-1,1]){
      const x=side*25,z=hole.length*.72,y=terrainAt(hole,x,z).height;view.box(2.5,.12,.6,0xb5a077,x,y+.6,z);view.box(2.5,.65,.12,0xb5a077,x,y+1,z-.3);for(const dx of [-1,1])view.box(.12,.65,.6,0x4b5c59,x+dx*.9,y+.3,z);
      view.add(new THREE.CylinderGeometry(.055,.06,2.8,8),0xe4dcc1,x+2,y+1.4,z);const umbrella=view.add(new THREE.ConeGeometry(1.5,.6,12),side===1?0xe7b26c:0x91bbb2,x+2,y+2.8,z);umbrella.rotation.y=.2;
    }
  }
  for(let i=0;i<7;i++)spawnAnimal('bird',(i%2?1:-1)*(13+i*3),hole.length*.4+i*3,{y:12+i*.7,radius:7+i,flight:true});
  animateSurroundings(view,{sunk:false},0);
}

export function animateSurroundings(view,ball,time){
  const t=view.settings.reducedMotion?0:time;
  for(const a of view.sceneryActors||[]){
    const speed=a.flight?.18:a.swimming?.14:a.kind==='person'?.22:.16,angle=t*speed+a.phase;
    const x=a.x+Math.cos(angle)*a.radius,z=a.z+Math.sin(angle)*(a.orbitZ??a.radius);
    let y=a.y??terrainAt(view.hole,x,z).height;
    if(a.flight)y+=Math.sin(t*.8+a.phase)*1.5;
    if(a.type==='rabbit'&&!view.settings.reducedMotion)y+=Math.max(0,Math.sin(t*2.5+a.phase))*.15;
    if(a.swimming)y+=Math.sin(t*1.6+a.phase)*.04;
    a.root.position.set(x,y,z);a.root.rotation.y=-angle;
    for(let i=0;i<(a.legs?.length||0);i++)a.legs[i].rotation.x=view.settings.reducedMotion?0:Math.sin(t*3+a.phase+(i%2)*Math.PI)*(a.radius?.20:0);
    for(let i=0;i<(a.wings?.length||0);i++)a.wings[i].rotation.z=Math.sin(t*5+a.phase)*(i?1:-1)*.55;
    if(a.head&&!a.flight)a.head.rotation.x=Math.sin(t*.7+a.phase)*.12;
    for(let i=0;i<(a.arms?.length||0);i++){const cheering=ball.sunk||view.celebration>0;const wave=cheering||((Math.sin(t*.35+a.phase)>.65)&&i===0);a.arms[i].rotation.z=wave?(i?-1:1)*(2.4+Math.sin(t*4)*.3):Math.sin(t*2.5+a.phase+i)*.12;a.arms[i].rotation.x=view.failure?-.8:0;}
  }
}
