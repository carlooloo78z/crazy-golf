export const DEFAULT_STROKE_LIMIT=8;
export function strokeLimit(mode,challenge){return mode==='challenge'?challenge.limit:DEFAULT_STROKE_LIMIT;}
export function roughPenalty(ball,surface,returnedFromHazard=false){return !ball.moving&&!ball.sunk&&!returnedFromHazard&&surface.type==='rough'?1:0;}
export function limitReached(strokes,limit,sunk=false){return strokes>limit||(!sunk&&strokes>=limit);}
export function failedHoleScore(strokes,limit){return Math.max(strokes,limit+1);}
