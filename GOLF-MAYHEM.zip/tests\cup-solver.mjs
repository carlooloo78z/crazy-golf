import {predict} from '../src/physics.js';
export function solveAirCup(ball,hole,time=0){
 const angle=Math.atan2(hole.cup.x-ball.x,hole.cup.z-ball.z);
 for(const offset of [0,-.01,.01,-.02,.02])for(const club of ['iron','wedge'])for(const loft of (club==='iron'?[40,55,25]:[45,60,70]))for(let p=30;p<=100;p+=.25){
  const shot={club,power:p/100,angle:angle+offset,loft},result=predict(ball,hole,shot,time).ball;
  if(result.sunk&&result.airtime>1&&!result.events.some(e=>e.startsWith('bounce')||e.startsWith('secret:')))return shot;
 }
 throw Error('No direct airborne cup entry found');
}
