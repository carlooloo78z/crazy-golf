import {mkdir,writeFile} from 'node:fs/promises';
import {browser,sleep} from './cdp.mjs';
const b=await browser();
try{
 await mkdir('public/courses',{recursive:true});
 await b.send('Emulation.setDeviceMetricsOverride',{width:1000,height:740,deviceScaleFactor:1,mobile:false});
 await b.send('Page.navigate',{url:'http://127.0.0.1:5173/?qa=1'});
 for(let i=0;i<100;i++){if(await b.evaluate('Boolean(window.golfQA)'))break;await sleep(150);}
 await b.click('[data-action="settings"]');await b.evaluate('document.querySelector("#setting-quality").value="low";document.querySelector("#setting-quality").dispatchEvent(new Event("input",{bubbles:true}))');await b.click('[data-action="close"]');
 for(const course of ['classic','desert','tropical','sky','volcano','neon']){
  await b.evaluate(`document.querySelector('[data-action="course"][data-id="${course}"]').click();document.querySelector('.hero-scene-label').style.visibility='hidden';document.querySelector('.scene-badge').style.visibility='hidden';window.scrollTo(0,0)`);
  await sleep(1400);
  const clip=await b.evaluate('(()=>{const r=document.querySelector("#game").getBoundingClientRect();return {x:r.x,y:r.y,width:r.width,height:r.height,scale:1}})()');
  const screenshot=await b.send('Page.captureScreenshot',{format:'webp',quality:86,clip});
  await writeFile(`public/courses/${course}.webp`,Buffer.from(screenshot.data,'base64'));console.log('Saved course preview:',course);
 }
 if(b.errors.length)throw Error(b.errors.join('\n'));
}finally{await b.close();}
