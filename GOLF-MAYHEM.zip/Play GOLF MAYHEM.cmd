@echo off
node "%~dp0scripts\launch.mjs"
if errorlevel 1 (
  echo.
  echo The game could not start. See the error above.
  pause
)
