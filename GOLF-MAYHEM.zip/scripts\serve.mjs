import http from 'node:http';
import {readFile,writeFile,mkdir,rename} from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {MemoryArenaStore,freshArena} from '../server/arena.js';
import {arenaApi} from '../server/api.js';

const project=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
export async function createGameServer({root=project,persist=true,scope=process.env.PUBLIC_URL?'public':'local',clock=Date.now}={}){
 let state=freshArena();const stateFile=path.join(project,'.local','arena-state.json');
 if(persist){await mkdir(path.dirname(stateFile),{recursive:true});try{state=JSON.parse(await readFile(stateFile,'utf8'));}catch{}}
 const store=new MemoryArenaStore(state,persist?async data=>{await writeFile(stateFile+'.tmp',JSON.stringify(data));await rename(stateFile+'.tmp',stateFile);}:null),api=arenaApi(store,{scope,clock});
 const types={'.html':'text/html','.js':'text/javascript','.mjs':'text/javascript','.css':'text/css','.svg':'image/svg+xml','.webp':'image/webp','.png':'image/png','.json':'application/json','.txt':'text/plain'},rates=new Map();
 return http.createServer(async(req,res)=>{
  try{
   const origin=process.env.PUBLIC_URL||'http://'+req.headers.host,url=new URL(req.url,origin);
   if(url.pathname.startsWith('/api/arena/')){
    const ip=req.socket.remoteAddress,now=Date.now();let rate=rates.get(ip);if(!rate||now-rate.start>10000){rate={start:now,count:0};rates.set(ip,rate);}if(rates.size>2000)for(const [key,v] of rates)if(now-v.start>10000)rates.delete(key);
    if(++rate.count>150){res.writeHead(429,{'Content-Type':'application/json'});res.end(JSON.stringify({error:'Too many requests. Try again in a moment.'}));return;}
    let body='';for await(const part of req){body+=part;if(body.length>16384){res.writeHead(413);res.end();return;}}
    const response=await api(new Request(url,{method:req.method,headers:req.headers,...(!['GET','HEAD'].includes(req.method)?{body}:{})}));res.writeHead(response.status,Object.fromEntries(response.headers));res.end(await response.text());return;
   }
   if(!['GET','HEAD'].includes(req.method)){res.writeHead(405);res.end();return;}
   const relative=decodeURIComponent(url.pathname).replace(/^\/+/, '')||'index.html';
   // Private sessions, source-control files and credentials are never public assets.
   if(relative.split('/').some(p=>p==='..'||p.startsWith('.'))||relative.includes('\\')||!(/^(index\.html|favicon\.svg|src\/|vendor\/|courses\/)/.test(relative)||scope==='local'&&relative.startsWith('tests/'))){res.writeHead(404);res.end('Not found');return;}
   let data,target=path.resolve(root,relative);if(!target.startsWith(root+path.sep))throw Error('Invalid path');
   try{data=await readFile(target);}catch{target=path.resolve(root,'public',relative);data=await readFile(target);}
   res.writeHead(200,{'Content-Type':(types[path.extname(target)]||'application/octet-stream')+'; charset=utf-8','Cache-Control':'no-cache','X-Content-Type-Options':'nosniff','Referrer-Policy':'same-origin'});res.end(req.method==='HEAD'?undefined:data);
  }catch{res.writeHead(404);res.end('Not found');}
 });
}
if(process.argv[1]&&path.resolve(process.argv[1])===fileURLToPath(import.meta.url)){
 const server=await createGameServer({root:process.argv.includes('--dist')?path.join(project,'dist'):project});
 server.requestTimeout=15000;server.headersTimeout=10000;
 server.listen(Number(process.env.PORT)||5173,process.env.HOST||'127.0.0.1',()=>console.log('GOLF MAYHEM · http://'+(process.env.HOST||'127.0.0.1')+':'+server.address().port));
}
