import test from 'node:test';
import assert from 'node:assert/strict';
import {COURSES,makeHole,terrainAt,roughHeightAt,landscapePatches,landscapeHeightAt} from '../src/courses.js';
import {createBall,strike,stepBall,predict,STEP,RADIUS} from '../src/physics.js';
import {solveShot} from './solver.mjs';
import * as THREE from '../vendor/three.module.min.js';

const drive={club:'driver',power:.8,angle:Math.PI/2,loft:24};
function settle(ball,hole){for(let i=0;i<3600&&ball.moving;i++)stepBall(ball,hole,STEP,i*STEP);assert.equal(ball.moving,false);return ball;}

test('the visible dark grass on both sides, behind the tee, and past the cup is playable',()=>{
 for(const c of COURSES.filter(c=>c.id!=='sky')){const h=makeHole(c.id,6);for(const [x,z] of [[-19,2],[19,2],[-70,20],[100,30],[0,-30],[0,h.length+35],[-30,h.gaps[0].z],[149,h.length+104]])assert.equal(terrainAt(h,x,z).type,'rough',c.id+' grass at '+x+','+z);assert.equal(terrainAt(h,151,2).type,'bounds');}
});
test('wide drives stay on the grass without out-of-bounds resets and can be played back to the cup',()=>{
 for(const c of COURSES.filter(c=>c.id!=='sky')){const h=makeHole(c.id,0,{wind:0}),b=createBall();h.trees=[];strike(b,h,drive);settle(b,h);assert.ok(b.x>18);assert.equal(terrainAt(h,b.x,b.z).type,'rough');assert.equal(b.events.includes('hazard'),false);assert.ok(Math.abs(b.y-terrainAt(h,b.x,b.z).height-RADIUS)<.001);const previous=b.x;strike(b,h,{club:'iron',power:.6,angle:-Math.PI/2,loft:35});settle(b,h);assert.ok(b.x<previous-5);assert.equal(b.events.includes('hazard'),false);}
 const h=makeHole('classic',0,{wind:0}),b=createBall();strike(b,h,drive);settle(b,h);
 for(let i=0;i<6&&!b.sunk;i++){strike(b,h,solveShot(b,h));settle(b,h);}assert.ok(b.sunk,'a stray shot must still allow the player to finish the hole');
});
test('a rolling ball crosses the old boundary into rough and previews agree with real shots',()=>{
 const h=makeHole('classic',0,{wind:0}),b=createBall(17.5,2),shot={club:'putter',power:.8,angle:Math.PI/2,loft:0};
 const preview=predict(b,h,shot).ball;strike(b,h,shot);settle(b,h);assert.ok(b.x>18);assert.equal(b.events.includes('hazard'),false);assert.ok(Math.abs(b.x-preview.x)<.001);assert.ok(Math.abs(b.y-preview.y)<.001);
});
test('rough collision heights lie on the rendered hillside triangles',()=>{
 const h=makeHole('classic',0),ray=new THREE.Raycaster();
 for(const p of landscapePatches(h)){
  const positions=[],indices=[];for(let z=0;z<=p.nz;z++)for(let x=0;x<=p.nx;x++){const xx=p.offsetX+(x/p.nx-.5)*p.width,zz=p.offsetZ+(z/p.nz-.5)*p.depth;positions.push(xx,landscapeHeightAt(h,xx,zz),zz);}
  for(let z=0;z<p.nz;z++)for(let x=0;x<p.nx;x++){const a=z*(p.nx+1)+x;indices.push(a,a+p.nx+1,a+1,a+1,a+p.nx+1,a+p.nx+2);}
  const geometry=new THREE.BufferGeometry();geometry.setAttribute('position',new THREE.Float32BufferAttribute(positions,3));geometry.setIndex(indices);const material=new THREE.MeshBasicMaterial(),mesh=new THREE.Mesh(geometry,material);
  for(const [u,v] of [[.13,.27],[.52,.66],[.83,.41]]){const x=p.offsetX+(u-.5)*p.width,z=p.offsetZ+(v-.5)*p.depth;ray.set(new THREE.Vector3(x,30,z),new THREE.Vector3(0,-1,0));const hit=ray.intersectObject(mesh)[0];assert.ok(hit);assert.ok(Math.abs(roughHeightAt(h,x,z)-hit.point.y)<.00001);}
  geometry.dispose();material.dispose();
 }
});
test('water, course gaps and falling from floating islands still act as hazards',()=>{
 const h=makeHole('classic',6);assert.equal(terrainAt(h,14,h.gaps[0].z).type,'void');
 const lake=makeHole('tropical',0),p=lake.water[0];assert.equal(terrainAt(lake,p.x,p.z).type,'water');
 const sky=makeHole('sky',0,{wind:0}),b=createBall();strike(b,sky,drive);settle(b,sky);assert.equal(b.events.includes('hazard'),true);assert.equal(b.x,sky.tee.x);assert.equal(b.z,sky.tee.z);assert.equal(terrainAt(sky,12,2).type,'rough');
});
