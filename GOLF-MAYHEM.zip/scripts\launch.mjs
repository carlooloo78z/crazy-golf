import { spawn } from 'node:child_process';
import { mkdir, writeFile } from 'node:fs/promises';
import { openSync, closeSync } from 'node:fs';
import { createServer } from 'node:net';
import { fileURLToPath } from 'node:url';
import path from 'node:path';

const root = fileURLToPath(new URL('../', import.meta.url));
const runtime = path.join(root, '.local');
const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
await mkdir(runtime, { recursive: true });

async function isGame(port) {
  try {
    const response = await fetch(`http://127.0.0.1:${port}/`, { signal: AbortSignal.timeout(1500) });
    return response.ok && (await response.text()).includes('<title>GOLF MAYHEM');
  } catch { return false; }
}

async function isAvailable(port) {
  return new Promise(resolve => {
    const probe = createServer();
    probe.once('error', () => resolve(false));
    probe.listen(port, '127.0.0.1', () => probe.close(() => resolve(true)));
  });
}

let port;
let ready = false;
let freePort;
for (let candidate = 5173; candidate <= 5180; candidate++) {
  if (await isGame(candidate)) { port = candidate; ready = true; break; }
  if (freePort === undefined && await isAvailable(candidate)) freePort = candidate;
}
port ??= freePort;
if (port === undefined) throw Error('No available local port between 5173 and 5180.');

if (!ready) {
  const out = openSync(path.join(runtime, 'server.log'), 'a');
  const err = openSync(path.join(runtime, 'server-error.log'), 'a');
  const server = spawn(process.execPath, [path.join(root, 'scripts', 'serve.mjs')], {
    cwd: root,
    env: { ...process.env, PORT: String(port) },
    detached: true,
    windowsHide: true,
    stdio: ['ignore', out, err],
  });
  closeSync(out);
  closeSync(err);
  let launchError;
  server.once('error', error => { launchError = error; });
  server.unref();
  if (server.pid) await writeFile(path.join(runtime, 'server.pid'), String(server.pid));
  for (let attempt = 0; attempt < 40; attempt++) {
    if (launchError) throw launchError;
    if (await isGame(port)) { ready = true; break; }
    if (server.exitCode !== null) throw Error('The server could not start. See .local/server-error.log.');
    await sleep(200);
  }
}
if (!ready) throw Error('The server did not become ready. See .local/server-error.log.');
const url = `http://127.0.0.1:${port}/`;
console.log(`GOLF MAYHEM is ready: ${url}`);
if (!process.argv.includes('--no-open')) {
  const command = process.platform === 'win32'
    ? path.join(process.env.SystemRoot || 'C:\\Windows', 'System32', 'WindowsPowerShell', 'v1.0', 'powershell.exe')
    : process.platform === 'darwin' ? 'open' : 'xdg-open';
  const args = process.platform === 'win32' ? ['-NoProfile', '-Command', `Start-Process '${url}'`] : [url];
  await new Promise((resolve, reject) => {
    const opener = spawn(command, args, { windowsHide: true, stdio: 'ignore' });
    opener.once('error', reject);
    opener.once('exit', code => code === 0 ? resolve() : reject(Error(`Open ${url} in your browser.`)));
  }).catch(() => console.log(`The game is running. Open ${url} in your browser if it did not open automatically.`));
}
