export function chargeValue(milliseconds){return Math.min(1,Math.max(0,milliseconds)/1000*1.05);}
// Reach the selected maximum before the widest perfect-timing window begins.
export function swingStrength(maximum,charge){return Math.max(.02,Math.min(1,maximum)*Math.min(1,Math.max(0,charge)/.64));}
