import assert from 'node:assert/strict';
import {browser,sleep} from './cdp.mjs';
import {secondPage} from './second-page.mjs';
const a=await browser();let b;
async function waitFor(page,expression,timeout=35000){const start=Date.now();while(Date.now()-start<timeout){if(await page.evaluate(expression))return;await sleep(200);}console.log(await page.evaluate('JSON.stringify({phase:golfQA?.state().phase,overlay:golfQA?.state().overlay,round:golfQA?.state().round,connection:document.querySelector("#online-connection")?.textContent})'));throw Error('Timed out: '+expression);}
const state=page=>page.evaluate('golfQA.state()');
async function playThree(){
 for(let h=0;h<3;h++){
  for(let attempt=0;attempt<8;attempt++){
   let done=true;
   for(const p of [a,b]){const s=await state(p);if(s.ball.sunk||s.round.failure)continue;done=false;await waitFor(p,'golfQA.state().phase==="ready"');await p.evaluate('(async()=>{const {solveShot}=await import("/tests/solver.mjs");const c=golfQA.candidates();return golfQA.shoot({...solveShot(c.ball,c.hole,c.time),style:"straight",powerUp:null});})()');}
   if(done)break;
   for(const p of [a,b])await waitFor(p,'["ready","finished"].includes(golfQA.state().phase)');
  }
  for(const p of [a,b])assert.ok((await state(p)).ball.sunk,'Both players sink hole '+h);
  if(h<2){for(const p of [a,b])await p.click('[data-action="next"]');for(const p of [a,b])await waitFor(p,`golfQA.state().round.position===${h+1}`);}
 }
}
try{
 b=await secondPage(a);
 for(const [i,p] of [a,b].entries()){
  const init=await p.send('Page.addScriptToEvaluateOnNewDocument',{source:'sessionStorage.clear();try{const p=JSON.parse(localStorage.getItem("golf-mayhem-v1"));if(p){p.settings.quality="low";localStorage.setItem("golf-mayhem-v1",JSON.stringify(p));}}catch{}'});
  await p.send('Emulation.setDeviceMetricsOverride',{width:1000,height:740,deviceScaleFactor:1,mobile:false});await p.send('Page.navigate',{url:'http://127.0.0.1:5173/?qa=1'});await waitFor(p,'Boolean(window.golfQA)');await p.send('Page.removeScriptToEvaluateOnNewDocument',{identifier:init.identifier});
  await p.evaluate(`sessionStorage.clear();document.querySelector('#online-name').value='${i?'Morgan':'Alex'}';`);
  await p.click('[data-action="online"][data-id="duel"]');
 }
 await waitFor(a,'golfQA.state().round?.online');await waitFor(b,'golfQA.state().round?.online');
 assert.equal((await state(a)).round.matchId,(await state(b)).round.matchId);assert.notEqual((await state(a)).round.player,(await state(b)).round.player);await a.screenshot('online-duel-live');console.log('PASS Two independent browser tabs find each other and start the same match');
 // A normal poll must not overwrite the player's chosen aim or power.
 await a.evaluate('document.querySelector("#power").value=37;document.querySelector("#power").dispatchEvent(new Event("input",{bubbles:true}))');await sleep(1700);assert.equal((await state(a)).shot.power,.37);
 await a.click('[data-action="powerup"][data-id="rocket"]');await sleep(1500);assert.equal((await state(a)).shot.powerUp,'rocket');await a.click('[data-action="powerup"][data-id="rocket"]');
 await a.send('Input.dispatchKeyEvent',{type:'keyDown',key:' ',code:'Space',windowsVirtualKeyCode:32});await sleep(200);await a.send('Input.dispatchKeyEvent',{type:'keyUp',key:' ',code:'Space',windowsVirtualKeyCode:32});await waitFor(a,'["ready","finished"].includes(golfQA.state().phase)');assert.ok((await state(a)).round.lastShotPower<=.37);assert.ok((await state(a)).round.strokes>=1);console.log('PASS Held shot strength reaches the multiplayer server');
 await playThree();
 for(const p of [a,b])await waitFor(p,'golfQA.state().overlay==="online-result"');
 const final=await state(a);assert.equal(final.round.players.length,2);assert.ok(final.round.players.every(p=>p.scores.length===3&&!p.failures.some(Boolean)));assert.ok(final.round.earned>200);const coins=final.progress.coins;await sleep(2500);assert.equal((await state(a)).progress.coins,coins);await a.screenshot('online-duel-result');console.log('PASS Complete 1v1 match: real shots, live scores, final winner, prizes claimed once');
 for(const p of [a,b])await p.click('[data-action="quit"]');await sleep(300);
 for(const p of [a,b])await p.click('[data-action="online"][data-id="arena"]');await waitFor(a,'golfQA.state().round?.mode==="arena"',30000);await waitFor(b,'golfQA.state().round?.mode==="arena"');console.log('PASS Mayhem queue starts with two real players after its lobby countdown');
 await a.send('Page.reload');await waitFor(a,'Boolean(window.golfQA)&&golfQA.state().round?.online');assert.equal((await state(a)).round.matchId,(await state(b)).round.matchId);console.log('PASS Reload reconnects the same player to the live match');
 await a.send('Emulation.setDeviceMetricsOverride',{width:390,height:844,deviceScaleFactor:1,mobile:true});await sleep(500);await a.screenshot('online-match-mobile');assert.ok(await a.evaluate('document.documentElement.scrollWidth<=innerWidth'));
 await playThree();for(const p of [a,b])await waitFor(p,'golfQA.state().overlay==="online-result"');assert.ok((await state(a)).round.players.every(p=>p.scores.length===3));console.log('PASS Complete Mayhem match with server physics and final results');
 for(const p of [a,b])await p.click('[data-action="quit"]');await sleep(200);for(const p of [a,b])await p.click('[data-action="online"][data-id="duel"]');for(const p of [a,b])await waitFor(p,'golfQA.state().round?.mode==="duel"');
 await b.click('[data-action="pause"]');await b.click('[data-action="quit"]');await waitFor(a,'golfQA.state().overlay==="online-result"');assert.ok(await a.evaluate('document.querySelector(".modal").textContent.includes("YOU WIN")'));console.log('PASS Leaving forfeits; remaining player receives the result; mobile controls fit');
 assert.deepEqual(a.errors,[]);assert.deepEqual(b.errors,[]);
}finally{b?.close();await a.close();}
