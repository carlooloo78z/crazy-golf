import test from 'node:test';
import assert from 'node:assert/strict';
import {COURSES,CLUBS,makeHole,terrainAt,movingX} from '../src/courses.js';
import {createBall,strike,stepBall,predict,STEP,RADIUS} from '../src/physics.js';
import {defaultProgress,loadProgress,saveProgress,purchase,unlockAchievements,holeReward} from '../src/progress.js';

function run(ball,hole,seconds=25){let t=0;while(ball.moving&&t<seconds){stepBall(ball,hole,STEP,t);t+=STEP;}return ball;}
test('all six courses contain 18 distinct, deterministic, playable layouts',()=>{
 const signatures=new Set();for(const course of COURSES)for(let i=0;i<18;i++){
  const h=makeHole(course.id,i);assert.deepEqual(h,makeHole(course.id,i));assert.equal(h.courseId,course.id);assert.equal(terrainAt(h,h.tee.x,h.tee.z).type,'fairway');assert.equal(terrainAt(h,h.cup.x,h.cup.z).type,'green');assert.ok(h.par>=3&&h.par<=5);signatures.add(JSON.stringify(h));
 }assert.equal(signatures.size,108);
});
test('a complete tee-to-cup shot is possible without changing ball position',()=>{
 const hole=makeHole('classic',0,{wind:0});let solution;
 for(const club of ['iron','driver'])for(let power=.3;power<=1;power+=.002){const result=predict(createBall(),hole,{club,power,angle:0,loft:CLUBS[club].loft});if(result.ball.sunk){solution={club,power,angle:0,loft:CLUBS[club].loft};break;}}
 assert.ok(solution,'there should be a real first-hole ace');const b=createBall();strike(b,hole,solution);run(b,hole);assert.equal(b.sunk,true);assert.ok(b.events.includes('cup'));
});
test('slow and full-power putts both drop when they cross the cup',()=>{
 const h=makeHole('classic',0,{wind:0}),b=createBall(0,h.cup.z-3);strike(b,h,{club:'putter',power:.28,angle:0,loft:0});run(b,h);assert.equal(b.sunk,true);
 const fast=createBall(0,h.cup.z-.4);strike(fast,h,{club:'putter',power:1,angle:0,loft:0});run(fast,h);assert.equal(fast.sunk,true);
});
test('sand and rough shorten a stroke compared with fairway',()=>{
 const base=makeHole('classic',0,{wind:0});base.cup.z=90;base.length=100;base.water=[];base.sand=[];const b=createBall();strike(b,base,{club:'putter',power:.7,angle:0,loft:0});run(b,base);const normal=b.z;
 const sandy=structuredClone(base);sandy.sand=[{x:0,z:20,rx:15,rz:40}];const s=createBall();strike(s,sandy,{club:'putter',power:.7,angle:0,loft:0});run(s,sandy);assert.ok(s.z<normal*.7);
 const r=createBall(9,2);strike(r,base,{club:'putter',power:.7,angle:0,loft:0});run(r,base);assert.ok(r.z<normal);
});
test('airborne loft, crosswind, hazards, wall collisions, and bounce pads affect the ball',()=>{
 const h=makeHole('classic',0,{wind:0});h.water=[];const calm=predict(createBall(),h,{club:'wedge',power:.9,angle:0,loft:60});assert.ok(Math.max(...calm.points.map(p=>p.y))>6);
 h.wind.x=10;const windy=predict(createBall(),h,{club:'wedge',power:.9,angle:0,loft:60});assert.ok(windy.ball.x>calm.ball.x+1);
 h.water=[{x:0,z:7,rx:3,rz:2}];const b=createBall();strike(b,h,{club:'putter',power:.9,angle:0,loft:0});run(b,h);assert.ok(b.events.includes('hazard'));assert.equal(b.z,2);assert.equal(b.moving,false);
 h.water=[];h.walls=[{x:0,z:7,w:8,d:1,h:3}];const w=createBall();strike(w,h,{club:'putter',power:.9,angle:0,loft:0});run(w,h);assert.ok(w.events.includes('wall'));
 h.walls=[];h.bouncers=[{x:0,z:3,rx:4,rz:4}];const pad=createBall(0,3);pad.y=3;pad.vy=-5;pad.moving=true;let bounced=false;for(let i=0;i<150;i++){stepBall(pad,h,STEP,i*STEP);if(pad.events.includes('bounce')){bounced=true;break;}}assert.ok(bounced);assert.ok(pad.vy>0);
});
test('platforms, loops, fans, and shortcuts have physical behavior',()=>{
 const h=makeHole('classic',6);assert.equal(terrainAt(h,movingX(h.platforms[0],0),h.gaps[0].z,0).type,'platform');assert.equal(terrainAt(h,14,h.gaps[0].z,0).type,'void');
 const l=makeHole('classic',9,{wind:0});const b=createBall(0,l.loops[0].z-.7);strike(b,l,{club:'putter',power:1,angle:0,loft:0});run(b,l);assert.ok(b.events.includes('loop'));
 const s=makeHole('classic',10,{wind:0}),g=s.shortcuts[0],p=createBall(g.x,g.z-1.8);strike(p,s,{club:'putter',power:.7,angle:0,loft:0});run(p,s);assert.ok(p.events.includes('shortcut'));assert.ok(p.teleported);
 const f=makeHole('classic',3,{wind:0}),fb=createBall(-3,f.fans[0].z);strike(fb,f,{club:'wedge',power:.4,angle:0,loft:60});run(fb,f);assert.ok(fb.x>-2);
});
test('save/load, corrupt saves, purchases and achievement rewards are transactional',()=>{
 const data=new Map(),storage={getItem:k=>data.get(k)||null,setItem:(k,v)=>data.set(k,v)};let p=loadProgress(storage);assert.equal(p.coins,0);p.coins=250;assert.ok(purchase(p,'balls','sunshine'));assert.equal(p.coins,190);assert.ok(purchase(p,'balls','sunshine'));assert.equal(p.coins,190);assert.equal(purchase(p,'clubs','carbon'),false);assert.equal(p.coins,190);p.stats.aces=1;const awards=unlockAchievements(p);assert.ok(awards.some(a=>a.id==='ace'));const balance=p.coins;unlockAchievements(p);assert.equal(p.coins,balance);assert.ok(saveProgress(p,storage));assert.deepEqual(loadProgress(storage),p);data.set('golf-mayhem-v1','oops');assert.deepEqual(loadProgress(storage),defaultProgress());assert.ok(holeReward(1,3,2)>holeReward(3,3,1));
});
test('free fall follows gravity, air drag shortens flight, and an off-line putt misses',()=>{
 const h=makeHole('classic',0,{wind:0});h.water=[];h.sand=[];
 const dropped=createBall();dropped.y=10;dropped.moving=true;for(let i=0;i<60;i++)stepBall(dropped,h,STEP,i*STEP);assert.ok(Math.abs(dropped.y-(10-.5*9.81*.5**2))<.08);
 const flight=predict(createBall(),h,{club:'wedge',power:.6,angle:0,loft:60});const vacuumHeight=(21*.6*Math.sin(Math.PI/3))**2/(2*9.81)+RADIUS;assert.ok(Math.max(...flight.points.map(p=>p.y))<vacuumHeight);
 const miss=createBall(h.cup.x+.55,h.cup.z-3);strike(miss,h,{club:'putter',power:.28,angle:0,loft:0});run(miss,h);assert.equal(miss.sunk,false);
});
test('backspin checks the first bounce and penalties preserve a bunker lie below ground level',()=>{
 const h=makeHole('classic',0,{wind:0});h.water=[];h.sand=[];
 const plain=createBall(),spinning=createBall();for(const b of [plain,spinning]){b.y=RADIUS+.02;b.vx=0;b.vz=6;b.vy=-5;b.moving=true;b.backspin=b===spinning?.45:0;}run(plain,h);run(spinning,h);assert.ok(spinning.z<plain.z);
 h.sand=[{x:7,z:10,rx:3,rz:3}];const b=createBall(7,10);b.y=-.08+RADIUS;strike(b,h,{club:'wedge',power:.6,angle:0,loft:50});b.y=-5;stepBall(b,h);assert.equal(b.x,7);assert.equal(b.z,10);assert.ok(b.y<0);
});
