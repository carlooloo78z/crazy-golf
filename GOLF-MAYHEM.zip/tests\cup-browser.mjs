import assert from 'node:assert/strict';
import {browser,sleep} from './cdp.mjs';
const b=await browser();
try{
 await b.send('Emulation.setDeviceMetricsOverride',{width:1100,height:900,deviceScaleFactor:1,mobile:false});
 await b.send('Page.navigate',{url:'http://127.0.0.1:5173/?qa=1&v=cup-capture'});
 for(let i=0;i<100;i++){if(await b.evaluate('Boolean(window.golfQA)'))break;await sleep(150);}
 await b.click('[data-action="settings"]');await b.evaluate('document.querySelector("#setting-quality").value="low";document.querySelector("#setting-quality").dispatchEvent(new Event("input",{bubbles:true}))');await b.click('[data-action="close"]');
 await b.click('[data-action="help"]');await b.click('[data-action="secrets-guide"]');
 const maps=await b.evaluate('Array.from(document.querySelectorAll(".secret-location"),el=>({label:el.querySelector("svg").getAttribute("aria-label"),caption:el.querySelector("figcaption").textContent}))');
 assert.equal(maps.length,6);assert.ok(maps.every(m=>m.label.includes('ahead')&&m.caption.includes('Any height')));assert.ok(maps[0].label.includes('9.5m left'));assert.ok(maps[2].label.includes('10m right'));
 await b.screenshot('secret-maps-desktop');
 await b.send('Emulation.setDeviceMetricsOverride',{width:390,height:844,deviceScaleFactor:1,mobile:true});
 assert.ok(await b.evaluate('document.documentElement.scrollWidth<=innerWidth'));
 assert.ok(await b.evaluate('Array.from(document.querySelectorAll(".secret-location svg"),el=>el.getBoundingClientRect()).every(r=>r.width>100&&r.right<=innerWidth)'));
 await b.screenshot('secret-maps-mobile');await b.click('[data-action="close"]');
 console.log('PASS All six secret maps show tee-relative directions and no height requirement on desktop and mobile');
 await b.send('Emulation.setDeviceMetricsOverride',{width:1100,height:900,deviceScaleFactor:1,mobile:false});
 const highSecret=await b.evaluate(`(()=>{
  golfQA.start('quick','classic',0,undefined,{difficulty:'expert',chaos:'wild'});
  const c=golfQA.candidates(),s=c.hole.secrets[0],shot={club:'wedge',power:.95,angle:Math.atan2(s.x-c.ball.x,s.z-c.ball.z),loft:55};
  golfQA.shoot(shot);golfQA.advance();return golfQA.state();
 })()`);
 assert.equal(highSecret.ball.secretAce,'hollow-oak');assert.ok(highSecret.ball.airtime>1);
 console.log('PASS High wedge shot over the secret oak activates the shortcut without matching the hollow height');
 const air=await b.evaluate(`(async()=>{
  golfQA.start('quick','classic',0,undefined,{difficulty:'expert',chaos:'wild'});
  const {solveAirCup}=await import('/tests/cup-solver.mjs'),c=golfQA.candidates();
  if(!golfQA.shoot(solveAirCup(c.ball,c.hole,c.time)))throw Error('Air shot refused');
  golfQA.advance();return golfQA.state();
 })()`);
 assert.equal(air.ball.sunk,true);assert.equal(air.round.strokes,1);assert.ok(air.ball.airtime>1);assert.equal(air.ball.events.includes('bounce-soft'),false);
 for(let i=0;i<40;i++){if(await b.evaluate('golfQA.state().overlay==="hole-result"'))break;await sleep(150);}
 assert.equal(await b.evaluate('golfQA.state().overlay'),'hole-result');await b.screenshot('airborne-cup-result');
 const coins=await b.evaluate('golfQA.state().progress.coins');await b.evaluate('golfQA.advance()');assert.equal(await b.evaluate('golfQA.state().progress.coins'),coins);
 await b.click('[data-action="next"]');assert.equal(await b.evaluate('golfQA.state().hole'),1);
 console.log('PASS A real airborne tee shot sinks, celebrates, rewards once and advances to the next hole');
 const fast=await b.evaluate(`(async()=>{
  golfQA.start('free','desert',0,undefined,{difficulty:'expert',chaos:'wild',hole:0});
  const {solveSecret}=await import('/tests/secret-solver.mjs');let c=golfQA.candidates();golfQA.shoot(solveSecret(c.ball,c.hole));golfQA.advance();
  c=golfQA.candidates();if(Math.abs(Math.hypot(c.ball.x-c.hole.cup.x,c.ball.z-c.hole.cup.z)-2)>.001)throw Error('Secret did not leave two-metre putt');
  golfQA.shoot({club:'putter',power:1,angle:Math.atan2(c.hole.cup.x-c.ball.x,c.hole.cup.z-c.ball.z),loft:0});golfQA.advance();return golfQA.state();
 })()`);
 assert.equal(fast.ball.sunk,true);assert.equal(fast.round.strokes,2);assert.deepEqual(b.errors,[]);
 console.log('PASS Full-power putt through the cup counts; no browser errors');
}finally{await b.close();}
