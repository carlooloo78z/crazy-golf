import assert from 'node:assert/strict';
import {browser,sleep} from './cdp.mjs';
const b=await browser();
try{
 await b.send('Emulation.setDeviceMetricsOverride',{width:1000,height:740,deviceScaleFactor:1,mobile:false});
 await b.send('Page.navigate',{url:'http://127.0.0.1:5173/?qa=1'});
 for(let i=0;i<100;i++){if(await b.evaluate('Boolean(window.golfQA)'))break;await sleep(150);}
 await b.click('[data-action="settings"]');await b.evaluate(`document.querySelector("#setting-quality").value="${process.argv.includes('--high')?'high':'low'}";document.querySelector("#setting-quality").dispatchEvent(new Event("input",{bubbles:true}))`);await b.click('[data-action="close"]');await sleep(1200);await b.screenshot('realistic-home');console.log('Home screenshot complete');
 await b.evaluate("golfQA.start('quick','classic')");await sleep(1600);console.log('Game ready',await b.evaluate('golfQA.state().phase'));await b.screenshot('realistic-classic');
 assert.deepEqual(b.errors,[]);console.log('Realistic scene rendered with no browser errors.');
}finally{await b.close();}
