import {populateMayhem} from './mayhem.js';
import {populateWildlife} from './wildlife.js';
export const COURSES = [
  { id:'classic', name:'CLASSIC', subtitle:'A little green. A lot of possibility.', label:'Emerald Hills', color:'#c9fb69', sky:0xbce8ed, ground:0x639a4b, fairway:0x8fc66c, green:0xa4d47c, rock:0xb69b79, water:0x50bed0, price:0, difficulty:1, decor:'tree' },
  { id:'desert', name:'DESERT', subtitle:'Big skies. Bigger canyon shots.', label:'Sunset Canyon', color:'#ffc582', sky:0xf6d7ae, ground:0xd39b5d, fairway:0xb3b96b, green:0xd8d384, rock:0xbf7047, water:0x51adab, price:180, difficulty:2, decor:'cactus' },
  { id:'tropical', name:'TROPICAL', subtitle:'Find your swing in paradise.', label:'Palm Paradise', color:'#76e5cd', sky:0xb0e6ec, ground:0xe9d7a2, fairway:0x67bd88, green:0x8fd4a0, rock:0xd8c28e, water:0x29b7cc, price:320, difficulty:2, decor:'palm' },
  { id:'sky', name:'SKY', subtitle:'The fairway has left the planet.', label:'Cloud Nine', color:'#a4bdff', sky:0xaec6f7, ground:0x8da1ba, fairway:0xa2c5c3, green:0xc2e3ca, rock:0x8391aa, water:0x95b6ef, price:480, difficulty:3, decor:'crystal' },
  { id:'volcano', name:'VOLCANO', subtitle:'Hot shots. Very hot hazards.', label:'Molten Valley', color:'#ff9779', sky:0x4d4e68, ground:0x4d514f, fairway:0x778c66, green:0x95a77a, rock:0x4b4146, water:0xff6032, price:640, difficulty:4, decor:'volcano' },
  { id:'neon', name:'NEON', subtitle:'After dark. Beyond par.', label:'Neon District', color:'#d7a3ff', sky:0x171e38, ground:0x232c4b, fairway:0x405b65, green:0x568a83, rock:0x26324f, water:0xb86bfb, price:800, difficulty:4, decor:'neon' },
];

export const MODES = [
  {id:'quick',name:'Quick play',icon:'bolt',tag:'THE GOOD STUFF',description:'Three holes. One great escape.',holes:3},
  {id:'career',name:'Career',icon:'trophy',tag:'MAKE YOUR NAME',description:'18 holes. Six tournaments. Climb the ranks.',holes:18},
  {id:'challenge',name:'Challenges',icon:'target',tag:'BREAK THE RULES',description:'Six skill trials with special shot rules.',holes:1},
  {id:'time',name:'Time attack',icon:'timer',tag:'BEAT THE CLOCK',description:'Nine holes. Every second counts.',holes:9},
  {id:'free',name:'Free play',icon:'flag',tag:'YOUR PACE',description:'Explore all 108 holes. No locked courses.',holes:18},
  {id:'multi',name:'Multiplayer',icon:'users',tag:'PASS & PLAY',description:'2–4 friends. Same screen. Bragging rights.',holes:9},
  {id:'survival',name:'Survival',icon:'spark',tag:'THREE LIVES',description:'Nine holes. Three lives. Over par costs a life.',holes:9},
  {id:'shuffle',name:'Club shuffle',icon:'club',tag:'ADAPT YOUR SWING',description:'Six short holes. A different compulsory club each tee.',holes:6},
  {id:'daily',name:'Daily Cup',icon:'medal',tag:'FRESH EVERY DAY',description:'A daily six-hole route. Beat your personal best.',holes:6},
  {id:'duel',name:'Online Duel',icon:'globe',tag:'1 VS 1',description:'Find a real opponent. Three holes. Lowest score wins.',holes:3,online:true},
  {id:'arena',name:'Online Mayhem',icon:'bolt',tag:'2–4 PLAYERS',description:'Real players. Wild obstacles. A live race to the cup.',holes:3,online:true},
];

export const CHALLENGES = [
  {name:'One & done',description:'Ace the opening hole in a single stroke.',hole:0,limit:1,clubs:null,wind:0,reward:120},
  {name:'Putting party',description:'Finish a short hole using only your putter in 3 strokes.',hole:1,limit:3,clubs:['putter'],short:true,reward:100},
  {name:'Against the wind',description:'Beat a fierce crosswind in 4 strokes.',hole:3,limit:4,wind:10,reward:150},
  {name:'Air mail',description:'Wedges only. Clear the obstacles in 4 strokes.',hole:4,limit:4,clubs:['wedge'],short:true,reward:150},
  {name:'Bank on it',description:'Navigate the moving wall in 3 strokes.',hole:5,limit:3,reward:170},
  {name:'The long game',description:'Finish the longest hole in 3 strokes.',hole:17,limit:3,reward:200},
];

export const CLUBS = {
  driver:{name:'Driver',mark:'1W',speed:36,loft:24,min:8,max:48,range:'LONG RANGE',color:'#d1fa79'},
  iron:{name:'Iron',mark:'7I',speed:25,loft:36,min:15,max:60,range:'ALL ROUNDER',color:'#92dcfa'},
  wedge:{name:'Wedge',mark:'SW',speed:21,loft:55,min:30,max:72,range:'HIGH & SOFT',color:'#f9bf84'},
  putter:{name:'Putter',mark:'PT',speed:12,loft:0,min:0,max:0,range:'ON THE GREEN',color:'#d5aff7'},
};

const NAMES=['First Light','Lazy Bend','Sandy Situation','Wind Rider','Up & Over','Moving Target','Island Hopping','Bounce House','Through the Looking Glass','Loop Dreams','The Hidden Route','Crossing Over','Double Trouble','High Stakes','The Long Way Home','Tunnel Vision','Final Approach','The Grand Finale'];
export function seeded(seed) { return () => {seed=(seed*1664525+1013904223)>>>0;return seed/4294967296;}; }
export function makeHole(courseId='classic',index=0,options={}) {
  const theme=COURSES.find(c=>c.id===courseId)||COURSES[0];
  const ci=COURSES.indexOf(theme), rand=seeded(719+ci*1013+index*79);
  const length=options.short?22:38+index*2.5+(index%3)*5+ci*1.8;
  const bend=index===0?0:(rand()-.5)*10;
  const hole={courseId,index,theme,name:NAMES[index%18],length,width:36,par:length>80?5:length>53?4:3,
    tee:{x:0,z:2},cup:{x:bend,z:length},bend,
    wind:{x:options.wind===0?0:(rand()-.5)*(options.wind||3.5),z:options.wind===0?0:(rand()-.5)*1.2},
    sand:[],water:[],walls:[],ramps:[],bouncers:[],fans:[],gaps:[],platforms:[],tunnels:[],loops:[],shortcuts:[],seed:719+ci*1013+index*79};
  hole.sand.push({x:index===0?7:-7+rand()*4,z:length*.53,rx:3.4+rand()*1.4,rz:4.2+rand()*2});
  if(index>1)hole.sand.push({x:bend+6,z:length-8,rx:3,rz:4});
  if(index%3===2 || ci===2 || ci===4)hole.water.push({x:(index%2?1:-1)*9,z:length*.43,rx:4.6,rz:7});
  if(index===0)hole.water.push({x:-11,z:length*.68,rx:4.6,rz:7});
  if([3,12,16].includes(index))hole.fans.push({x:-4,z:length*.5,radius:7,power:ci===3?7:4});
  if([4,9,13,17].includes(index))hole.ramps.push({x:0,z:length*.4,w:5,d:6,h:2.6});
  if([5,12,14,17].includes(index))hole.walls.push({x:0,z:length*.57,w:6,h:2.8,d:.7,amplitude:5,speed:1.1,phase:rand()*6});
  if([6,11,15].includes(index)) {
    hole.gaps.push({z:length*.46,d:5});
    hole.platforms.push({x:0,z:length*.46,w:5,d:5.6,amplitude:8,speed:.6,phase:0});
  }
  if([7,13,17].includes(index))hole.bouncers.push({x:0,z:length*.48,rx:3,rz:3});
  if([8,15].includes(index))hole.tunnels.push({x:bend*.35,z:length*.55,w:6,h:3,d:7});
  if([9,14].includes(index))hole.loops.push({x:0,z:length*.6,r:3.3});
  if([10,16].includes(index))hole.shortcuts.push({x:-9,z:length*.3,toX:bend-2,toZ:length-6});
  if(ci===3 && index>1 && !hole.gaps.length) {hole.gaps.push({z:length*.65,d:4});hole.platforms.push({x:3,z:length*.65,w:6,d:4.6,amplitude:5,speed:.5,phase:1});}
  if(options.short){hole.gaps=[];hole.water=[];hole.walls=index===4?[{x:0,z:11,w:7,h:1.8,d:.6,amplitude:0,speed:0,phase:0}]:[];hole.loops=[];hole.ramps=[];hole.tunnels=[];hole.sand=[];}
  addSurroundings(hole);
  hole.trees=forestLayout(hole);
  for(const [i,lake] of hole.sceneryLakes.entries())for(const side of [-1,1]){const x=lake.island.x+side*1.1,z=lake.island.z,type=hole.courseId==='tropical'?'palm':'tree';hole.trees.push({id:'island-tree-'+i+'-'+side,x,z,y:roughHeightAt(hole,x,z),s:.65,type,h:(type==='palm'?4:3.2)*.65,external:true});}
  for(const [i,island] of hole.sceneryIslands.entries())for(const side of [-1,1])hole.trees.push({id:'cloud-tree-'+i+'-'+side,x:island.x+side*2.3,z:island.z+1.5,y:island.y,s:.8,type:'tree',h:3.2*.8,external:true});
  return populateWildlife(populateMayhem(hole,options),options);
}

export function forestLayout(hole){
 const rng=seeded(hole.seed+412),trees=[],type=hole.theme.decor;
 for(let i=0;i<30;i++){const z=-4+rng()*(hole.length+12),x=(i%2?1:-1)*(12.8+rng()*3.5);if(hole.gaps.some(g=>Math.abs(z-g.z)<g.d/2+2))continue;if(hole.water.some(p=>((x-p.x)/p.rx)**2+((z-p.z)/p.rz)**2<1.5))continue;trees.push({x,z,s:.8+rng()*.55});}
 if(hole.courseId!=='sky')for(let i=0;i<62;i++){const x=(i%2?1:-1)*(25+rng()*55),z=-10+rng()*(hole.length+80);if(hole.sceneryLakes.some(p=>ellipse(x,z,p,3)))continue;trees.push({x,z,s:.9+rng()*1.4,distant:true});}
 return trees.map((t,i)=>({...t,id:'tree-'+i,type,y:t.distant?roughHeightAt(hole,t.x,t.z):0,h:(type==='palm'?5.5:4.3)*t.s}));
}

function addSurroundings(hole){
  const rand=seeded(hole.seed+9203);hole.sceneryLakes=[];hole.sceneryIslands=[];
  if(hole.courseId==='sky'){
    for(let i=0;i<3;i++)hole.sceneryIslands.push({x:(i%2?1:-1)*(33+rand()*7),z:hole.length*(.22+i*.28),rx:7+rand()*2,rz:9+rand()*3,y:1+rand()*2});
  }else{
    for(const [x,z,rx,rz] of [[38,hole.length*.6+5,10,12],[-43,hole.length*.92+16,12,15]]){
      const level=baseLandscapeHeightAt(hole,x,z)-.8;
      hole.sceneryLakes.push({x,z,rx,rz,level,island:{x:x+1,z:z+1.5,rx:4.2,rz:5.2}});
    }
  }
}

export function centerAt(hole,z) { return hole.bend*(z/hole.length)+Math.sin(z/hole.length*Math.PI*2)*(hole.index===0?0:2.5); }
export function movingX(object,time) {return object.x+Math.sin(time*object.speed+object.phase)*object.amplitude;}
export function ellipse(x,z,p,pad=0){return ((x-p.x)/(p.rx+pad))**2+((z-p.z)/(p.rz+pad))**2<1;}
// These four patches are both visible land and playable rough.
export function landscapePatches(hole){
  return [
    ...[-1,1].map(side=>({width:132,depth:hole.length+210,nx:44,nz:64,offsetX:side*(hole.width/2+66),offsetZ:hole.length/2})),
    {width:hole.width,depth:98,nx:16,nz:32,offsetX:0,offsetZ:-56},
    {width:hole.width,depth:95,nx:16,nz:32,offsetX:0,offsetZ:hole.length+57.5},
  ];
}
function baseLandscapeHeightAt(hole,x,z){
  const away=Math.max(Math.abs(x)-hole.width/2,-7-z,z-hole.length-10,0),fade=Math.min(1,away/18);
  return fade*(1.5+Math.sin(x*.052+z*.02)*3.2+Math.sin(z*.065)*2.1)+fade*fade*Math.max(0,Math.sin(x*.022-z*.013))*7;
}
export function landscapeHeightAt(hole,x,z){
  let y=baseLandscapeHeightAt(hole,x,z);
  for(const lake of hole.sceneryLakes||[]){
    const r=((x-lake.x)/lake.rx)**2+((z-lake.z)/lake.rz)**2;
    if(r<1.3){const blend=Math.min(1,(1.3-r)/.3);y=y*(1-blend)+(lake.level-1)*blend;const i=lake.island,d=((x-i.x)/i.rx)**2+((z-i.z)/i.rz)**2;if(d<1.3)y=Math.max(y,lake.level+1.5*(1-d/1.3));}
  }
  return y;
}
export function roughHeightAt(hole,x,z){
  const patches=landscapePatches(hole),p=Math.abs(x)>hole.width/2?patches[x<0?0:1]:patches[z< -7?2:3];
  const dx=p.width/p.nx,dz=p.depth/p.nz,minX=p.offsetX-p.width/2,minZ=p.offsetZ-p.depth/2;
  const gx=Math.max(0,Math.min(p.nx,(x-minX)/dx)),gz=Math.max(0,Math.min(p.nz,(z-minZ)/dz));
  const ix=Math.min(p.nx-1,Math.floor(gx)),iz=Math.min(p.nz-1,Math.floor(gz)),u=gx-ix,v=gz-iz,x0=minX+ix*dx,z0=minZ+iz*dz;
  const h=(a,b)=>landscapeHeightAt(hole,x0+a*dx,z0+b*dz);
  // Interpolate the same two triangles used by the rendered terrain mesh.
  return u+v<=1?h(0,0)*(1-u-v)+h(1,0)*u+h(0,1)*v:h(1,0)*(1-v)+h(0,1)*(1-u)+h(1,1)*(u+v-1);
}
export function terrainAt(hole,x,z,time=0){
  if(Math.abs(x)>hole.width/2 || z< -7 || z>hole.length+10){
    for(const i of hole.sceneryIslands||[])if(ellipse(x,z,i))return {type:'rough',height:i.y,friction:6};
    if(hole.courseId==='sky')return {type:'void',height:-20,friction:0};
    if(Math.abs(x)<=hole.width/2+132&&z>=-105&&z<=hole.length+105){
      for(const lake of hole.sceneryLakes||[])if(ellipse(x,z,lake)){const height=roughHeightAt(hole,x,z);return height>lake.level+.02?{type:'rough',height,friction:6}:{type:'water',height:lake.level-.25,friction:0};}
      return {type:'rough',height:roughHeightAt(hole,x,z),friction:6};
    }
    return {type:'bounds',height:0,friction:0};
  }
  for(const gap of hole.gaps)if(Math.abs(z-gap.z)<gap.d/2){
    for(const p of hole.platforms)if(Math.abs(x-movingX(p,time))<p.w/2 && Math.abs(z-p.z)<p.d/2)return {type:'platform',height:0,friction:2.7,platform:p};
    return {type:'void',height:-20,friction:0};
  }
  for(const p of hole.water)if(ellipse(x,z,p))return {type:'water',height:-.25,friction:0};
  for(const p of hole.ramps)if(Math.abs(x-p.x)<p.w/2 && Math.abs(z-p.z)<p.d/2)return {type:'ramp',height:(z-(p.z-p.d/2))/p.d*p.h,friction:1.5,slope:p.h/p.d};
  for(const p of hole.bouncers)if(ellipse(x,z,p))return {type:'bounce',height:.08,friction:.5};
  if(Math.hypot(x-hole.cup.x,z-hole.cup.z)<6)return {type:'green',height:0,friction:hole.difficulty==='expert'?1.35:1.85};
  for(const p of hole.sand)if(ellipse(x,z,p))return {type:'sand',height:-.08,friction:9};
  if(Math.abs(x-centerAt(hole,z))<5.5)return {type:'fairway',height:0,friction:2.7};
  return {type:'rough',height:0,friction:6};
}
