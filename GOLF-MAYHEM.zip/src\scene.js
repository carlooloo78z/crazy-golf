import * as THREE from '../vendor/three.module.min.js';
import { centerAt, seeded, movingX, terrainAt } from './courses.js';
import { RADIUS } from './physics.js';
import {buildLandscape,buildForest,addGolfDetails,dimpleTexture,grainTexture} from './natural.js';
import {buildMayhem,animateMayhem} from './mayhem-scene.js';
import {buildSurroundings,animateSurroundings} from './surroundings-scene.js';
import {buildSecrets,beginReactionScene,animateReactionScene,endReactionScene} from './wildlife-scene.js';

const UP=new THREE.Vector3(0,1,0);
export class GolfScene {
  constructor(canvas,settings) {
    this.canvas=canvas;this.settings=settings;
    this.renderer=new THREE.WebGLRenderer({canvas,antialias:true,alpha:false,powerPreference:'high-performance'});
    this.renderer.setPixelRatio(Math.min(devicePixelRatio,settings.quality==='low'?1:1.8));
    this.renderer.shadowMap.enabled=settings.quality!=='low';this.renderer.shadowMap.type=THREE.PCFSoftShadowMap;this.renderer.shadowMap.autoUpdate=false;this.shadowTick=-1;
    this.renderer.outputColorSpace=THREE.SRGBColorSpace;this.renderer.toneMapping=THREE.ACESFilmicToneMapping;this.renderer.toneMappingExposure=1.05;
    this.scene=new THREE.Scene();this.camera=new THREE.PerspectiveCamera(48,1,.04,450);
    this.scene.add(new THREE.HemisphereLight(0xc8dded,0x655f43,.95));
    this.sun=new THREE.DirectionalLight(0xfff1d5,3);this.sun.position.set(-40,48,-28);this.sun.castShadow=true;
    this.sun.shadow.mapSize.set(2048,2048);Object.assign(this.sun.shadow.camera,{left:-70,right:70,top:80,bottom:-80,near:.5,far:170});this.sun.shadow.bias=-.0005;this.sun.shadow.normalBias=.08;this.scene.add(this.sun);
    this.world=new THREE.Group();this.scene.add(this.world);
    this.ball=this.mesh(new THREE.SphereGeometry(RADIUS,32,24),0xffffff,{roughness:.3,bumpMap:dimpleTexture(),bumpScale:.003});this.ball.castShadow=true;this.scene.add(this.ball);
    this.ballRing=this.mesh(new THREE.RingGeometry(.23,.25,32),0xffffff,{transparent:true,opacity:.6});this.ballRing.rotation.x=-Math.PI/2;this.scene.add(this.ballRing);
    this.trail=[];this.trailLine=new THREE.Line(new THREE.BufferGeometry(),new THREE.LineBasicMaterial({color:0xffffff,transparent:true,opacity:.6}));this.scene.add(this.trailLine);this.path=new THREE.Group();this.scene.add(this.path);
    this.particles=[];this.target=new THREE.Vector3();this.mode='home';this.cameraMode='follow';this.orbit=0;
    this.resizeObserver=new ResizeObserver(()=>this.resize());this.resizeObserver.observe(canvas);this.resize();
  }
  mesh(geometry,color,options={}) {return new THREE.Mesh(geometry,new THREE.MeshStandardMaterial({color,roughness:.9,...options}));}
  setRivals(players){
    if(!this.rivals){this.rivals=new THREE.Group();this.scene.add(this.rivals);this.rivalObjects=new Map();}
    const ids=new Set(players.map(p=>p.id));for(const [id,g] of this.rivalObjects)if(!ids.has(id)){g.traverse(o=>{o.material?.map?.dispose();});this.disposeGroup(g);this.rivals.remove(g);this.rivalObjects.delete(id);}
    for(const p of players){let g=this.rivalObjects.get(p.id);if(!g){g=new THREE.Group();const b=this.mesh(new THREE.SphereGeometry(RADIUS*1.4,16,12),p.color,{emissive:p.color,emissiveIntensity:.2});g.add(b);const r=this.mesh(new THREE.RingGeometry(.27,.36,24),p.color,{side:THREE.DoubleSide});r.rotation.x=-Math.PI/2;r.position.y=-RADIUS+.02;g.add(r);const c=document.createElement('canvas');c.width=256;c.height=64;const ctx=c.getContext('2d');ctx.fillStyle='rgba(14,35,32,.85)';ctx.fillRect(0,0,256,64);ctx.fillStyle=p.color;ctx.font='bold 26px sans-serif';ctx.textAlign='center';ctx.fillText(p.name,128,42,240);const map=new THREE.CanvasTexture(c),label=new THREE.Sprite(new THREE.SpriteMaterial({map,depthTest:false,sizeAttenuation:false}));label.scale.set(.12,.03,1);label.position.y=.8;g.add(label);this.rivals.add(g);this.rivalObjects.set(p.id,g);}g.position.set(p.x,p.y,p.z);}
  }
  add(geometry,color,x,y,z,options={}){const m=this.mesh(geometry,color,options);m.position.set(x,y,z);m.castShadow=true;m.receiveShadow=true;this.world.add(m);return m;}
  box(w,h,d,color,x,y,z){return this.add(new THREE.BoxGeometry(w,h,d),color,x,y,z);}
  disc(rx,rz,color,x,y,z,options={}){const m=this.add(new THREE.CircleGeometry(1,48),color,x,y,z,options);m.rotation.x=-Math.PI/2;m.scale.set(rx,rz,1);m.castShadow=false;return m;}
  disposeGroup(group){group.traverse(o=>{o.geometry?.dispose();if(o.material)for(const m of Array.isArray(o.material)?o.material:[o.material])m.dispose();});group.clear();}
  resize(){const w=this.canvas.clientWidth,h=this.canvas.clientHeight;if(!w||!h)return;this.renderer.setSize(w,h,false);this.camera.aspect=w/h;this.camera.updateProjectionMatrix();}
  build(hole){
    endReactionScene(this);
    this.disposeGroup(this.world);this.clearPath();this.hole=hole;this.animated=[];this.trees=[];this.fans=[];this.failure=false;
    const t=hole.theme,rng=seeded(hole.seed);this.scene.background=new THREE.Color(t.sky);this.scene.fog=new THREE.Fog(t.sky,105,210);
    this.sun.color.set(t.id==='neon'?0xb7c7ff:0xfff1d5);this.sun.intensity=t.id==='neon'?1.6:3;this.trail=[];this.celebration=0;this.shadowTick=-1;
    buildLandscape(this,hole);
    addGolfDetails(this,hole);
    for(const p of hole.platforms){const g=new THREE.Group();this.world.add(g);const m=this.mesh(new THREE.BoxGeometry(p.w,.5,p.d),0xf1d57e);m.position.y=-.25;m.castShadow=m.receiveShadow=true;g.add(m);for(const dx of [-1,1]){const stripe=this.mesh(new THREE.BoxGeometry(.16,.03,p.d),0xffffff);stripe.position.set(dx*(p.w/2-.2),.02,0);g.add(stripe);}g.position.z=p.z;this.animated.push({object:g,data:p});}
    for(const w of hole.walls){const g=new THREE.Group();g.position.set(w.x,w.h/2,w.z);this.world.add(g);const m=this.mesh(new THREE.BoxGeometry(w.w,w.h,w.d),0xf28378);m.castShadow=true;g.add(m);for(let x=-w.w/2+.6;x<w.w/2;x+=1.2){const m=this.mesh(new THREE.BoxGeometry(.25,w.h,.03),0xffdb9c);m.rotation.z=.3;m.position.set(x,0,-w.d/2-.02);g.add(m);}this.animated.push({object:g,data:w});this.box(w.w+12,.08,.2,0x5c6c6b,0,.03,w.z);}
    for(const r of hole.ramps){const vertices=[-r.w/2,0,-r.d/2,r.w/2,0,-r.d/2,-r.w/2,r.h,r.d/2,r.w/2,0,-r.d/2,r.w/2,r.h,r.d/2,-r.w/2,r.h,r.d/2];const geo=new THREE.BufferGeometry();geo.setAttribute('position',new THREE.Float32BufferAttribute(vertices,3));geo.computeVertexNormals();this.add(geo,0xefe2a2,r.x,.02,r.z,{side:THREE.DoubleSide});for(const dx of [-1,1]){const rail=this.box(.15,.2,Math.hypot(r.d,r.h),0xf5a66d,r.x+dx*r.w/2,r.h/2,r.z);rail.rotation.x=-Math.atan2(r.h,r.d);}}
    for(const b of hole.bouncers){this.disc(b.rx+.2,b.rz+.2,0xffffff,b.x,.09,b.z);this.disc(b.rx,b.rz,0xd588e9,b.x,.1,b.z);for(let i=0;i<3;i++)this.box(.15,.02,b.rz*1.5,0xf8dcff,b.x-1+i,.12,b.z);}
    for(const f of hole.fans){this.box(.5,2,.5,0x71829a,f.x,1,f.z);const fan=new THREE.Group();fan.position.set(f.x,2.8,f.z);fan.rotation.y=Math.PI/2;this.world.add(fan);const cage=this.mesh(new THREE.TorusGeometry(1.6,.1,8,32),0xe4f2eb);fan.add(cage);const blades=new THREE.Group();fan.add(blades);for(let i=0;i<4;i++){const blade=this.mesh(new THREE.BoxGeometry(.4,1.4,.15),0x86bddc);blade.position.set(Math.sin(i*Math.PI/2)*.65,Math.cos(i*Math.PI/2)*.65,0);blade.rotation.z=-i*Math.PI/2;blades.add(blade);}this.fans.push(blades);}
    for(const t of hole.tunnels){for(const dx of [-1,1])this.box(.8,t.h,t.d,0x93a8a3,t.x+dx*(t.w/2+.4),t.h/2,t.z);this.box(t.w+1.6,.5,t.d,0xc4cebb,t.x,t.h+.25,t.z);for(const z of [-1,1]){this.box(t.w+1.7,.18,.2,0xffdd88,t.x,t.h+.53,t.z+z*t.d/2);}}
    for(const l of hole.loops){const ring=this.add(new THREE.TorusGeometry(l.r,.32,10,60),0xffca75,l.x,l.r,l.z);ring.rotation.y=Math.PI/2;for(const dx of [-1,1]){const rail=this.add(new THREE.TorusGeometry(l.r,.08,8,60),0xffffff,l.x+dx*.8,l.r,l.z);rail.rotation.y=Math.PI/2;}}
    for(const s of hole.shortcuts){const arch=this.add(new THREE.TorusGeometry(1.5,.18,10,40,Math.PI),0xe4c06c,s.x,1,s.z,{emissive:0x9b6510,emissiveIntensity:.5});arch.rotation.z=0;for(const dx of [-1,1])this.box(.25,1,.25,0xe4c06c,s.x+dx*1.5,.5,s.z);this.disc(1.4,1.4,0xecd58d,s.x,.09,s.z);}
    buildForest(this,hole);buildMayhem(this,hole);buildSurroundings(this,hole);buildSecrets(this,hole);
    this.swingTime=0;this.camera.position.set(52,55,-24);this.target.set(0,0,hole.length*.45);this.camera.lookAt(this.target);
  }
  decorate(x,z,scale,type,rng){
    if(type==='palm'){
      const trunk=this.add(new THREE.CylinderGeometry(.16,.3,4*scale,8),0xa88a65,x,2*scale,z);trunk.rotation.z=.1;
      for(let j=0;j<6;j++){const leaf=this.add(new THREE.ConeGeometry(.6,3.4*scale,4),0x398f72,x,4*scale,z);leaf.rotation.z=1;leaf.rotation.y=j*Math.PI/3;leaf.position.x+=Math.cos(j*Math.PI/3)*1.1;leaf.position.z+=Math.sin(j*Math.PI/3)*1.1;}
    }else if(type==='cactus'){
      this.add(new THREE.CapsuleGeometry(.36*scale,2.8*scale,4,8),0x6b9977,x,1.7*scale,z);
      for(const dx of [-1,1]){const arm=this.add(new THREE.CapsuleGeometry(.23*scale,1.1*scale,4,8),0x76a07b,x+dx*.65*scale,1.8*scale,z);arm.rotation.z=dx*.9;}
    }else if(type==='crystal'||type==='neon'){
      const m=this.add(new THREE.OctahedronGeometry(1.2*scale,0),type==='neon'?0xbe8bf9:0xd5dbee,x,1.3*scale,z,{emissive:type==='neon'?0x8344b8:0x000000,emissiveIntensity:.8});m.scale.y=2;this.trees.push(m);
    }else if(type==='volcano'){
      const m=this.add(new THREE.DodecahedronGeometry(1.5*scale,0),0x55535b,x,.8,z);m.scale.y=1.4;this.add(new THREE.ConeGeometry(.4,1.6,5),0xe99b5e,x,1.8,z,{emissive:0xff4200,emissiveIntensity:.4});
    }else{
      this.add(new THREE.CylinderGeometry(.18*scale,.3*scale,2.5*scale,7),0x9c8360,x,1.25*scale,z);
      const tree=this.add(new THREE.IcosahedronGeometry(1.65*scale,1),[0x619d65,0x80b776,0xa3bf70][Math.floor(rng()*3)],x,3.2*scale,z);tree.scale.y=1.3;this.trees.push(tree);
      this.add(new THREE.IcosahedronGeometry(1.1*scale,0),0x84ae6a,x+.6*scale,2.5*scale,z+.3);
    }
  }
  setCosmetics(ball,outfit){this.ball.material.color.set(ball);for(const piece of this.shirtPieces||[])piece.material.color.set(outfit);}
  setClub(id){if(!this.clubHead)return;this.clubHead.scale.set(...(id==='driver'?[.13,.07,.095]:id==='putter'?[.035,.035,.13]:[.08,.055,.065]));}
  setCharge(amount){this.chargeAmount=amount;}
  startReaction(data){beginReactionScene(this,data);}
  stopReaction(){endReactionScene(this);}
  clearPath(){this.disposeGroup(this.path);}
  showPath(points,partial=false){this.clearPath();const geometry=new THREE.SphereGeometry(.04,6,5),mat=new THREE.MeshBasicMaterial({color:0xffffff,transparent:true,opacity:.65});for(let i=0;i<Math.min(70,points.length);i++){const p=points[i];const dot=new THREE.Mesh(geometry,mat);dot.position.set(p.x,Math.max(.06,p.y),p.z);this.path.add(dot);}if(points.length&&!partial){const p=points.at(-1),ring=this.mesh(new THREE.RingGeometry(.20,.23,28),0xffffff,{transparent:true,opacity:.55,depthTest:false});ring.rotation.x=-Math.PI/2;ring.position.set(p.x,.02,p.z);this.path.add(ring);}}
  swing(){this.swingTime=1.15;this.trail=[];}
  defeat(){this.failure=true;this.swingTime=0;}
  celebrate(x,z,scale=1){if(this.settings.reducedMotion)return;this.celebration=3;for(let i=0;i<90*scale;i++){const m=this.mesh(i%5===0?new THREE.CylinderGeometry(.1,.1,.035,10):new THREE.BoxGeometry(.13,.25,.07),i%5===0?0xffd574:[0xd0fa71,0xffb582,0xf5f8ef,0xad9ee7][i%4]);m.position.set(x,.8,z);this.scene.add(m);this.particles.push({mesh:m,v:new THREE.Vector3((Math.random()-.5)*10,4+Math.random()*10,(Math.random()-.5)*10),life:2+Math.random()});}}
  draw(ball,angle,time,dt,{home=false,moving=false,replay=false}={}){
    if(!this.hole)return;
    animateMayhem(this,ball,time);
    animateSurroundings(this,ball,time);
    animateReactionScene(this,dt);
    this.ball.position.set(ball.x,ball.y,ball.z);this.ball.rotation.x+=moving?(ball.vz||0)/RADIUS*dt:0;this.ball.rotation.z-=moving?(ball.vx||0)/RADIUS*dt:0;
    if(moving){this.trail.push(this.ball.position.clone());if(this.trail.length>25)this.trail.shift();this.trailLine.geometry.dispose();this.trailLine.geometry=new THREE.BufferGeometry().setFromPoints(this.trail);}this.trailLine.visible=moving&&ball.y>.8;
    this.ballRing.position.set(ball.x,terrainAt(this.hole,ball.x,ball.z,time).height+.012,ball.z);this.ballRing.visible=!moving&&!ball.sunk&&!home;
    this.ballRing.scale.setScalar(1+Math.sin(time*3)*.08);
    const gx=moving?(ball.safe?.x??ball.x):ball.x,gz=moving?(ball.safe?.z??ball.z):ball.z;
    this.golfer.position.set(gx-Math.cos(angle)*1.06,moving?terrainAt(this.hole,gx,gz,time).height:ball.y-RADIUS,gz+Math.sin(angle)*1.06);this.golfer.rotation.y=angle;this.golfer.visible=!replay;
    if(this.swingTime>0){this.swingTime=Math.max(0,this.swingTime-dt);const t=1-this.swingTime/1.15;this.golferTorso.rotation.y=Math.sin(t*Math.PI)*1.05;this.clubGroup.rotation.x=-Math.sin(t*Math.PI)*1.9;this.clubGroup.rotation.z=-Math.sin(t*Math.PI)*.3;}else if(this.chargeAmount>0){this.golferTorso.rotation.y=-this.chargeAmount*.75;this.clubGroup.rotation.x=this.chargeAmount*1.25;this.clubGroup.rotation.z=-this.chargeAmount*.2;}else{this.golferTorso.rotation.y=Math.sin(time*.7)*.015;this.clubGroup.rotation.set(0,0,0);}
    if(this.celebration>0){this.celebration-=dt;this.golferTorso.rotation.y=.2;this.clubGroup.rotation.z=-.5;}
    if(this.failure){this.golferTorso.rotation.x=.28;this.golferTorso.rotation.z=this.settings.reducedMotion?0:Math.sin(time*6)*.04;this.clubGroup.rotation.z=-.8;}
    const flagPositions=this.flag.geometry.attributes.position;for(let i=0;i<flagPositions.count;i++){const x=this.flagRest[i*3]+.35;flagPositions.setZ(i,Math.sin(time*3.2-x*9)*x*.13+Math.sin(time*1.7+x*5)*x*.05);}flagPositions.needsUpdate=true;this.flag.geometry.computeVertexNormals();
    for(const spectator of this.spectators||[])spectator.torsoPivot.rotation.y=Math.sin(time*.65)*.04;
    if(this.water.length){const map=grainTexture('water');map.offset.set(time*.008,time*.004);}
    for(const a of this.animated)a.object.position.x=movingX(a.data,time);
    for(const fan of this.fans)fan.rotation.z-=dt*9;
    for(const [i,t] of this.trees.entries())t.rotation.z=Math.sin(time+i)*.025;
    for(let i=this.particles.length-1;i>=0;i--){const p=this.particles[i];p.life-=dt;p.v.y-=9*dt;p.mesh.position.addScaledVector(p.v,dt);p.mesh.rotation.z+=dt*4;if(p.life<0){this.scene.remove(p.mesh);p.mesh.geometry.dispose();p.mesh.material.dispose();this.particles.splice(i,1);}}
    const pos=new THREE.Vector3(),target=new THREE.Vector3();
    if(this.reactionCamera){pos.copy(this.reactionCamera.position);target.copy(this.reactionCamera.target);}
    else if(home){const a=this.settings.reducedMotion?.62:.62+Math.sin(time*.045)*.035;pos.set(Math.sin(a)*61,31,-Math.cos(a)*35+this.hole.length*.10);target.set(0,.5,this.hole.length*.46);}
    else if(this.cameraMode==='world'){pos.set(78,62,-36+this.hole.length*.15);target.set(0,1,this.hole.length*.55);}
    else if(this.cameraMode==='map'){
      const minZ=Math.min(-7,ball.z-5),maxZ=Math.max(this.hole.length+10,ball.z+5),minX=Math.min(-this.hole.width/2,ball.x-5),maxX=Math.max(this.hole.width/2,ball.x+5);
      const midZ=(minZ+maxZ)/2,midX=(minX+maxX)/2,height=Math.max(65,(maxZ-minZ)*1.25,(maxX-minX)*1.25/this.camera.aspect);
      if(this.camera.far<height+150){this.camera.far=height+150;this.camera.updateProjectionMatrix();}
      pos.set(midX,height,midZ-.1);target.set(midX,0,midZ);
    }
    else {
      if(moving&&!this.wasMoving)this.flightHeading=angle;const a=(moving?this.flightHeading:angle)+this.orbit;
      const distance=Math.hypot(ball.x-this.hole.cup.x,ball.z-this.hole.cup.z),zoom=distance<13?5.8:11.5;
      pos.set(ball.x-Math.sin(a)*zoom+Math.cos(a)*.45,Math.max(ball.y,0)+(moving?5.8:distance<13?2.9:5.2),ball.z-Math.cos(a)*zoom-Math.sin(a)*.45);
      const lead=moving?3:distance<13?.8:2.5;target.set(ball.x+Math.sin(a)*lead,Math.max(ball.y*.8,.1),ball.z+Math.cos(a)*lead);
    }
    this.wasMoving=moving;const ease=this.settings.reducedMotion?1:1-Math.exp(-dt*(home?2:moving?3:5));this.camera.position.lerp(pos,ease);this.target.lerp(target,ease);this.camera.lookAt(this.target);
    const shadowTick=Math.floor(time*6);if(shadowTick!==this.shadowTick){this.renderer.shadowMap.needsUpdate=true;this.shadowTick=shadowTick;}
    this.renderer.render(this.scene,this.camera);
  }
  groundPoint(clientX,clientY){const r=this.canvas.getBoundingClientRect();const pointer=new THREE.Vector2((clientX-r.left)/r.width*2-1,-(clientY-r.top)/r.height*2+1);const ray=new THREE.Raycaster();ray.setFromCamera(pointer,this.camera);return ray.intersectObjects(this.groundMeshes||[],false)[0]?.point||ray.ray.intersectPlane(new THREE.Plane(UP,0),new THREE.Vector3());}
  quality(value){this.renderer.setPixelRatio(Math.min(devicePixelRatio,value==='low'?1:1.8));this.renderer.shadowMap.enabled=value!=='low';this.resize();}
}
