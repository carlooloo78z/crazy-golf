import * as THREE from '../vendor/three.module.min.js';
export function buildSecrets(view,hole){
 for(const s of hole.secrets){
  const x=s.x,y=s.y,z=s.z;
  if(s.type==='nest'||s.type==='cloud'){
   if(s.type==='cloud'){const stone=view.add(new THREE.OctahedronGeometry(1,0),0xa6b2bd,x,y-1,z+.3);stone.scale.set(.75,2,.75);}
   const ring=view.add(new THREE.TorusGeometry(s.r,.095,7,18),0x716145,x,y,z);ring.rotation.x=.15;
   const hollow=view.add(new THREE.CircleGeometry(s.r,24),0x1c2117,x,y,z-.03,{side:THREE.DoubleSide});hollow.rotation.y=Math.PI;
   for(let i=0;i<5;i++){const a=i*1.25,twig=view.box(.045,.045,.65,0x8c7954,x+Math.cos(a)*.28,y-.3,z+Math.sin(a)*.2);twig.rotation.z=a;twig.rotation.y=a;}
   const feather=view.add(new THREE.SphereGeometry(1,8,6),s.course==='tropical'?0x6295ab:0xc9c2a5,x+.48,y-.27,z-.1);feather.scale.set(.035,.18,.065);feather.rotation.z=-.4;
  }else if(s.type==='skull'){
   const skull=view.add(new THREE.SphereGeometry(1,12,8),0xcfc7a9,x,y+.18,z+.12);skull.scale.set(.65,.42,.44);
   for(const side of [-1,1]){view.add(new THREE.SphereGeometry(.13,8,6),0x373328,x+side*.27,y+.32,z-.26);const horn=view.add(new THREE.ConeGeometry(.1,.75,8),0xb5a98c,x+side*.62,y+.4,z+.1);horn.rotation.z=-side*.95;}
   view.add(new THREE.CircleGeometry(.36,20),0x29291f,x,y,z-.32).rotation.y=Math.PI;
   view.decorate(x+.9,z+1,.65,'cactus',()=>.5);
  }else if(s.type==='vent'){
   for(let i=0;i<3;i++){const a=i*2.1;view.add(new THREE.DodecahedronGeometry(.45,0),0x575352,x+Math.cos(a)*.53,y-.1,z+Math.sin(a)*.53);}
   view.disc(.48,.48,0x212324,x,.08,z);for(let i=0;i<3;i++){const smoke=view.add(new THREE.SphereGeometry(.18+i*.08,8,6),0xa19b8f,x+.06*i,y+.6+i*.36,z,{transparent:true,opacity:.14,depthWrite:false});smoke.scale.y=.5;}
  }else{
   view.box(1.3,1.7,.32,0x232936,x,.85,z+.3);view.box(.76,.78,.035,0x151b26,x,y,z+.11);view.box(.035,.035,.06,0x837099,x+.36,y+.34,z+.07);
  }
 }
}
export function beginReactionScene(view,data){
 // A cutaway beside the tee keeps every close-up clear of trees and moving obstacles.
 endReactionScene(view);const root=new THREE.Group(),actor=new THREE.Group();root.position.set(0,.2,6);root.add(actor);view.scene.add(root);
 const wingParts=[],eyebrows=[],claws=[],kind=data.kind,angry=kind==='bird',duck=kind==='duck',crab=kind==='crab';
 const part=(geometry,color,x,y,z,sx=1,sy=1,sz=1,parent=actor)=>{const m=view.mesh(geometry,color);m.position.set(x,y,z);m.scale.set(sx,sy,sz);parent.add(m);return m;},sphere=new THREE.SphereGeometry(1,20,14);
 if(crab){
  part(sphere,0xc76d43,0,.35,0,.55,.22,.35);
  for(const side of [-1,1]){part(new THREE.CylinderGeometry(.035,.035,.4,8),0xdf8b63,side*.24,.65,-.15);part(sphere,0xf7edd9,side*.24,.88,-.15,.12,.12,.12);part(sphere,0x172a29,side*.24,.88,-.25,.05,.06,.04);const claw=new THREE.Group();claw.position.set(side*.7,.5,-.15);actor.add(claw);part(sphere,0xe08b54,0,0,0,.23,.17,.2,claw);for(const dz of [-1,1])part(new THREE.ConeGeometry(.09,.28,8),0xecaf72,side*.08,.12,dz*.1,1,1,1,claw);claws.push(claw);for(let i=0;i<3;i++){const leg=part(new THREE.CylinderGeometry(.035,.035,.65,7),0xbf764b,side*.5,.18,-.2+i*.2);leg.rotation.z=side*.9;}}
 }else{
  part(sphere,duck?0xd9cc9d:angry?0x81945b:0xb8a36b,0,.54,.03,.4,.48,.38);part(sphere,duck?0x36735d:angry?0xa4b776:0xe7dcb4,0,1.12,-.13,.34,.33,.31);part(sphere,0xe9dfb9,0,.53,-.27,.28,.33,.13);
  part(new THREE.ConeGeometry(.16,.38,4),0xeeb350,0,1.05,-.56).rotation.x=-Math.PI/2;
  for(const side of [-1,1]){part(sphere,0xf7f5dd,side*.16,1.22,-.38,.125,.14,.075);part(sphere,0x172824,side*.16,1.2,-.44,.047,.066,.035);const brow=part(new THREE.BoxGeometry(.25,.055,.065),0x354431,side*.16,1.39,-.42);brow.rotation.z=side*(angry?.4:-.15);eyebrows.push(brow);const wing=new THREE.Group();wing.position.set(side*.35,.75,0);actor.add(wing);part(sphere,duck?0xa2986c:0x667b4c,side*.16,-.12,.02,.2,.43,.18,wing);wingParts.push(wing);part(new THREE.BoxGeometry(.2,.06,.3),0xdb9a42,side*.16,.065,-.12);}
  if(kind==='secret')part(new THREE.SphereGeometry(.09,16,12),0xffffff,0,.92,-.73);
 }
 const stage=view.mesh(new THREE.CircleGeometry(1.5,40),crab?0xbaa47c:0x657b49,{transparent:true,opacity:.7});stage.rotation.x=-Math.PI/2;root.add(stage);
 view.reactionScene={root,actor,wingParts,eyebrows,claws,data,age:0};
 animateReactionScene(view,0);view.camera.position.copy(view.reactionCamera.position);view.target.copy(view.reactionCamera.target);view.camera.lookAt(view.target);
}
export function animateReactionScene(view,dt){
 const r=view.reactionScene;if(!r)return;const t=r.age+=dt,reduced=view.settings.reducedMotion;
 r.actor.position.y=reduced?0:Math.abs(Math.sin(t*(r.data.kind==='bird'?9:5)))*(r.data.kind==='secret'?.18:.07);
 r.actor.rotation.y=reduced?0:Math.sin(t*3)*.12;r.actor.rotation.x=reduced?0:Math.sin(t*6)*(r.data.kind==='bird'?.22:.08);
 for(let i=0;i<r.wingParts.length;i++)r.wingParts[i].rotation.z=reduced?0:(i?-1:1)*(.55+Math.sin(t*13)*.45);
 for(let i=0;i<r.claws.length;i++)r.claws[i].rotation.z=reduced?0:Math.sin(t*8+i)*.5;
 const p=r.root.position;view.reactionCamera={position:new THREE.Vector3(p.x+1.7,p.y+1.5,p.z-4.2),target:new THREE.Vector3(p.x,p.y+.8,p.z)};
}
export function endReactionScene(view){if(view.reactionScene){view.disposeGroup(view.reactionScene.root);view.scene.remove(view.reactionScene.root);}view.reactionScene=null;view.reactionCamera=null;}
