import test from 'node:test';
import assert from 'node:assert/strict';
import {makeHole,COURSES} from '../src/courses.js';
import {createBall,strike,stepBall,predict,STEP,RADIUS} from '../src/physics.js';
import {applyMayhem,gravityMultiplier} from '../src/mayhem.js';
import {rewardBreakdown,loadProgress,SAVE_KEY} from '../src/progress.js';
import {solveShot} from './solver.mjs';

const cleanHole=()=>{const h=makeHole('classic',0);h.wind={x:0,z:0};for(const key of ['walls','ramps','sand','water','fans','loops','shortcuts','bouncers'])h[key]=[];return h;};
function flight(style,powerUp=null){const h=cleanHole(),b=createBall();strike(b,h,{club:'iron',power:.65,angle:0,loft:40,style,powerUp});for(let i=0;i<90;i++)stepBall(b,h,STEP,i*STEP);return b;}

test('chaos layouts are deterministic, remixable, and preserve tees and cups',()=>{
 for(const c of COURSES){const h=makeHole(c.id,8,{chaos:'mayhem',remix:3});assert.deepEqual(h,makeHole(c.id,8,{chaos:'mayhem',remix:3}));assert.notDeepEqual(h.coinRings,makeHole(c.id,8,{chaos:'mayhem',remix:4}).coinRings);assert.deepEqual(h.cup,makeHole(c.id,8).cup);assert.equal(h.boosts.length,1);assert.equal(h.bumpers.length,2);assert.equal(h.gravityZones.length,1);assert.equal(h.tornadoes.length,1);assert.equal(h.coinRings.length,4);}
 assert.equal(makeHole('classic',0).boosts.length,0);
});
test('shot shapes bend in opposite directions, punch lowers flight, and rocket adds speed',()=>{
 const straight=flight('straight'),draw=flight('draw'),fade=flight('fade'),punch=flight('punch'),spin=flight('backspin'),rocket=flight('straight','rocket');
 assert.ok(draw.x<straight.x-.15);assert.ok(fade.x>straight.x+.15);assert.ok(punch.y<straight.y);assert.ok(spin.y>straight.y);assert.ok(rocket.z>straight.z+2);
 const b=createBall();strike(b,cleanHole(),{club:'putter',style:'draw',loft:0});assert.equal(b.sideSpin,0);
});
test('bubble rescues a hazard at the original lie and regular shots still incur hazards',()=>{
 for(const powerUp of ['shield',null]){const h=cleanHole(),b=createBall();h.water=[{x:8,z:2,rx:3,rz:3}];strike(b,h,{club:'driver',power:1,angle:Math.PI/2,loft:0,powerUp});for(let i=0;i<3000&&b.moving;i++)stepBall(b,h,STEP,i*STEP);assert.equal(b.x,0);assert.equal(b.z,2);assert.ok(b.events.includes(powerUp?'shield-save':'hazard'));assert.equal(b.events.includes('hazard'),!powerUp);}
});
test('boosts launch once per shot and pinball bumpers reflect away from contact',()=>{
 const h=cleanHole(),b=createBall(0,10);h.boosts=[{id:'boost',x:0,z:10,w:3,d:4,kick:9}];applyMayhem(b,h,STEP,RADIUS);const vz=b.vz;applyMayhem(b,h,STEP,RADIUS);assert.equal(b.vz,vz);assert.equal(b.events.filter(e=>e==='boost').length,1);assert.ok(b.vy>0);
 h.boosts=[];h.bumpers=[{id:'bumper',x:0,z:10,r:1,h:2,kick:5}];Object.assign(b,{x:0,z:9,vz:8});applyMayhem(b,h,STEP,RADIUS);assert.ok(b.vz<0);assert.ok(b.events.includes('bumper'));
});
test('moon gravity, twister lift, and cup magnet change the real physics',()=>{
 const h=cleanHole(),b=createBall(0,10);b.y=1;h.gravityZones=[{id:'moon',x:0,z:10,r:4,height:9}];assert.equal(gravityMultiplier(b,h),.3);b.x=7;assert.equal(gravityMultiplier(b,h),1);
 h.tornadoes=[{id:'twister',x:7,z:10,r:4,height:10,strength:6}];applyMayhem(b,h,STEP,RADIUS);assert.ok(b.vy>0);assert.ok(b.events.includes('tornado'));
 const m=createBall(h.cup.x+1.2,h.cup.z-2);strike(m,h,{club:'putter',power:.12,angle:0,loft:0,powerUp:'magnet'});for(let i=0;i<2000&&m.moving;i++)stepBall(m,h,STEP,i*STEP);assert.ok(m.sunk,'the magnet should pull a slow nearby putt into the cup');
});
test('rings pay only once per hole and shot previews never collect real rewards',()=>{
 const h=cleanHole(),b=createBall();h.coinRings=[{id:'ring-0',x:0,y:RADIUS,z:2,r:1.3}];const p=predict(b,h,{club:'putter',power:.1,angle:0,loft:0});assert.ok(p.ball.collectedRings.includes('ring-0'));assert.deepEqual(b.collectedRings,[]);
 applyMayhem(b,h,STEP,RADIUS);applyMayhem(b,h,STEP,RADIUS);assert.deepEqual(b.events,['ring:ring-0']);strike(b,h,{club:'putter',power:.1,angle:0,loft:0});applyMayhem(b,h,STEP,RADIUS);assert.deepEqual(b.events,[]);assert.deepEqual(b.collectedRings,['ring-0']);
});
test('every fewer-stroke finish earns more and bonuses add up exactly',()=>{
 for(const par of [3,4,5]){let previous=Infinity;for(let strokes=1;strokes<=par+5;strokes++){const r=rewardBreakdown(strokes,par);assert.ok(r.total<previous);previous=r.total;}}
 assert.equal(rewardBreakdown(1,3,{clean:true}).total,605);
 assert.equal(rewardBreakdown(2,4).base,220);assert.equal(rewardBreakdown(3,4).base,120);assert.equal(rewardBreakdown(4,4).base,50);
 const r=rewardBreakdown(2,4,{combo:1.75,clean:true,tricks:3});assert.equal(r.total,r.base+r.efficiency+r.clean+r.tricks+r.streak);assert.equal(r.tricks,105);assert.equal(r.clean,25);assert.equal(rewardBreakdown(5,4,{clean:true,tricks:10,combo:99}).tricks,175);assert.equal(rewardBreakdown(5,4,{clean:true}).clean,0);assert.ok(r.xp>rewardBreakdown(4,4).xp);
});
test('existing progress loads with new statistics without losing coins or equipment',()=>{
 const old={version:1,coins:123,xp:45,stats:{holes:9},equipped:{ball:'sunshine'}};const p=loadProgress({getItem:key=>key===SAVE_KEY?JSON.stringify(old):null});assert.equal(p.coins,123);assert.equal(p.stats.holes,9);assert.equal(p.stats.rings,0);assert.equal(p.stats.powers,0);assert.equal(p.equipped.ball,'sunshine');
});
test('all 216 Wild and Mayhem layouts can be completed with legal shots',()=>{
 let count=0,max=0;
 for(const chaos of ['wild','mayhem'])for(const c of COURSES)for(let i=0;i<18;i++){
  const hole=makeHole(c.id,i,{chaos}),ball=createBall(hole.tee.x,hole.tee.z);let time=0,strokes=0;
  while(!ball.sunk&&strokes<10){const shot=solveShot(ball,hole,time);assert.ok(shot);strike(ball,hole,shot);strokes++;for(let j=0;j<3600&&ball.moving;j++){time+=STEP;stepBall(ball,hole,STEP,time);}}
  assert.ok(ball.sunk,chaos+' '+c.id+' hole '+(i+1)+' must be playable');count++;max=Math.max(max,strokes);
 }
 console.log(count+' chaos layouts completed; maximum '+max+' strokes.');
});
