import {arenaCommand,ArenaError} from './arena.js';
const json=(data,status=200)=>new Response(JSON.stringify(data),{status,headers:{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'}});
const hash=async token=>Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(token))),n=>n.toString(16).padStart(2,'0')).join('');
export function arenaApi(store,{scope='local',clock=Date.now}={}){
 return async request=>{
  try{
   const url=new URL(request.url),action=url.pathname.split('/').at(-1),get=['state','status'].includes(action);
   if(!['session','status','state','join','leave','shot','next'].includes(action))return json({error:'Unknown matchmaking action.'},404);
   if(request.method!==(get?'GET':'POST'))return json({error:'Method not allowed.'},405);
   const origin=request.headers.get('Origin');if(origin&&origin!==url.origin)return json({error:'Use the game on this server to join.'},403);
   let body={};if(!get){if(!request.headers.get('Content-Type')?.startsWith('application/json'))return json({error:'JSON required.'},415);const raw=await request.text();if(raw.length>16384)return json({error:'Request is too large.'},413);try{body=JSON.parse(raw);}catch{return json({error:'Invalid JSON.'},400);}if(!body||typeof body!=='object'||Array.isArray(body))return json({error:'Invalid request.'},400);}
   const token=action==='session'?crypto.randomUUID()+crypto.randomUUID():request.headers.get('Authorization')?.replace(/^Bearer /,'');
   if(action!=='status'&&(!token||token.length!==72))return json({error:'Reconnect to the clubhouse.'},401);
   const key=token?await hash(token):null;
   const result=await store.transaction(state=>arenaCommand(state,action,body,key,clock()));
   return json({...result,scope,...(action==='session'?{token}:{})});
  }catch(error){return json({error:error instanceof ArenaError?error.message:'The clubhouse is temporarily unavailable. Retrying is safe.'},error instanceof ArenaError?error.status:503);}
 };
}
