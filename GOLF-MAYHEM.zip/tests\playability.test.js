import test from 'node:test';
import assert from 'node:assert/strict';
import {COURSES,makeHole} from '../src/courses.js';
import {createBall,strike,stepBall,STEP} from '../src/physics.js';
import {solveShot} from './solver.mjs';

test('all 108 holes can be completed through the shot physics',()=>{
 let worst=0,total=0;const failures=[];
 for(const course of COURSES)for(let index=0;index<18;index++){
  const hole=makeHole(course.id,index),ball=createBall(),max=16;let time=0,shots=0;
  while(!ball.sunk&&shots<max){const shot=solveShot(ball,hole,time);strike(ball,hole,{...shot,time});while(ball.moving){stepBall(ball,hole,STEP,time);time+=STEP;}shots++;}
  if(!ball.sunk)failures.push(`${course.id}/${index+1}: ${Math.hypot(ball.x-hole.cup.x,ball.z-hole.cup.z).toFixed(1)}m remaining`);worst=Math.max(worst,shots);total+=shots;
 }
 assert.deepEqual(failures,[]);console.log(`108 holes completed with real shots; ${total} strokes, longest ${worst} strokes.`);
});
