import { CLUBS, terrainAt, movingX } from './courses.js';
import {SHOT_STYLES,applyMayhem,gravityMultiplier} from './mayhem.js';
import {stepWildlife,addReaction} from './wildlife.js';
export const RADIUS=.06;
export const GRAVITY=9.81;
export const STEP=1/120;
export function createBall(x=0,z=2){return {x,y:RADIUS,z,vx:0,vy:0,vz:0,moving:false,sunk:false,airtime:0,rest:0,age:0,events:[],loop:null,teleported:false,safe:{x,z},collectedRings:[],stunts:[],powerUp:null};}
export function strike(ball,hole,{club='driver',power=.65,angle=0,loft=CLUBS[club].loft,time=0,style='straight',powerUp=null}) {
  if(ball.moving||ball.sunk)return false;
  const terrain=terrainAt(hole,ball.x,ball.z,time), penalty=terrain.type==='sand'?.7:terrain.type==='rough'?.86:1;
  style=club==='putter'||!SHOT_STYLES.some(s=>s.id===style)?'straight':style;
  const speed=CLUBS[club].speed*Math.max(.02,Math.min(1,power))*penalty*(powerUp==='rocket'?1.25:1)*(style==='backspin'?.93:style==='punch'?1.04:1), rad=(style==='punch'?Math.min(20,loft*.5):style==='backspin'?Math.min(72,loft+8):loft)*Math.PI/180;
  ball.safe={x:ball.x,z:ball.z}; ball.vx=Math.sin(angle)*Math.cos(rad)*speed;ball.vz=Math.cos(angle)*Math.cos(rad)*speed;ball.vy=Math.sin(rad)*speed;
  ball.moving=true;ball.age=0;ball.rest=0;ball.airtime=0;ball.teleported=false;ball.events=[];ball.reactions=[];ball.lastTree=null;ball.lastTreeTime=0;ball.stunts=[];ball.powerUp=powerUp;ball.shieldUsed=false;ball.sideSpin=style==='draw'?-1:style==='fade'?1:0;ball.backspin=style==='backspin'?.9:style==='punch'?0:club==='wedge'?.45:club==='iron'?.18:club==='driver'?.08:0;
  return true;
}
function wallCollision(ball,wall,time) {
  const x=wall.amplitude?movingX(wall,time):wall.x;
  if(ball.y-RADIUS>wall.h)return;
  const hx=wall.w/2+RADIUS,hz=wall.d/2+RADIUS,dx=ball.x-x,dz=ball.z-wall.z;
  if(Math.abs(dx)<hx&&Math.abs(dz)<hz){
    if(hx-Math.abs(dx)<hz-Math.abs(dz)){ball.x=x+Math.sign(dx||1)*hx;ball.vx=Math.sign(dx||1)*Math.abs(ball.vx)*.75;}
    else {ball.z=wall.z+Math.sign(dz||1)*hz;ball.vz=Math.sign(dz||1)*Math.abs(ball.vz)*.75;}
    ball.events.push('wall');
  }
}
function captureCup(ball,hole,previous){
  // Check the entire path through the opening, before the green can bounce
  // an incoming shot. Clip its height first so high flyovers remain airborne.
  const bottom=-RADIUS,top=.22,dy=ball.y-previous.y;
  let start=0,end=1;
  if(Math.abs(dy)<1e-9){if(previous.y<bottom||previous.y>top)return false;}
  else {
    const a=(bottom-previous.y)/dy,b=(top-previous.y)/dy;
    start=Math.max(0,Math.min(a,b));end=Math.min(1,Math.max(a,b));
    if(start>end)return false;
  }
  const dx=ball.x-previous.x,dz=ball.z-previous.z,x=previous.x-hole.cup.x,z=previous.z-hole.cup.z,length=dx*dx+dz*dz;
  const t=length?Math.max(start,Math.min(end,-(x*dx+z*dz)/length)):start,r=hole.cupRadius||.30;
  if((x+dx*t)**2+(z+dz*t)**2>r*r)return false;
  ball.x=hole.cup.x;ball.z=hole.cup.z;ball.y=-.15;ball.vx=ball.vy=ball.vz=0;ball.sunk=true;ball.moving=false;ball.events.push('cup');
  return true;
}
export function stepBall(ball,hole,dt=STEP,time=0) {
  if(!ball.moving||ball.sunk)return;
  ball.age+=dt;
  if(ball.loop){
    const loop=ball.loop;loop.progress+=dt*loop.speed/loop.r;
    ball.x=loop.x;ball.z=loop.z+Math.sin(loop.progress)*loop.r;ball.y=RADIUS+loop.r*(1-Math.cos(loop.progress));
    if(loop.progress>=Math.PI*2){ball.z=loop.z+loop.r+.6;ball.y=RADIUS+.2;ball.vx=0;ball.vz=loop.speed*.9;ball.vy=2;ball.loop=null;ball.events.push('loop');}return;
  }
  const before=terrainAt(hole,ball.x,ball.z,time), grounded=ball.y<=before.height+RADIUS+.025&&ball.vy<=.1;
  if(!grounded){const rx=ball.vx-hole.wind.x,rz=ball.vz-hole.wind.z,drag=.006*Math.hypot(rx,ball.vy,rz);ball.vx-=rx*drag*dt;ball.vz-=rz*drag*dt;ball.vy-=(GRAVITY*gravityMultiplier(ball,hole)+ball.vy*drag)*dt;ball.vx+=hole.wind.x*.12*dt;ball.vz+=hole.wind.z*.12*dt;const curve=(ball.sideSpin||0)*.048;const vx=ball.vx;ball.vx+=ball.vz*curve*dt;ball.vz-=vx*curve*dt;ball.airtime+=dt;}
  else {
    const speed=Math.hypot(ball.vx,ball.vz),next=Math.max(0,speed-before.friction*dt);
    if(speed){ball.vx*=next/speed;ball.vz*=next/speed;}
    if(before.slope){ball.vz-=GRAVITY*before.slope*dt;ball.vy=Math.max(0,ball.vz*before.slope);}
    if(before.platform)ball.x+=Math.cos(time*before.platform.speed+before.platform.phase)*before.platform.speed*before.platform.amplitude*dt;
  }
  for(const f of hole.fans)if(Math.hypot(ball.x-f.x,ball.z-f.z)<f.radius&&ball.y<7){ball.vx+=f.power*dt;ball.vy+=grounded?0:2*dt;}
  const previous={x:ball.x,y:ball.y,z:ball.z};ball.x+=ball.vx*dt;ball.z+=ball.vz*dt;ball.y+=ball.vy*dt;
  if(captureCup(ball,hole,previous))return;
  if(stepWildlife(ball,hole,previous))return;
  const surface=terrainAt(hole,ball.x,ball.z,time);
  if((surface.type==='water'&&ball.y<surface.height+RADIUS+.27)||(surface.type==='bounds'&&ball.y<RADIUS+.02)||(ball.y< -4&&(['void','bounds'].includes(surface.type)||ball.y<surface.height-4))||ball.age>24){
    if(surface.type==='water'&&hole.courseId!=='volcano')addReaction(ball,'duck',ball.x,surface.height+.25,ball.z);
    const safeSurface=terrainAt(hole,ball.safe.x,ball.safe.z,time),saved=ball.powerUp==='shield'&&!ball.shieldUsed;ball.events.push(saved?'shield-save':'hazard');if(saved)ball.shieldUsed=true;Object.assign(ball,{x:ball.safe.x,z:ball.safe.z,y:safeSurface.height+RADIUS,vx:0,vy:0,vz:0,moving:false,rest:0});
    if(['void','water','bounds'].includes(safeSurface.type)){Object.assign(ball,{x:hole.tee.x,z:hole.tee.z,y:RADIUS});}return;
  }
  if(ball.y<surface.height+RADIUS && surface.type!=='void'){
    ball.y=surface.height+RADIUS;
    if(surface.type==='bounce'&&ball.vy< -1){ball.vy=Math.max(10,Math.abs(ball.vy)*1.05);ball.vz*=1.08;ball.events.push('bounce');}
    else if(surface.type==='ramp'&&ball.vz>0){ball.vy=ball.vz*surface.slope;}
    else if(ball.vy< -1.2){const restitution=surface.type==='sand'?.09:surface.type==='rough'?.16:surface.type==='green'?.28:.23;const retention=(surface.type==='sand'?.42:surface.type==='rough'?.64:.86)-(ball.backspin||0)*.3;ball.vy*=-restitution;ball.vx*=retention;ball.vz*=retention;ball.backspin=(ball.backspin||0)*.4;ball.events.push('bounce-soft');}
    else ball.vy=0;
  }
  for(const wall of hole.walls)wallCollision(ball,wall,time);
  for(const tunnel of hole.tunnels){
    for(const side of [-1,1])wallCollision(ball,{x:tunnel.x+side*(tunnel.w/2+.4),z:tunnel.z,w:.8,d:tunnel.d,h:tunnel.h},time);
    if(Math.abs(ball.x-tunnel.x)<tunnel.w/2&&Math.abs(ball.z-tunnel.z)<tunnel.d/2&&ball.y+RADIUS>tunnel.h&&ball.y-RADIUS<tunnel.h+.5){
      if(ball.vy>0){ball.y=tunnel.h-RADIUS;ball.vy*=-.55;}else{ball.y=tunnel.h+.5+RADIUS;ball.vy=Math.abs(ball.vy)*.3;}
    }
  }
  for(const loop of hole.loops)if(Math.abs(ball.x-loop.x)<1.7&&Math.abs(ball.z-loop.z)<.5&&ball.y<1&&ball.vz>6){ball.loop={...loop,speed:Math.max(12,Math.hypot(ball.vx,ball.vz)),progress:0};return;}
  for(const s of hole.shortcuts)if(!ball.teleported&&Math.hypot(ball.x-s.x,ball.z-s.z)<1.4){ball.x=s.toX;ball.z=s.toZ;ball.vx*=.35;ball.vz*=.35;ball.vy=2;ball.teleported=true;ball.events.push('shortcut');}
  applyMayhem(ball,hole,dt,RADIUS);
  const cupDistance=Math.hypot(ball.x-hole.cup.x,ball.z-hole.cup.z),speed=Math.hypot(ball.vx,ball.vz);
  // Obstacles may reposition the ball; never sweep across a teleport's jump.
  if(captureCup(ball,hole,ball))return;
  if(cupDistance<.43&&ball.y<.15&&speed<1.5){ball.vx+=(hole.cup.x-ball.x)*2*dt;ball.vz+=(hole.cup.z-ball.z)*2*dt;}
  if(speed<.2&&Math.abs(ball.vy)<.2&&grounded&&surface.type!=='void'){ball.rest+=dt;if(ball.rest>.12){ball.moving=false;ball.vx=ball.vy=ball.vz=0;ball.y=surface.height+RADIUS;ball.events.push('rest');if(surface.type==='sand')addReaction(ball,'crab',ball.x,surface.height,ball.z);}}
  else ball.rest=0;
}
export function predict(ball,hole,shot,time=0,steps=1800){
  const copy=createBall(ball.x,ball.z);copy.y=ball.y;copy.collectedRings=[...(ball.collectedRings||[])];copy.foundSecrets=[...(ball.foundSecrets||[])];strike(copy,hole,{...shot,time});
  const points=[];for(let i=0;i<steps;i++){stepBall(copy,hole,STEP,time+i*STEP);if(i%12===0)points.push({x:copy.x,y:copy.y,z:copy.z});if(!copy.moving)break;}
  return {points,ball:copy};
}
