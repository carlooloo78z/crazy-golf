import test from 'node:test';import assert from 'node:assert/strict';
import {makeHole,terrainAt} from '../src/courses.js';import {createBall,strike,stepBall,predict,STEP} from '../src/physics.js';import {SECRETS,stepWildlife} from '../src/wildlife.js';import {chargeValue,swingStrength} from '../src/controls.js';import {solveSecret} from './secret-solver.mjs';

test('secret opening shots tolerate two degrees of aim error and five percentage points of strength error together',()=>{
 const recipes=[['classic','driver',.70,-35,15],['desert','putter',1,40,0],['tropical','iron',.77,32,25],['sky','iron',.75,36,25],['volcano','iron',.76,-38,15],['neon','iron',.70,34,20]];
 for(const [course,club,power,angle,loft] of recipes){
  const hole=makeHole(course,0,{difficulty:'expert',chaos:'wild'});
  for(const dp of [-.05,0,.05])for(const da of [-2,0,2]){
   const shot={club,power:Math.min(1,power+dp),angle:(angle+da)*Math.PI/180,loft};
   assert.ok(predict(createBall(),hole,shot).ball.foundSecrets?.includes(hole.secrets[0].id),`${course}: power offset ${dp}, aim offset ${da}`);
  }
 }
});
test('secret catch zones accept swept near misses at any height and reject distant shots',()=>{
 for(const secret of SECRETS)for(const height of [.06,6,60]){
  const hole=makeHole(secret.course,0),ball=createBall(secret.x+1,secret.z+4);ball.y=height;
  assert.equal(stepWildlife(ball,hole,{x:secret.x+1,y:height,z:secret.z-4}),true,secret.id+' near miss at '+height);
  assert.deepEqual(ball.foundSecrets,[secret.id]);
  assert.equal(stepWildlife(ball,hole,{x:secret.x,y:secret.y,z:secret.z}),false,'Discovery cannot be paid twice');
  const miss=createBall(secret.x+3,secret.z);miss.y=height;
  assert.equal(stepWildlife(miss,hole,{...miss,z:secret.z-1}),false,secret.id+' distant miss');
 }
});
test('ground shots and high flyovers activate all 18 secret placements through the real physics',()=>{
 for(const secret of SECRETS)for(const index of [0,6,12])for(const height of [.06,12,60]){
  const hole=makeHole(secret.course,index,{difficulty:'expert'}),ball=Object.assign(createBall(secret.x,secret.z-2.5),{y:height,vz:100,moving:true});
  stepBall(ball,hole,STEP);
  assert.ok(ball.foundSecrets?.includes(secret.id),secret.id+' hole '+index+' height '+height);
  assert.equal(ball.sunk,secret.effect!=='near');assert.equal(ball.moving,false);
  assert.equal(ball.reactions.filter(r=>r.kind==='secret').length,1);
 }
});
test('older amber arches also activate on ground shots and high flyovers',()=>{
 for(const secret of SECRETS)for(const index of [10,16])for(const height of [.06,12,60]){
  const hole=makeHole(secret.course,index),arch=hole.shortcuts[0],ball=Object.assign(createBall(arch.x,arch.z-1.5),{y:height,vz:100,moving:true});
  stepBall(ball,hole,STEP);
  assert.ok(ball.events.includes('shortcut'),secret.course+' hole '+index+' height '+height);
  assert.equal(ball.x,arch.toX);assert.equal(ball.z,arch.toZ);
 }
});
test('strength slider and hold duration both change actual flight distance',()=>{const h=makeHole('classic',0,{wind:0});h.water=[];h.trees=[];h.secrets=[];const shot={club:'iron',angle:0,loft:36};const a=predict(createBall(),h,{...shot,power:swingStrength(.3,1)}).ball,b=predict(createBall(),h,{...shot,power:swingStrength(.9,1)}).ball,c=predict(createBall(),h,{...shot,power:swingStrength(.9,chargeValue(150))}).ball;assert.ok(b.z>a.z+15);assert.ok(b.z>c.z+15);assert.equal(swingStrength(.4,.8),.4);assert.equal(swingStrength(.8,0),.02);});
test('Expert has smaller cups, faster greens and stronger wind; fixed trials omit secrets',()=>{const a=makeHole('classic',0),b=makeHole('classic',0,{difficulty:'expert'});assert.ok(b.cupRadius<a.cupRadius);assert.ok(terrainAt(b,0,b.cup.z).friction<terrainAt(a,0,a.cup.z).friction);assert.ok(Math.abs(b.wind.x)>Math.abs(a.wind.x));assert.equal(makeHole('classic',0,{fixedRules:true}).secrets.length,0);assert.equal(makeHole('classic',1).secrets.length,0);});
test('all six hidden routes on holes 1, 7 and 13 can be reached with real legal shots',()=>{for(const secret of SECRETS)for(const index of [0,6,12]){const h=makeHole(secret.course,index,{difficulty:'expert',chaos:'wild'}),b=createBall();const shot=solveSecret(b,h);strike(b,h,shot);let t=0;while(b.moving){t+=STEP;stepBall(b,h,STEP,t);}assert.ok(b.foundSecrets.includes(secret.id));assert.equal(b.reactions.some(r=>r.kind==='secret'),true);assert.equal(b.sunk,secret.effect!=='near');assert.equal(Boolean(b.secretAce),secret.effect==='ace');if(secret.effect==='near')assert.equal(Math.hypot(b.x-h.cup.x,b.z-h.cup.z),2);console.log(secret.course,index+1,JSON.stringify(shot));}});
test('tree contact bounces a real shot and produces only one bird reaction per shot',()=>{const h=makeHole('classic',0,{wind:0}),t=h.trees.find(t=>t.id==='sentinel-0'),b=createBall(t.x,t.z-2);strike(b,h,{club:'putter',power:.7,angle:0,loft:0});for(let i=0;i<300&&b.moving;i++)stepBall(b,h,STEP,i*STEP);assert.ok(b.events.includes('tree'));assert.equal(b.reactions.filter(r=>r.kind==='bird').length,1);assert.ok(b.z<t.z);});
test('water and sand create duck and crab reactions; predictions have no discovery side effects',()=>{const h=makeHole('classic',0,{wind:0}),b=createBall(-11,h.water[0].z-8);strike(b,h,{club:'putter',power:1,angle:0,loft:0});for(let i=0;i<1000&&b.moving;i++)stepBall(b,h,STEP,i*STEP);assert.ok(b.reactions.some(r=>r.kind==='duck'));const sand=h.sand[0],c=createBall(sand.x,sand.z);c.y=-.02;strike(c,h,{club:'putter',power:.1,angle:0,loft:0});for(let i=0;i<500&&c.moving;i++)stepBall(c,h,STEP,i*STEP);assert.ok(c.reactions.some(r=>r.kind==='crab'));const original=createBall(),shot=solveSecret(original,h);assert.ok(predict(original,h,shot).ball.secretAce);assert.equal(original.secretAce,undefined);assert.equal(original.foundSecrets,undefined);});
