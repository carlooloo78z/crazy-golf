import {spawn} from 'node:child_process';
import {mkdir,writeFile,appendFile} from 'node:fs/promises';
import path from 'node:path';
export const sleep=ms=>new Promise(resolve=>setTimeout(resolve,ms));
export async function browser(){
 const keepAlive=setInterval(()=>{},1000);
 await mkdir('test-results',{recursive:true});
 let ownedServer=null;try{await fetch('http://127.0.0.1:5173/');}catch{ownedServer=spawn(process.execPath,['scripts/serve.mjs'],{windowsHide:true,stdio:'ignore'});await sleep(400);}
 const executable=process.env.CHROME_PATH||'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe';
 const child=spawn(executable,['--headless=new','--no-sandbox','--in-process-gpu','--disable-background-networking','--disable-background-timer-throttling','--disable-renderer-backgrounding','--disable-backgrounding-occluded-windows','--disable-component-update','--disable-sync','--no-first-run','--no-default-browser-check','--mute-audio','--remote-debugging-port=9225','--user-data-dir='+path.resolve('.local/chrome-qa'),'--window-size=1440,1050','--use-angle=swiftshader','--enable-unsafe-swiftshader','about:blank'],{windowsHide:true,stdio:['ignore','ignore','pipe']});
 child.stderr.on('data',chunk=>appendFile('test-results/chrome.log',chunk).catch(()=>{}));child.on('error',err=>console.error(err));
 let targets;for(let i=0;i<50;i++){try{targets=await(await fetch('http://127.0.0.1:9225/json')).json();break;}catch{await sleep(200);}}
 if(!targets)throw Error('Chrome debugging interface did not start');
 const ws=new WebSocket(targets.find(t=>t.type==='page').webSocketDebuggerUrl);await new Promise((resolve,reject)=>{ws.addEventListener('open',resolve,{once:true});ws.addEventListener('error',reject,{once:true});});let id=0;const pending=new Map(),errors=[];
 ws.addEventListener('message',e=>{const data=JSON.parse(e.data);if(process.env.CDP_DEBUG)console.log('CDP',JSON.stringify(data).slice(0,200));if(data.id){const p=pending.get(data.id);if(p){pending.delete(data.id);if(data.error)p.reject(data.error);else p.resolve(data.result);}}if(data.method==='Runtime.exceptionThrown')errors.push(data.params.exceptionDetails.exception?.description||data.params.exceptionDetails.text);if(data.method==='Log.entryAdded'&&data.params.entry.level==='error')errors.push(data.params.entry.text);});
 function send(method,params={}){return new Promise((resolve,reject)=>{const n=++id;const timeout=setTimeout(()=>{pending.delete(n);reject(Error('CDP timeout: '+method));},45000);pending.set(n,{resolve:v=>{clearTimeout(timeout);resolve(v);},reject:e=>{clearTimeout(timeout);reject(e);}});ws.send(JSON.stringify({id:n,method,params}));});}
 async function evaluate(expression){const r=await send('Runtime.evaluate',{expression,awaitPromise:true,returnByValue:true,userGesture:true});if(r.exceptionDetails)throw Error(r.exceptionDetails.exception?.description||r.exceptionDetails.text);return r.result.value;}
 if(process.env.CDP_DEBUG)console.log(await send('Browser.getVersion'));await send('Runtime.enable');await send('Page.enable');await send('Log.enable');
 async function screenshot(name){await send('Page.bringToFront');await sleep(200);const r=await send('Page.captureScreenshot',{format:'png',captureBeyondViewport:false});await writeFile(`test-results/${name}.png`,Buffer.from(r.data,'base64'));}
 async function click(selector){const rect=await evaluate(`(()=>{const el=document.querySelector(${JSON.stringify(selector)});if(!el)throw Error('Missing '+${JSON.stringify(selector)});el.scrollIntoView({block:'center',inline:'nearest',behavior:'instant'});const r=el.getBoundingClientRect();return {x:r.x+r.width/2,y:r.y+r.height/2}})()`);await send('Input.dispatchMouseEvent',{type:'mousePressed',...rect,button:'left',clickCount:1});await send('Input.dispatchMouseEvent',{type:'mouseReleased',...rect,button:'left',clickCount:1});await sleep(80);}
 async function close(){await Promise.race([send('Browser.close').catch(()=>{}),sleep(1000)]);ws.close();child.kill();ownedServer?.kill();clearInterval(keepAlive);}
 return {send,evaluate,screenshot,click,errors,close};
}
