export const SAVE_KEY='golf-mayhem-v1';
export const DEFAULT_SETTINGS={sound:true,music:true,volume:.45,quality:'high',reducedMotion:false,aimAssist:true};
export function defaultProgress(){return {version:1,coins:0,xp:0,unlocked:['classic'],balls:['classic'],outfits:['coral'],clubs:['standard'],equipped:{ball:'classic',outfit:'coral',club:'standard'},stats:{holes:0,aces:0,perfect:0,longest:0,rounds:0,shortcuts:0,underPar:0,rings:0,tricks:0,powers:0,birdHits:0},achievements:[],career:{},challenges:[],records:{},secrets:[],settings:{...DEFAULT_SETTINGS}};}
export function loadProgress(storage){try{const d=JSON.parse(storage.getItem(SAVE_KEY));if(!d||d.version!==1)return defaultProgress();const p=defaultProgress();return {...p,...d,stats:{...p.stats,...d.stats},settings:{...p.settings,...d.settings},equipped:{...p.equipped,...d.equipped}};}catch{return defaultProgress();}}
export function saveProgress(p,storage){try{storage.setItem(SAVE_KEY,JSON.stringify(p));return true;}catch{return false;}}
export const ACHIEVEMENTS=[
 {id:'all-secrets',name:'Keeper of secrets',detail:'Discover all six hidden wildlife shortcuts.',icon:'spark',check:p=>(p.secrets?.length||0)>=6,reward:450},
 {id:'bird-beef',name:'Feathered enemies',detail:'Anger a bird on five different shots.',icon:'bolt',check:p=>p.stats.birdHits>=5,reward:80},
 {id:'first',name:'Hello, fairway',detail:'Complete your first hole.',icon:'flag',check:p=>p.stats.holes>=1,reward:30},
 {id:'ace',name:'One hit wonder',detail:'Score a hole in one.',icon:'star',check:p=>p.stats.aces>=1,reward:100},
 {id:'perfect',name:'Sweet spot',detail:'Hit 10 perfectly timed shots.',icon:'target',check:p=>p.stats.perfect>=10,reward:75},
 {id:'distance',name:'Air miles',detail:'Send a ball more than 75 metres.',icon:'bolt',check:p=>p.stats.longest>=75,reward:60},
 {id:'explorer',name:'World tour',detail:'Unlock all six courses.',icon:'globe',check:p=>p.unlocked.length>=6,reward:200},
 {id:'birdie',name:'Early bird',detail:'Finish 5 holes under par.',icon:'trophy',check:p=>p.stats.underPar>=5,reward:100},
 {id:'secret',name:'Off the beaten path',detail:'Find a secret shortcut.',icon:'spark',check:p=>p.stats.shortcuts>=1,reward:80},
 {id:'veteran',name:'Just one more hole',detail:'Complete 54 holes.',icon:'medal',check:p=>p.stats.holes>=54,reward:250},
 {id:'ringmaster',name:'Ringmaster',detail:'Collect 15 airborne coin rings.',icon:'coin',check:p=>p.stats.rings>=15,reward:300},
 {id:'stunt',name:'Certified chaos',detail:'Complete 20 obstacle tricks.',icon:'spark',check:p=>p.stats.tricks>=20,reward:350},
 {id:'powered',name:'Power trip',detail:'Use 10 special shots.',icon:'bolt',check:p=>p.stats.powers>=10,reward:200},
];
export const SHOP={
 balls:[{id:'classic',name:'The original',color:'#ffffff',price:0},{id:'sunshine',name:'Sunshine',color:'#ffe66b',price:60},{id:'coral',name:'Coral crush',color:'#ff8e86',price:100},{id:'mint',name:'Mint condition',color:'#8affcb',price:140},{id:'cosmic',name:'Cosmic violet',color:'#bf9eff',price:200}],
 outfits:[{id:'coral',name:'Weekend coral',color:'#ef8b68',price:0},{id:'ocean',name:'Ocean club',color:'#69c8e2',price:100},{id:'lime',name:'Lime time',color:'#caf36c',price:140},{id:'violet',name:'After hours',color:'#bfa1e6',price:180}],
 clubs:[{id:'standard',name:'Clubhouse set',color:'#b2beb9',price:0,detail:'The four essentials.'},{id:'gold',name:'Golden hour',color:'#efd38c',price:220,detail:'Gold finish · wider perfect timing window.'},{id:'carbon',name:'Carbon pro',color:'#8eb9d2',price:380,detail:'Carbon finish · widest perfect timing window.'}],
};
export function level(p){return Math.floor(p.xp/250)+1;}
export function rank(p){const l=level(p);return l>=15?'LEGEND':l>=10?'PRO':l>=6?'CONTENDER':l>=3?'RISING STAR':'ROOKIE';}
export function unlockAchievements(p){const awarded=[];for(const a of ACHIEVEMENTS)if(!p.achievements.includes(a.id)&&a.check(p)){p.achievements.push(a.id);p.coins+=a.reward;awarded.push(a);}return awarded;}
export function purchase(p,kind,id){const list=SHOP[kind],item=list?.find(x=>x.id===id);if(!item)return false;const owned=p[kind];if(!owned.includes(id)){if(p.coins<item.price)return false;p.coins-=item.price;owned.push(id);}p.equipped[kind==='balls'?'ball':kind==='outfits'?'outfit':'club']=id;return true;}
export function rewardBreakdown(strokes,par,{combo=1,clean=false,tricks=0}={}){
 const saved=Math.max(0,par-strokes),label=strokes===1?'Hole in one':saved>=3?'Albatross':saved===2?'Eagle':saved===1?'Birdie':strokes===par?'Par':strokes===par+1?'Bogey':'Hole finished';
 const base=strokes===1?500:saved>=3?320+(saved-3)*80:saved===2?220:saved===1?120:strokes===par?50:strokes===par+1?30:Math.max(1,25-(strokes-par-1)*5);
 const efficiency=saved*40,cleanBonus=clean&&strokes<=par?25:0,trickBonus=Math.min(5,Math.max(0,tricks))*35,subtotal=base+efficiency+cleanBonus+trickBonus,multiplier=Math.max(1,Math.min(2,combo)),streak=Math.round(subtotal*(multiplier-1)),total=subtotal+streak;
 return {label,base,saved,efficiency,clean:cleanBonus,tricks:trickBonus,multiplier,streak,best:0,total,xp:10+Math.floor(total*.18)};
}
export function holeReward(strokes,par,combo=1){return rewardBreakdown(strokes,par,{combo}).total;}
