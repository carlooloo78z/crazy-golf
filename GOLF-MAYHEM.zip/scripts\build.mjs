import {mkdir,cp,readFile,stat} from 'node:fs/promises';
import {execFileSync} from 'node:child_process';
for(const file of ['main','scene','natural','mayhem','mayhem-scene','surroundings-scene','rules','physics','courses','progress','audio','ui','extra-modes','online','online-ui','wildlife','wildlife-scene','controls'])execFileSync(process.execPath,['--check',`src/${file}.js`],{stdio:'inherit'});
for(const file of ['server/arena.js','server/api.js','scripts/serve.mjs'])execFileSync(process.execPath,['--check',file],{stdio:'inherit'});
await mkdir('dist',{recursive:true});
for(const item of ['src','vendor','index.html'])await cp(item,`dist/${item}`,{recursive:true});
await cp('public','dist',{recursive:true});
const main=await readFile('dist/index.html','utf8');if(!main.includes('GOLF MAYHEM'))throw Error('Missing game entry');
console.log('Built self-contained game in dist/ — no runtime CDN or package installation required.');
