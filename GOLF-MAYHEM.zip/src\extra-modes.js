export function dailyCup(date=new Date()){
 const day=date.toISOString().slice(0,10),seed=Array.from(day).reduce((n,c)=>(n*31+c.charCodeAt(0))>>>0,17);
 return {day,course:['classic','desert','tropical','sky','volcano','neon'][seed%6],indices:Array.from({length:6},(_,i)=>(seed+i*5)%18),chaos:'wild',remix:seed%10000};
}
export function shuffleClub(position){return ['iron','putter','wedge','driver','putter','wedge'][position%6];}
export function survivalLives(lives,strokes,par,failed=false){return Math.max(0,lives-(failed||strokes>par?1:0));}
