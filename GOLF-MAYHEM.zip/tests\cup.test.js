import test from 'node:test';
import assert from 'node:assert/strict';
import {COURSES,makeHole} from '../src/courses.js';
import {createBall,strike,stepBall,predict,STEP} from '../src/physics.js';
import {solveAirCup} from './cup-solver.mjs';

const moving=(h,x,y,z,vx,vy,vz)=>Object.assign(createBall(h.cup.x+x,h.cup.z+z),{y,vx,vy,vz,moving:true});
function assertSunkOnce(b,h){
 assert.equal(b.sunk,true);assert.equal(b.moving,false);
 assert.equal(b.x,h.cup.x);assert.equal(b.z,h.cup.z);
 assert.deepEqual([b.vx,b.vy,b.vz],[0,0,0]);
 for(let i=0;i<10;i++)stepBall(b,h);
 assert.equal(b.events.filter(e=>e==='cup').length,1);
 assert.equal(b.events.includes('bounce-soft'),false,'Capture happens before ground rebound');
}
test('fast rolling crossings are captured between simulation frames in every course and difficulty',()=>{
 for(const course of COURSES)for(const difficulty of ['arcade','expert']){
  const h=makeHole(course.id,0,{wind:0,difficulty});
  for(const heading of [0,Math.PI/4,Math.PI/2,Math.PI,Math.PI*1.5]){
   const b=moving(h,-Math.sin(heading)*.4,.06,-Math.cos(heading)*.4,Math.sin(heading)*100,0,Math.cos(heading)*100);
   stepBall(b,h,STEP);assertSunkOnce(b,h);
  }
 }
});
test('steep drops, diagonal airborne entries and low chips sink before bouncing',()=>{
 for(const course of COURSES)for(const difficulty of ['arcade','expert']){
  const h=makeHole(course.id,0,{wind:0,difficulty});
  for(const args of [[0,.35,0,0,-70,0],[0,.35,-.4,0,-65,100],[0,.12,-.4,0,-1,100]]){
   const b=moving(h,...args);stepBall(b,h,STEP);assertSunkOnce(b,h);
  }
 }
});
test('a ball dropped from high above a cup sinks only when it reaches the opening',()=>{
 const h=makeHole('classic',0,{wind:0,difficulty:'expert'}),b=moving(h,0,5,0,0,-1,0);
 stepBall(b,h);assert.equal(b.sunk,false);
 for(let i=0;i<300&&b.moving;i++)stepBall(b,h,STEP,i*STEP);
 assertSunkOnce(b,h);
});
test('a real lofted shot from the tee drops straight in and agrees with the preview',()=>{
 const h=makeHole('classic',0,{difficulty:'expert',chaos:'wild'}),b=createBall(),shot=solveAirCup(b,h),preview=predict(b,h,shot).ball;
 strike(b,h,shot);for(let i=0;i<1800&&b.moving;i++)stepBall(b,h,STEP,i*STEP);
 assert.ok(b.airtime>1);assertSunkOnce(b,h);
 assert.equal(b.age,preview.age);assert.equal(b.events.includes('hazard'),false);
});
test('high flyovers, off-line putts and a diagonal shot crossing the rim height outside the cup remain misses',()=>{
 const h=makeHole('classic',0,{wind:0,difficulty:'expert'});
 for(const args of [[0,3,-.4,0,0,100],[.35,.06,-.4,0,0,100],[.35,.35,0,0,-70,0],[0,.8,-.4,0,-85,150]]){
  const b=moving(h,...args);stepBall(b,h,STEP);assert.equal(b.sunk,false,JSON.stringify(args));
 }
});
