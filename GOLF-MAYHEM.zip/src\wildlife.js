// Shared, deterministic interactions: both browser and match server run these rules.
export const SECRETS=[
 {id:'hollow-oak',course:'classic',name:'The hollow oak',x:-9.5,z:16,y:2.5,r:.46,captureRadius:2.2,type:'nest',effect:'ace',clue:'A tiny cream feather and a dark hollow on the left-hand oak.',method:'Roll near the oak or fly over it at any height. Near misses are pulled in for a secret hole-in-one, even after earlier shots.'},
 {id:'coyote-skull',course:'desert',name:'Coyote express',x:10.5,z:15,y:.27,r:.48,captureRadius:2.2,type:'skull',effect:'near',clue:'A small sun-bleached skull beside the right-hand crooked cactus.',method:'Roll near the skull or fly over it at any height. A buried tunnel leaves an easy two-metre putt.'},
 {id:'coconut-post',course:'tropical',name:'Coconut post',x:10,z:18,y:2.6,r:.46,captureRadius:2.2,type:'nest',effect:'ace',clue:'One palm on the right has a coconut nest and a blue feather.',method:'Roll near the palm or fly over it at any height. The bird catches nearby shots and delivers a secret hole-in-one.'},
 {id:'cloud-mail',course:'sky',name:'Cloud mail',x:10,z:16,y:2.7,r:.5,captureRadius:2.2,type:'cloud',effect:'cup',clue:'A small nest tucked into the right-hand low crystal, below the big floating islands.',method:'Roll near the crystal or fly over it at any height. The courier catches near misses and carries the ball into the cup; strokes already taken still count.'},
 {id:'sleeping-vent',course:'volcano',name:'The sleeping vent',x:-10,z:15,y:.3,r:.52,captureRadius:2.2,type:'vent',effect:'near',clue:'Three dull stones and a little curl of smoke on the left. No bright lava.',method:'Roll near the dark vent or fly over it at any height. It catches nearby balls and fires them to a safe two-metre putt.'},
 {id:'service-hatch',course:'neon',name:'Maintenance only',x:10,z:17,y:.9,r:.5,captureRadius:2.2,type:'hatch',effect:'cup',clue:'A dark service panel on the right, with just one dim violet screw.',method:'Roll near the panel or fly over it at any height. Near misses count. The hidden pipe runs straight to the cup; existing strokes still count.'},
];
export function populateWildlife(hole,options){
 hole.difficulty=options.difficulty==='expert'?'expert':'arcade';hole.cupRadius=hole.difficulty==='expert'?.20:.30;
 if(hole.difficulty==='expert'){hole.wind.x*=2.1;hole.wind.z*=2.1;}
 hole.secrets=!options.fixedRules&&!options.short&&[0,6,12].includes(hole.index)?SECRETS.filter(s=>s.course===hole.courseId).map(s=>({...s})):[];
 // Interaction trees deliberately stand clear of water, gaps and the tee.
 for(const [i,z] of [hole.length*.33,hole.length*.59].entries()){
  // Keep the deliberate fairway trees out of the hollow oak's approach.
  const x=(i||hole.secrets.some(s=>s.type==='nest'&&s.x<0)?1:-1)*6.8;
  if(hole.gaps.some(g=>Math.abs(z-g.z)<g.d/2+2)||hole.water.some(p=>((x-p.x)/p.rx)**2+((z-p.z)/p.rz)**2<1.5))continue;
  if(['classic','tropical'].includes(hole.courseId))hole.trees.push({id:'sentinel-'+i,x,z,y:0,s:1,type:hole.theme.decor,h:hole.theme.decor==='palm'?5.5:4.3});
 }
 for(const s of hole.secrets)if(s.type==='nest')hole.trees.push({id:s.id,x:s.x,z:s.z+.3,y:0,s:1.1,type:hole.theme.decor,h:hole.theme.decor==='palm'?6.05:4.73,secret:true});
 hole.treeGrid={};hole.trees.forEach((t,i)=>{if(!['tree','palm'].includes(t.type))return;const r=2.3*t.s;for(let x=Math.floor((t.x-r)/8);x<=Math.floor((t.x+r)/8);x++)for(let z=Math.floor((t.z-r)/8);z<=Math.floor((t.z+r)/8);z++)(hole.treeGrid[x+':'+z] ||= []).push(i);});
 return hole;
}
export function addReaction(ball,kind,x,y,z,extra={}){
 ball.reactions ||= [];if(ball.reactions.some(r=>r.kind===kind))return;
 ball.reactions.push({kind,x,y,z,...extra});
}
const segmentDistance=(a,b,p)=>{const dx=b.x-a.x,dy=b.y-a.y,dz=b.z-a.z,n=dx*dx+dy*dy+dz*dz,t=n?Math.max(0,Math.min(1,((p.x-a.x)*dx+(p.y-a.y)*dy+(p.z-a.z)*dz)/n)):0;return Math.hypot(a.x+dx*t-p.x,a.y+dy*t-p.y,a.z+dz*t-p.z);};
// Shortcuts care only about the horizontal path. Ground shots and flyovers
// activate the same hidden entrance, regardless of the clue's visual height.
function reachesSecret(previous,ball,secret){
 const dx=ball.x-previous.x,dz=ball.z-previous.z,length=dx*dx+dz*dz;
 const t=length?Math.max(0,Math.min(1,((secret.x-previous.x)*dx+(secret.z-previous.z)*dz)/length)):0;
 return Math.hypot(previous.x+dx*t-secret.x,previous.z+dz*t-secret.z)<=(secret.captureRadius||secret.r);
}
export function stepWildlife(ball,hole,previous){
 for(const s of hole.secrets||[]){
  if(ball.foundSecrets?.includes(s.id)||!reachesSecret(previous,ball,s))continue;
  ball.foundSecrets ||= [];ball.foundSecrets.push(s.id);ball.events.push('secret:'+s.id);addReaction(ball,'secret',s.x,s.y,s.z,{id:s.id});
  ball.x=hole.cup.x;ball.z=hole.cup.z-(s.effect==='near'?2:0);ball.y=s.effect==='near'?.06:-.15;ball.vx=ball.vy=ball.vz=0;ball.moving=false;ball.sunk=s.effect!=='near';ball.teleported=true;
  if(s.effect==='ace')ball.secretAce=s.id;
  if(ball.sunk)ball.events.push('cup');else ball.events.push('rest');return true;
 }
 const nearby=hole.treeGrid?hole.treeGrid[Math.floor(ball.x/8)+':'+Math.floor(ball.z/8)]||[]:(hole.trees||[]).map((_,i)=>i);
 for(const index of nearby){const t=hole.trees[index];if(!t)continue;
  if(!['tree','palm'].includes(t.type)||Math.abs(ball.x-t.x)>2.3*t.s||Math.abs(ball.z-t.z)>2.3*t.s)continue;
  const base=t.y||0,cy=base+t.h,dx=ball.x-t.x,dz=ball.z-t.z;
  const trunk=ball.y>=base-.06&&ball.y<=cy,near=Math.hypot(dx,dz),r=.23*t.s+.06;
  const crown=t.type==='tree'&&((dx/(1.55*t.s))**2+((ball.y-cy)/(1.7*t.s))**2+(dz/(1.55*t.s))**2<1);
  const swept=trunk&&segmentDistance({x:previous.x,y:ball.y,z:previous.z},ball,{x:t.x,y:ball.y,z:t.z})<r;
  if(!(swept||crown))continue;
  if(ball.lastTree===t.id&&ball.age-(ball.lastTreeTime||0)<.25)continue;
  const nx=(near>1e-5?dx/near:-Math.sin(Math.atan2(ball.vx,ball.vz))),nz=(near>1e-5?dz/near:-Math.cos(Math.atan2(ball.vx,ball.vz))),dot=ball.vx*nx+ball.vz*nz;
  if(dot<0){ball.vx=(ball.vx-2*dot*nx)*.58;ball.vz=(ball.vz-2*dot*nz)*.58;}else{ball.vx*=.6;ball.vz*=.6;}
  if(crown){ball.vy=Math.min(ball.vy,0)*.6;ball.x=previous.x;ball.z=previous.z;}else{ball.x=t.x+nx*(r+.025);ball.z=t.z+nz*(r+.025);}
  ball.lastTree=t.id;ball.lastTreeTime=ball.age;ball.events.push('tree');addReaction(ball,'bird',t.x,Math.min(cy,3.5)+base,t.z,{treeId:t.id});
 }
 return false;
}
