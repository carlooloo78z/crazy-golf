import * as THREE from '../vendor/three.module.min.js';
import { seeded, centerAt, landscapePatches, landscapeHeightAt, roughHeightAt, ellipse } from './courses.js';

const assets = new Map();
const clamp = (v,a=0,b=1)=>Math.max(a,Math.min(b,v));
export const PALETTES = {
  classic: {rough:0x41662c,fairway:0x608943,green:0x7c9e53,sand:0xd5c49a,water:0x2a666b,sky:['#598bb1','#c7d9df','#ece3cd'],haze:0xd2dbcf},
  desert: {rough:0xa98456,fairway:0x73844a,green:0x8e9b5a,sand:0xd6b681,water:0x32696b,sky:['#7598ac','#dfcfb5','#ead3b1'],haze:0xd1bda1},
  tropical: {rough:0x4b7545,fairway:0x618c47,green:0x8ba55e,sand:0xe3d2a8,water:0x23868b,sky:['#548bb9','#bad8dd','#ede8d1'],haze:0xc3d8cf},
  sky: {rough:0x63806a,fairway:0x7e996d,green:0xa8b58a,sand:0xd2cab3,water:0x719fae,sky:['#6c93c2','#c8d8e9','#eef0e8'],haze:0xc4d5e8},
  volcano: {rough:0x41483b,fairway:0x596342,green:0x78844e,sand:0x857359,water:0xec5421,sky:['#373f52','#807b79','#aa9784'],haze:0x777974},
  neon: {rough:0x172b2a,fairway:0x25413b,green:0x3d6153,sand:0x738a7f,water:0x573a7b,sky:['#080f20','#25334b','#5a6074'],haze:0x26364a},
};

function canvasTexture(key,size,draw,color=true) {
  if(assets.has(key))return assets.get(key);
  const canvas=document.createElement('canvas');canvas.width=canvas.height=size;draw(canvas.getContext('2d'),size);
  const texture=new THREE.CanvasTexture(canvas);texture.colorSpace=color?THREE.SRGBColorSpace:THREE.NoColorSpace;texture.wrapS=texture.wrapT=THREE.RepeatWrapping;texture.anisotropy=4;assets.set(key,texture);return texture;
}
export function grainTexture(type='grass') {
  return canvasTexture(type,256,(ctx,n)=>{
    const random=seeded(type==='grass'?88:93),data=ctx.createImageData(n,n);
    for(let i=0;i<data.data.length;i+=4){const c=type==='water'?120+random()*100:195+random()*60;data.data[i]=data.data[i+1]=data.data[i+2]=c;data.data[i+3]=255;}ctx.putImageData(data,0,0);
    if(type==='grass'){for(let i=0;i<8500;i++){const x=random()*n,y=random()*n;ctx.strokeStyle=`rgba(${random()>.5?'255,255,255':'60,80,45'},${.05+random()*.17})`;ctx.lineWidth=.4;ctx.beginPath();ctx.moveTo(x,y);ctx.lineTo(x+(random()-.5)*3,y-1-random()*4);ctx.stroke();}}
    if(type==='water'){ctx.strokeStyle='#d7d7d7';ctx.lineWidth=1;for(let i=0;i<28;i++){ctx.beginPath();for(let x=0;x<=n;x+=3){const y=i*10+Math.sin(x*.035+i)*4;if(!x)ctx.moveTo(x,y);else ctx.lineTo(x,y);}ctx.stroke();}}
  },type!=='water');
}
export function dimpleTexture(){return canvasTexture('dimples',256,(ctx,n)=>{ctx.fillStyle='#ddd';ctx.fillRect(0,0,n,n);for(let y=0;y<16;y++)for(let x=0;x<16;x++){const cx=x*16+(y%2)*8,cy=y*16;const g=ctx.createRadialGradient(cx,cy,1,cx,cy,6);g.addColorStop(0,'#888');g.addColorStop(.75,'#bbb');g.addColorStop(1,'#eee');ctx.fillStyle=g;ctx.beginPath();ctx.arc(cx,cy,6,0,Math.PI*2);ctx.fill();}},false);}
function skyTexture(id){
  return canvasTexture('sky-'+id,1024,(ctx,n)=>{
    const colors=PALETTES[id].sky,g=ctx.createLinearGradient(0,0,0,n);g.addColorStop(0,colors[0]);g.addColorStop(.45,colors[1]);g.addColorStop(.53,colors[2]);g.addColorStop(1,colors[2]);ctx.fillStyle=g;ctx.fillRect(0,0,n,n);
    const random=seeded(415);for(let group=0;group<18;group++){const x=random()*n,y=n*(.18+random()*.25),width=40+random()*120;for(let j=0;j<12;j++){const xx=x+(random()-.5)*width,yy=y+(random()-.5)*15,r=12+random()*25;ctx.save();ctx.translate(xx,yy);ctx.scale(2.4,.55);const cloud=ctx.createRadialGradient(0,0,0,0,0,r);cloud.addColorStop(0,id==='neon'?'rgba(145,162,196,.12)':'rgba(255,251,235,.24)');cloud.addColorStop(1,'rgba(255,255,255,0)');ctx.fillStyle=cloud;ctx.fillRect(-r,-r,r*2,r*2);ctx.restore();}}
  });
}
function foliageTexture(){return canvasTexture('foliage',256,(ctx,n)=>{
  ctx.clearRect(0,0,n,n);const random=seeded(73);
  for(let i=0;i<1000;i++){const a=random()*Math.PI*2,r=Math.sqrt(random())*110,x=128+Math.cos(a)*r,y=128+Math.sin(a)*r;ctx.save();ctx.translate(x,y);ctx.rotate(a);ctx.fillStyle=`rgb(${175+random()*65},${190+random()*60},${130+random()*80})`;ctx.beginPath();ctx.ellipse(0,0,4+random()*5,2.5+random()*2.5,0,0,Math.PI*2);ctx.fill();ctx.restore();}
});}
function palmTexture(){return canvasTexture('palm-leaf',256,(ctx,n)=>{ctx.clearRect(0,0,n,n);ctx.strokeStyle='#b6cb8a';ctx.lineWidth=4;ctx.beginPath();ctx.moveTo(n/2,n);ctx.lineTo(n/2,8);ctx.stroke();for(let i=1;i<24;i++){const y=i*n/25,w=Math.sin(i/25*Math.PI)*n*.43;for(const side of [-1,1]){ctx.fillStyle=i%2?'#b6ca8b':'#d0d8a0';ctx.beginPath();ctx.moveTo(n/2,y+12);ctx.quadraticCurveTo(n/2+side*w*.6,y-9,n/2+side*w,y-19);ctx.quadraticCurveTo(n/2+side*w*.65,y+4,n/2,y+15);ctx.fill();}}});}

function gridGeometry(width,depth,nx,nz,height,color,offsetZ=0,offsetX=0){
  const positions=[],colors=[],uv=[],indices=[];
  for(let z=0;z<=nz;z++)for(let x=0;x<=nx;x++){
    const xx=(x/nx-.5)*width+offsetX,zz=(z/nz-.5)*depth+offsetZ;positions.push(xx,height(xx,zz),zz);uv.push(xx*.45,zz*.45);const c=color(xx,zz);colors.push(c.r,c.g,c.b);
  }
  for(let z=0;z<nz;z++)for(let x=0;x<nx;x++){const a=z*(nx+1)+x,b=a+1,c=a+nx+1;indices.push(a,c,b,b,c,c+1);}
  const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.Float32BufferAttribute(positions,3));g.setAttribute('color',new THREE.Float32BufferAttribute(colors,3));g.setAttribute('uv',new THREE.Float32BufferAttribute(uv,2));g.setIndex(indices);g.computeVertexNormals();return g;
}

export function buildLandscape(view,hole){
  view.groundMeshes=[];
  const palette=PALETTES[hole.courseId],sky=skyTexture(hole.courseId);sky.mapping=THREE.EquirectangularReflectionMapping;view.scene.background=sky;view.scene.environment=sky;view.scene.environmentIntensity=.32;view.scene.fog=new THREE.Fog(palette.haze,95,240);
  const grass=grainTexture(),rough=new THREE.Color(palette.rough),fairway=new THREE.Color(palette.fairway),green=new THREE.Color(palette.green),sand=new THREE.Color(palette.sand);
  const material=new THREE.MeshStandardMaterial({map:grass,bumpMap:grass,bumpScale:.025,vertexColors:true,roughness:1});
  const pondRatio=(p,x,z)=>((x-p.x)/p.rx)**2+((z-p.z)/p.rz)**2;
  const groundHeight=(x,z)=>{let y=0;for(const p of hole.water){const r=pondRatio(p,x,z);if(r<1.15)y=Math.min(y,-.62*clamp((1.15-r)/.5));}for(const p of hole.sand){const r=pondRatio(p,x,z);if(r<1.1)y=Math.min(y,-.08*clamp((1.1-r)/.25));}return y;};
  const groundColor=(x,z)=>{
    const edge=Math.abs(x-centerAt(hole,z)),c=rough.clone().lerp(fairway,clamp((5.8-edge)/.65));
    const mowing=Math.floor((z+7)/3.2)%2===0?.97:1.04;c.multiplyScalar(mowing);
    c.lerp(green,clamp((6.2-Math.hypot(x-hole.cup.x,z-hole.cup.z))/.45));
    for(const p of hole.sand)c.lerp(sand,clamp((1.1-pondRatio(p,x,z))/.18));
    for(const p of hole.water){const r=pondRatio(p,x,z);if(r<1.2)c.lerp(sand.clone().multiplyScalar(.65),clamp((1.2-r)/.25));}
    c.multiplyScalar(.97+.03*Math.sin(x*1.3+z*.6));return c;
  };
  let start=-7;
  for(const cut of [...hole.gaps].sort((a,b)=>a.z-b.z).concat({z:hole.length+10,d:0})){
    const end=cut.z-cut.d/2,depth=end-start;if(depth>0){const terrain=new THREE.Mesh(gridGeometry(hole.width,depth,72,Math.max(2,Math.ceil(depth*2)),groundHeight,groundColor,(start+end)/2),material);terrain.receiveShadow=true;view.world.add(terrain);view.groundMeshes.push(terrain);
      if(hole.courseId==='sky'||hole.gaps.length){view.box(hole.width,.7,depth,hole.theme.rock,0,-1,(start+end)/2);for(const side of [-1,1])for(let z=start+1.8;z<end-1;z+=3.2){const r=view.add(new THREE.IcosahedronGeometry(2.1,1),hole.theme.rock,side*17.7,-2,z);r.scale.set(1,2.2,1.3);}}
    }start=cut.z+cut.d/2;
  }
  if(hole.courseId!=='sky'){
    const terrainHeight=(x,z)=>landscapeHeightAt(hole,x,z);
    view.landscapeHeight=terrainHeight;
    // Four adjoining meshes surround the playing area without filling its gaps.
    const backdropColor=(x,z)=>rough.clone().multiplyScalar(.86+.14*Math.sin(x*.06+z*.07));
    for(const p of landscapePatches(hole)){const mesh=new THREE.Mesh(gridGeometry(p.width,p.depth,p.nx,p.nz,terrainHeight,backdropColor,p.offsetZ,p.offsetX),material);mesh.receiveShadow=true;view.world.add(mesh);view.groundMeshes.push(mesh);}
  }
  if(hole.courseId==='sky')for(const side of [-1,1])for(let z=-5;z<hole.length+9;z+=9){if(hole.gaps.some(g=>Math.abs(z-g.z)<g.d/2+1))continue;view.add(new THREE.CylinderGeometry(.035,.04,.56,6),0xe7e3d7,side*17.8,.28,z);}
  view.water=[];
  for(const p of hole.water){const water=view.disc(p.rx,p.rz,palette.water,p.x,-.075,p.z,{roughness:.13,metalness:.45,envMapIntensity:1,bumpMap:grainTexture('water'),bumpScale:.055,emissive:hole.courseId==='volcano'?0xd82d00:0x000000,emissiveIntensity:hole.courseId==='volcano'?.8:0});view.water.push(water);}
  return {groundHeight,palette};
}

export function buildForest(view,hole){
  const rng=seeded(hole.seed+412),type=hole.theme.decor,night=hole.courseId==='neon';
  const trees=hole.trees.filter(t=>!t.external);
  if(!['tree','palm'].includes(type)){
    for(const t of trees){const first=view.world.children.length;view.decorate(t.x,t.z,t.s,type,rng);if(t.distant)for(const part of view.world.children.slice(first))part.position.y+=view.landscapeHeight?.(t.x,t.z)||0;}return;
  }
  const branches=[],leaves=[],canopies=[],up=new THREE.Vector3(0,1,0),dummy=new THREE.Object3D();
  function branch(a,b,r){const va=new THREE.Vector3(...a),vb=new THREE.Vector3(...b);dummy.position.copy(va).add(vb).multiplyScalar(.5);dummy.quaternion.setFromUnitVectors(up,vb.clone().sub(va).normalize());dummy.scale.set(r,va.distanceTo(vb),r);dummy.updateMatrix();branches.push(dummy.matrix.clone());}
  for(const tree of trees){const {x,z,s}=tree,base=tree.distant?roughHeightAt(hole,x,z):0,h=(type==='palm'?5.5:4.3)*s;
    branch([x,base,z],[x+.12*s,h+base,z],.17*s);
    if(type==='palm'){
      for(let arm=0;arm<9;arm++){const a=arm*Math.PI*2/9;for(let part=0;part<5;part++){const d=(part+.4)*.48*s;dummy.position.set(x+Math.cos(a)*d,base+h+.4*Math.sin(part/4*Math.PI)-part*.2,z+Math.sin(a)*d);dummy.rotation.set(Math.PI/2+.3,a,Math.sin(part)*.2);dummy.scale.set(.55*s,1.6*s,1);dummy.updateMatrix();leaves.push({matrix:dummy.matrix.clone(),color:new THREE.Color(0x62854c).multiplyScalar(.8+rng()*.35)});}}
    }else{
      for(let arm=0;arm<5;arm++){const a=rng()*Math.PI*2;branch([x,base+h*.5,z],[x+Math.cos(a)*1.2*s,base+h*.85,z+Math.sin(a)*1.2*s],.055*s);}
      for(let cluster=0;cluster<12;cluster++){const a=rng()*Math.PI*2,y=rng()*2-1,r=Math.sqrt(1-y*y)*1.05*s;dummy.position.set(x+Math.cos(a)*r,base+h+y*1.2*s,z+Math.sin(a)*r);dummy.rotation.set(rng()*3,rng()*3,rng()*3);dummy.scale.set((.8+rng()*.4)*s,(.8+rng()*.5)*s,(.7+rng()*.5)*s);dummy.updateMatrix();canopies.push({matrix:dummy.matrix.clone(),color:new THREE.Color(0x577b3b).multiplyScalar(.85+rng()*.35)});}
      const count=tree.distant?8:16;for(let leaf=0;leaf<count;leaf++){const a=rng()*Math.PI*2,y=rng()*2-1,r=Math.sqrt(1-y*y)*(1.4+rng()*.3)*s;dummy.position.set(x+Math.cos(a)*r,base+h+y*1.7*s,z+Math.sin(a)*r);dummy.rotation.set(rng()*Math.PI,rng()*Math.PI,rng()*Math.PI);dummy.scale.setScalar((.65+rng()*.6)*s);dummy.updateMatrix();leaves.push({matrix:dummy.matrix.clone(),color:new THREE.Color(0x8f9f6a).multiplyScalar(.8+rng()*.35)});}
    }
  }
  const bark=new THREE.MeshStandardMaterial({color:0x75634b,roughness:1,bumpMap:grainTexture('bark'),bumpScale:.12});
  const trunks=new THREE.InstancedMesh(new THREE.CylinderGeometry(.6,1,1,7),bark,branches.length);branches.forEach((m,i)=>trunks.setMatrixAt(i,m));trunks.castShadow=trunks.receiveShadow=true;view.world.add(trunks);
  if(canopies.length){const geo=new THREE.IcosahedronGeometry(1,2),p=geo.attributes.position;for(let i=0;i<p.count;i++){const v=new THREE.Vector3().fromBufferAttribute(p,i),s=1+Math.sin(v.x*19+v.y*7)*Math.cos(v.z*17-v.y*9)*.1;p.setXYZ(i,v.x*s,v.y*s,v.z*s);}const normal=geo.attributes.normal;for(let i=0;i<p.count;i++){const v=new THREE.Vector3().fromBufferAttribute(p,i).normalize();normal.setXYZ(i,v.x,v.y,v.z);}const crowns=new THREE.InstancedMesh(geo,new THREE.MeshStandardMaterial({map:grainTexture(),bumpMap:grainTexture(),bumpScale:.09,roughness:1}),canopies.length);canopies.forEach((c,i)=>{crowns.setMatrixAt(i,c.matrix);crowns.setColorAt(i,c.color);});crowns.castShadow=crowns.receiveShadow=true;view.world.add(crowns);}
  const foliage=new THREE.InstancedMesh(new THREE.PlaneGeometry(1,1),new THREE.MeshStandardMaterial({map:type==='palm'?palmTexture():foliageTexture(),side:THREE.DoubleSide,alphaTest:.25,roughness:1,transparent:false}),leaves.length);leaves.forEach((l,i)=>{foliage.setMatrixAt(i,l.matrix);foliage.setColorAt(i,l.color);});foliage.castShadow=false;foliage.receiveShadow=true;view.world.add(foliage);
  // Low grass tufts outside the cut fairway use a single draw call.
  const blade=new THREE.ConeGeometry(.025,.24,3),tufts=new THREE.InstancedMesh(blade,new THREE.MeshStandardMaterial({color:0x819058,roughness:1}),400);let count=0;
  for(let i=0;i<500;i++){const x=(rng()-.5)*34,z=rng()*hole.length;if(Math.abs(x-centerAt(hole,z))<7||hole.gaps.some(g=>Math.abs(z-g.z)<g.d/2+1)||hole.water.some(p=>((x-p.x)/p.rx)**2+((z-p.z)/p.rz)**2<1.4))continue;dummy.position.set(x,.10,z);dummy.rotation.set(0,rng()*6,(rng()-.5)*.35);dummy.scale.setScalar(.6+rng()*.9);dummy.updateMatrix();tufts.setMatrixAt(count++,dummy.matrix);if(count===400)break;}tufts.count=count;view.world.add(tufts);
}

export function makeGolfer(color=0xe7e3d7){
  const root=new THREE.Group(),torsoPivot=new THREE.Group();torsoPivot.position.set(.05,.88,0);root.add(torsoPivot);
  const shirt=new THREE.MeshStandardMaterial({color,roughness:.94}),skin=new THREE.MeshStandardMaterial({color:0xc99873,roughness:.85}),pants=new THREE.MeshStandardMaterial({color:0x34413e,roughness:.95}),shoe=new THREE.MeshStandardMaterial({color:0xe8e7dd,roughness:.55}),metal=new THREE.MeshStandardMaterial({color:0xa7adae,roughness:.24,metalness:.8});
  const up=new THREE.Vector3(0,1,0),shirtPieces=[];
  function part(parent,geo,mat,x,y,z){const m=new THREE.Mesh(geo,mat);m.position.set(x,y,z);m.castShadow=m.receiveShadow=true;parent.add(m);return m;}
  function limb(parent,a,b,r1,r2,mat){const av=new THREE.Vector3(...a),bv=new THREE.Vector3(...b);const m=part(parent,new THREE.CylinderGeometry(r1,r2,av.distanceTo(bv),10),mat,...av.clone().add(bv).multiplyScalar(.5).toArray());m.quaternion.setFromUnitVectors(up,bv.clone().sub(av).normalize());return m;}
  for(const side of [-1,1]){
    limb(root,[0,.88,side*.12],[.11,.48,side*.18],.085,.105,pants);limb(root,[.11,.48,side*.18],[.02,.1,side*.24],.055,.075,pants);
    const foot=part(root,new THREE.SphereGeometry(1,14,10),shoe,.08,.07,side*.24);foot.scale.set(.17,.07,.085);
    const sole=part(root,new THREE.BoxGeometry(.28,.025,.15),pants,.08,.023,side*.24);sole.rotation.y=side*.08;
  }
  const body=part(torsoPivot,new THREE.CylinderGeometry(.205,.15,.5,14),shirt,.10,.28,0);body.scale.z=.76;body.rotation.z=-.13;shirtPieces.push(body);
  part(torsoPivot,new THREE.CylinderGeometry(.16,.16,.035,14),pants,.055,.025,0);
  const head=part(torsoPivot,new THREE.SphereGeometry(1,20,16),skin,.15,.79,0);head.scale.set(.12,.15,.115);
  part(torsoPivot,new THREE.CylinderGeometry(.055,.06,.09,10),skin,.13,.61,0);
  const cap=part(torsoPivot,new THREE.SphereGeometry(.125,18,10,0,Math.PI*2,0,Math.PI/2),shoe,.15,.855,0);cap.scale.y=.58;
  const brim=part(torsoPivot,new THREE.SphereGeometry(1,14,8),shoe,.25,.855,0);brim.scale.set(.14,.012,.105);
  part(torsoPivot,new THREE.SphereGeometry(.024,10,8),skin,.27,.79,0);
  for(const side of [-1,1]){
    part(torsoPivot,new THREE.SphereGeometry(.009,8,6),pants,.257,.825,side*.046);
    const sleeve=limb(torsoPivot,[.12,.48,side*.17],[.25,.27,side*.22],.072,.08,shirt);shirtPieces.push(sleeve);
    limb(torsoPivot,[.25,.27,side*.22],[.52,-.03,side*.025],.04,.058,skin);
    part(torsoPivot,new THREE.SphereGeometry(.05,10,8),side===-1?shoe:skin,.52,-.05,side*.025);
  }
  const club=new THREE.Group();club.position.set(.53,-.05,0);torsoPivot.add(club);
  limb(club,[0,0,0],[.47,-.73,0],.012,.014,metal);limb(club,[-.035,.06,0],[.05,-.08,0],.021,.02,pants.clone());
  const headClub=part(club,new THREE.SphereGeometry(1,16,10),metal,.48,-.74,0);headClub.scale.set(.11,.045,.065);
  return {root,body,torsoPivot,club,headClub,shirtPieces};
}

export function addGolfDetails(view,hole){
  const golfer=makeGolfer(0xd8d5ca);view.golfer=golfer.root;view.golferBody=golfer.body;view.golferTorso=golfer.torsoPivot;view.clubGroup=golfer.club;view.clubHead=golfer.headClub;view.shirtPieces=golfer.shirtPieces;view.world.add(golfer.root);
  const cup=view.add(new THREE.CylinderGeometry(hole.cupRadius+.01,hole.cupRadius+.01,.16,40,1,true),0x44483e,hole.cup.x,-.045,hole.cup.z,{side:THREE.DoubleSide});cup.castShadow=false;
  view.disc(hole.cupRadius,hole.cupRadius,0x111a15,hole.cup.x,-.10,hole.cup.z);const rim=view.add(new THREE.TorusGeometry(hole.cupRadius+.01,.014,5,40),0xd6d3c5,hole.cup.x,.008,hole.cup.z);rim.rotation.x=-Math.PI/2;rim.castShadow=false;
  view.add(new THREE.CylinderGeometry(.018,.022,2.5,10),0xe5e6de,hole.cup.x,1.25,hole.cup.z);
  const flagMap=canvasTexture('flag-'+hole.index,128,(ctx,n)=>{ctx.fillStyle='#b7392c';ctx.fillRect(0,0,n,n);ctx.fillStyle='#fff8e8';ctx.font='bold 60px Arial';ctx.textAlign='center';ctx.fillText(String(hole.index+1),n/2,85);});
  view.flag=view.add(new THREE.PlaneGeometry(.7,.44,14,6),0xffffff,hole.cup.x+.35,2.21,hole.cup.z,{map:flagMap,side:THREE.DoubleSide,roughness:.9});view.flagRest=Float32Array.from(view.flag.geometry.attributes.position.array);
  const teeMat=view.box(2,.015,1.5,0x618443,hole.tee.x,-.007,hole.tee.z);teeMat.material.map=grainTexture();
  for(const side of [-1,1]){const marker=view.add(new THREE.SphereGeometry(.075,12,8),0xf0eade,hole.tee.x+side*.94,.05,hole.tee.z);marker.scale.y=.7;}
  const bag=view.add(new THREE.CylinderGeometry(.19,.17,.9,14),0x283938,-1.9,.47,.6,{roughness:.6});bag.rotation.z=.12;view.add(new THREE.TorusGeometry(.19,.025,7,18),0xc1aa78,-1.95,.87,.6).rotation.x=Math.PI/2;
  for(let i=0;i<4;i++){view.add(new THREE.CylinderGeometry(.012,.012,.9,6),0xb9bfc1,-2+i*.07,1.0,.6);view.box(.1,.06,.07,0xa8afb0,-2+i*.07,1.46,.6);}
  view.spectators=[];for(let i=0;i<4;i++){const spectator=makeGolfer([0xe1ded2,0x7a8f94,0xa28a71,0x576e68][i]);spectator.root.position.set(10+i*.8,0,hole.length-4);spectator.root.rotation.y=Math.PI*.7;spectator.club.visible=false;view.world.add(spectator.root);view.spectators.push(spectator);}
}
