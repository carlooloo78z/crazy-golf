import {COURSES,MODES,CLUBS,CHALLENGES,makeHole,terrainAt,centerAt,movingX} from './courses.js';
import {createBall,strike,stepBall,predict,STEP} from './physics.js';
import {loadProgress,saveProgress,unlockAchievements,rewardBreakdown,SHOP,purchase,rank,level} from './progress.js';
import {CHAOS_LEVELS,SHOT_STYLES,POWERS} from './mayhem.js';
import {strokeLimit,roughPenalty,limitReached,failedHoleScore} from './rules.js';
import {SECRETS} from './wildlife.js';
import {chargeValue,swingStrength} from './controls.js';
import {dailyCup,shuffleClub,survivalLives} from './extra-modes.js';
import {GolfScene} from './scene.js';
import {GolfAudio} from './audio.js';
import * as UI from './ui.js';
import {OnlineClient,frameAt} from './online.js';
import {onlineLobby,queueView,onlineBoard,onlineResult,colors as rivalColors} from './online-ui.js';

const app=document.querySelector('#app'),canvas=document.querySelector('#game');
let progress=loadProgress(localStorage),selection={mode:'quick',course:'classic',hole:0,challenge:0,chaos:'wild',remix:0,difficulty:'expert'};
let scene,audio=new GolfAudio(progress.settings),screen='home',round=null,hole=makeHole('classic',0),ball=createBall(),phase='ready';
let shot={club:'iron',power:.8,angle:0,loft:36,style:'straight',powerUp:null},simTime=0,accumulator=0,last=performance.now(),charging=0,timing=.0;
let overlay=null,previousFocus=null,lockedTab='balls',toastTimer,announcementTimer,previewDirty=true,previewAt=0,lastHud=0;
let replayFrames=[],lastReplay=[],replay=null,shotStart=null,distanceBonus=false,keys=new Set(),swingPointer=false;
let pendingResult=null,activeTimeout=null,reaction=null,onlineReacted=null;
let online=null,onlineAnimation=null,onlineSeen=0,onlineNotice=null,onlineData=null,serverScope=null,onlineSettled=null;
const settings=progress.settings;
try{scene=new GolfScene(canvas,settings);}catch(error){app.innerHTML=`<div class="webgl-error"><h1>GOLF MAYHEM</h1><p>This game needs WebGL to render its 3D courses. Enable hardware acceleration in your browser and reload.</p><button onclick="location.reload()">Try again</button></div>`;throw error;}
function save(){if(!saveProgress(progress,localStorage))toast('Browser storage is full. Progress cannot be saved on this device.');}
function toast(message){const el=document.querySelector('#toast');el.textContent=message;el.classList.add('visible');clearTimeout(toastTimer);toastTimer=setTimeout(()=>el.classList.remove('visible'),3500);}
function announce(title,subtitle=''){const el=document.querySelector('#announcement');el.innerHTML=`<b>${UI.escape(title)}</b><span>${UI.escape(subtitle)}</span>`;el.classList.add('visible');clearTimeout(announcementTimer);announcementTimer=setTimeout(()=>el.classList.remove('visible'),2300);}
function achievements(){const rewards=unlockAchievements(progress);if(rewards.length)toast(rewards.map(a=>`${a.name} · +${a.reward} coins`).join(' / '));save();}
function cosmetics(){const b=SHOP.balls.find(x=>x.id===progress.equipped.ball),o=SHOP.outfits.find(x=>x.id===progress.equipped.outfit);scene.setCosmetics(b?.color||'#ffffff',o?.color||'#ef8b68');if(scene.clubGroup)scene.clubGroup.traverse(m=>{if(m.material)m.material.color.set(SHOP.clubs.find(x=>x.id===progress.equipped.club)?.color||'#b2beb9');});}
function showHome(){cancelReaction();if(online?.active)online.leave();onlineAnimation=null;onlineData=null;onlineNotice=null;scene.setRivals([]);clearTimeout(activeTimeout);removeModal();screen='home';phase='ready';round=null;replay=null;keys.clear();document.body.classList.remove('playing');previewCourse();scene.cameraMode='follow';scene.clearPath();cosmetics();paintHome();}
function previewCourse(){hole=makeHole(selection.course,0,selection.mode==='challenge'?{}:selection);ball=createBall();scene.build(hole);cosmetics();}
function rerenderHome(){paintHome();}
function paintHome(){app.innerHTML=UI.home(progress,selection);document.querySelector('.hero').insertAdjacentHTML('afterend',onlineLobby(sessionStorage.getItem('golf-player-name')||progress.playerName));refreshServerStatus();}
async function refreshServerStatus(){try{const d=await online.request('status');serverScope=d.scope;setText('server-status',d.scope==='public'?'MATCHMAKING ONLINE · '+d.players+' connected players':'LOCAL MATCHMAKING · Worldwide play is not live yet. Two tabs can play together on this server.');}catch{setText('server-status','MATCHMAKING UNAVAILABLE · Launch the game with its server to play against friends.');}}
function openModal(html,kind='general'){clearTimeout(announcementTimer);document.querySelector('#announcement')?.classList.remove('visible');previousFocus ||= document.activeElement;document.querySelector('#overlay')?.remove();app.insertAdjacentHTML('beforeend',html);overlay=kind;keys.clear();charging=0;const el=document.querySelector('#overlay');if(['hole-result','round-result','challenge-failed','hole-failed','handoff','online-queue','online-hole','online-result'].includes(kind))el.querySelector('[data-action="close"]')?.remove();el.querySelector('button,input,select')?.focus();}
function removeModal(){document.querySelector('#overlay')?.remove();overlay=null;previousFocus?.focus?.();previousFocus=null;}
function closeModal(){if(['hole-result','round-result','challenge-failed','hole-failed','handoff','online-queue','online-hole','online-result'].includes(overlay))return;removeModal();if(screen==='home')rerenderHome();previewDirty=true;}
function begin(names){
  const mode=selection.mode,challenge=CHALLENGES[selection.challenge],daily=mode==='daily'?dailyCup():null;
  if(daily)Object.assign(selection,{course:daily.course,chaos:daily.chaos,remix:daily.remix});
  const count=MODES.find(m=>m.id===mode).holes;
  const indices=daily?daily.indices:mode==='shuffle'?[0,1,4,3,2,5]:mode==='challenge'?[challenge.hole]:Array.from({length:count},(_,i)=>(i+(mode==='free'?selection.hole:0))%18);
  round={mode,lives:3,dailyDay:daily?.day,course:selection.course,indices,position:0,player:0,challenge:selection.challenge,difficulty:mode==='challenge'?'arcade':mode==='daily'?'expert':selection.difficulty,chaos:mode==='challenge'?'chill':selection.chaos,remix:selection.remix,players:(names||['You']).map(name=>({name,scores:[],failures:[],combo:1,streak:0})),elapsed:0,earned:0,allowedClubs:mode==='challenge'?challenge.clubs:null,finished:false};
  round.pars=round.indices.map(i=>roundHole(i).par);screen='game';document.body.classList.add('playing');removeModal();loadHole();audio.unlock();
}
function loadHole(){
  cancelReaction();
  clearTimeout(activeTimeout);removeModal();replay=null;pendingResult=null;lastReplay=[];replayFrames=[];
  const options=round.mode==='challenge'?{...CHALLENGES[round.challenge],fixedRules:true}:{chaos:round.chaos,remix:round.remix,short:round.mode==='shuffle',difficulty:round.difficulty};
  if(round.mode==='shuffle')round.allowedClubs=[shuffleClub(round.position)];
  round.lifeCounted=false;
  hole=makeHole(round.course,round.indices[round.position],options);ball=createBall(hole.tee.x,hole.tee.z);round.strokes=0;round.swings=0;round.strokeLimit=strokeLimit(round.mode,CHALLENGES[round.challenge]);round.roughPenalties=0;round.shotHazard=false;round.failure=null;round.powerCharge=round.mode==='challenge'?0:1;round.hazards=0;round.tricks=[];round.conceded=false;shot.style='straight';shot.powerUp=null;phase='ready';charging=0;accumulator=0;
  scene.build(hole);scene.cameraMode='follow';scene.orbit=0;cosmetics();autoClub(true);renderHud();
  if(round.mode==='multi')announce(`${round.players[round.player].name}, you’re up!`,'Complete the hole, then pass the screen.');
  else announce(`HOLE ${hole.index+1}`,`${hole.name} · Par ${hole.par}`);
}
function roundHole(index){return makeHole(round.course,index,round.mode==='challenge'?{...CHALLENGES[round.challenge],fixedRules:true}:{chaos:round.chaos,remix:round.remix,short:round.mode==='shuffle',difficulty:round.difficulty});}
function autoClub(resetPower=false){const distance=Math.hypot(hole.cup.x-ball.x,hole.cup.z-ball.z);let club=distance<18?'putter':distance<43?'iron':'driver';if(round.allowedClubs&&!round.allowedClubs.includes(club))club=round.allowedClubs[0];shot={style:club==='putter'?'straight':shot.style,powerUp:shot.powerUp,club,power:resetPower?(club==='putter'?Math.min(.9,Math.sqrt(distance*3.7)/12):.8):shot.power,angle:Math.atan2(hole.cup.x-ball.x,hole.cup.z-ball.z),loft:CLUBS[club].loft};previewDirty=true;}
function renderHud(){app.innerHTML=UI.hud(progress,round,shot,hole);updateShotInputs();updateHud();previewDirty=true;}
function updateShotInputs(){if(shot.club==='putter')shot.style='straight';updateMayhemControls();scene.setClub(shot.club);const c=CLUBS[shot.club];for(const [id,val] of [['aim',shot.angle*180/Math.PI],['loft',shot.loft],['power',Math.round(shot.power*100)]]){const input=document.getElementById(id);if(input)input.value=val;}const loft=document.getElementById('loft');if(loft){loft.min=c.min;loft.max=c.max;loft.disabled=c.max===0;}document.querySelectorAll('.club-button').forEach(el=>{el.classList.toggle('selected',el.dataset.id===shot.club);el.setAttribute('aria-pressed',el.dataset.id===shot.club);});setText('aim-value',Math.round(shot.angle*180/Math.PI)+'°');setText('loft-value',shot.loft+'°');setText('power-value',Math.round(shot.power*100)+'%');const zone=document.querySelector('.perfect-zone');if(zone){const size=perfectWindow();zone.style.left=(.8-size)*100+'%';zone.style.width=size*200+'%';}previewDirty=true;}
function updateMayhemControls(disabled=phase!=='ready'){
 document.querySelectorAll('[data-action="style"]').forEach(el=>{const selected=el.dataset.id===shot.style;el.classList.toggle('selected',selected);el.setAttribute('aria-pressed',selected);el.disabled=disabled||shot.club==='putter';});
 document.querySelectorAll('[data-action="powerup"]').forEach(el=>{const selected=el.dataset.id===shot.powerUp;el.classList.toggle('selected',selected);el.setAttribute('aria-pressed',selected);el.disabled=disabled||!round?.powerCharge;});
 setText('power-status',round?.mode==='challenge'?'FIXED RULES':round?.powerCharge?(shot.powerUp?'ARMED · TAP TO CANCEL':'1 CHARGE · OPTIONAL'):'USED · NEXT HOLE REFILLS');
 setText('style-status',shot.club==='putter'?'PUTTER · STRAIGHT ONLY':'SHAPE YOUR FLIGHT');
}
function setText(id,text){const el=document.getElementById(id);if(el&&el.textContent!==String(text))el.textContent=text;}
function updateHud(){if(!round)return;setText('special-rules',round.mode==='survival'?'♥ '.repeat(round.lives)+' · '+round.lives+' LIVES':round.mode==='shuffle'?'REQUIRED CLUB · '+CLUBS[round.allowedClubs[0]].name.toUpperCase():round.mode==='daily'?'DAILY CUP · '+round.dailyDay+' UTC':'');setText('stroke-count',round.strokes+'/'+round.strokeLimit);setText('strokes-left',Math.max(0,round.strokeLimit-round.strokes)+' LEFT · DARK GRASS +1');document.getElementById('stroke-count')?.classList.toggle('limit-warning',round.strokeLimit-round.strokes<=2);const player=round.players[round.player],score=player.scores.reduce((sum,s,i)=>sum+s-round.pars[i],0);setText('round-score',round.mode==='time'?formatTime(round.elapsed):UI.formatScore(score));setText('distance-label',Math.round(Math.hypot(ball.x-hole.cup.x,ball.z-hole.cup.z)));setText('lie-label',ball.moving?'BALL IN FLIGHT':terrainAt(hole,ball.x,ball.z,simTime).type.toUpperCase());setText('hud-coins',progress.coins);setText('last-strength',round.lastShotPower?'LAST SWING · '+Math.round(round.lastShotPower*100)+'% STRENGTH':'QUICK RELEASE = GENTLE TAP');setText('combo-label',player.combo>1?`×${player.combo} STREAK`:'');const nextStreak=round.strokes+1<hole.par?player.streak+1:0;const prize=rewardBreakdown(round.strokes+1,hole.par,{combo:Math.min(2,1+.25*Math.max(0,nextStreak-1)),clean:round.hazards===0&&round.roughPenalties===0,tricks:round.tricks.length});setText('next-reward',round.online?'MATCH PRIZE PENDING: +'+round.earned:round.failure?'HOLE CLOSED · NO PRIZE':ball.sunk?`BANKED +${pendingResult?.reward||0}`:`SINK NEXT: +${prize.total} COINS`);drawMinimap();}
function perfectWindow(){return progress.equipped.club==='carbon'?.16:progress.equipped.club==='gold'?.12:.08;}
function canShoot(){return (!round?.online||online?.healthy&&!online.pending&&!onlineAnimation&&onlineData?.match.status==='playing'&&!onlineData.match.players.find(p=>p.id===onlineData.you).holeDone)&& screen==='game'&&!reaction&&phase==='ready'&&!overlay&&!replay&&!ball.moving&&!ball.sunk&&round.strokes<round.strokeLimit;}
function startCharge(){if(!canShoot())return;audio.unlock();charging=performance.now();timing=0;document.querySelector('#swing')?.classList.add('charging');setText('timing-hint','BUILDING SHOT STRENGTH…');}
function cancelCharge(){charging=0;swingPointer=false;document.querySelector('#swing')?.classList.remove('charging');setText('timing-hint','HOLD FOR POWER · GREEN = MAX');setText('power-value',Math.round(shot.power*100)+'% MAX');}
function releaseCharge(){if(!charging)return;const value=chargeValue(performance.now()-charging),strength=swingStrength(shot.power,value);cancelCharge();if(!canShoot())return;const perfect=Math.abs(value-.8)<=perfectWindow();const deviation=perfect?0:(value-.8)*.055;fireShot({...shot,power:strength,angle:shot.angle+deviation},perfect);}
function fireShot(params,perfect=false){if(!canShoot())return false;
  round.lastShotPower=params.power;if(round.online){submitOnlineShot(params);return true;}
  const chosen=params.powerUp??null,powerUp=round.powerCharge&&POWERS.some(p=>p.id===chosen)?chosen:null;
  if(!strike(ball,hole,{...params,powerUp,time:simTime}))return false;
  if(powerUp){round.powerCharge--;progress.stats.powers++;shot.powerUp=null;announce(POWERS.find(p=>p.id===powerUp).name.toUpperCase()+' SHOT!', 'Special charge used · refills next hole');}
  phase='flying';round.strokes++;round.swings++;round.shotHazard=false;shotStart={x:ball.x,z:ball.z};distanceBonus=false;scene.clearPath();scene.swing();audio.play('hit');replayFrames=[];replay=null;
  if(perfect){progress.stats.perfect++;progress.coins+=5;round.earned+=5;announce('PERFECT SHOT','Sweet timing. +5 coins');audio.play('perfect');}
  setShotDisabled(true);updateHud();return true;
}
function setShotDisabled(disabled){document.querySelector('.shot-panel')?.classList.toggle('busy',disabled);for(const el of document.querySelectorAll('.shot-panel input,.shot-panel button')){if(el.classList.contains('club-button'))el.disabled=disabled||!!(round.allowedClubs&&!round.allowedClubs.includes(el.dataset.id));else el.disabled=disabled||(el.id==='loft'&&shot.club==='putter');}const b=document.querySelector('#swing span');if(b)b.textContent=disabled?'Let it fly…':'Hold to swing';updateMayhemControls(disabled);}
function chooseReaction(items=[]){return items.find(r=>r.kind==='secret')||items.find(r=>r.kind==='bird')||items[0];}
function rememberSecret(id,pay=true){progress.secrets ||= [];if(progress.secrets.includes(id))return;progress.secrets.push(id);progress.stats.shortcuts++;if(pay){progress.coins+=150;round.earned+=150;}save();}
function completeShotWithReaction(){
 if(ball.secretAce)round.strokes=1;
 for(const id of ball.foundSecrets||[])rememberSecret(id);
 const data=chooseReaction(ball.reactions);if(data?.kind==='bird')progress.stats.birdHits++;
 const finish=()=>{shotEnded();if(ball.sunk&&!round.failure)holeComplete();};
 if(data)startReaction(data,finish);else finish();
}
function startReaction(data,after){
 if(reaction)return;cancelCharge();clearTimeout(activeTimeout);activeTimeout=null;removeModal();scene.clearPath();phase='cutscene';setShotDisabled(true);
 reaction={data,after,age:0,startedAt:performance.now(),duration:settings.reducedMotion?1.5:3.6};scene.startReaction(data);audio.play(data.kind==='secret'?'perfect':data.kind);
 const secret=SECRETS.find(s=>s.id===data.id),titles={bird:'THIS IS MY TREE!',duck:'QUACK. NICE SHOT.',crab:'THANKS FOR THE DELIVERY!',secret:secret?.name.toUpperCase()||'SECRET DISCOVERED!'},captions={bird:'You woke the resident. It wants a word.',duck:'The local duck has reviewed your technique.',crab:'The bunker concierge would like a tip.',secret:secret?.effect==='ace'?'The bird delivers your ball. Secret hole-in-one!':secret?.effect==='near'?'A hidden route. A two-metre putt awaits.':'Special delivery, straight into the cup.'};
 document.querySelector('#announcement')?.classList.remove('visible');app.insertAdjacentHTML('beforeend',`<div id="reaction-cutscene" class="reaction-cutscene" role="dialog" aria-modal="true" aria-label="${UI.escape(titles[data.kind])}"><div class="cinema-top"><span>GOLF MAYHEM / ${data.kind==='secret'?'A WELL-KEPT SECRET':'WILDLIFE ENCOUNTER'}</span>${UI.button('skip-reaction','Skip · Esc','button secondary')}</div><div class="cinema-caption"><h2>${UI.escape(titles[data.kind])}</h2><p>${UI.escape(captions[data.kind])}</p></div></div>`);document.querySelector('[data-action="skip-reaction"]')?.focus();
}
function cancelReaction(){reaction=null;document.querySelector('#reaction-cutscene')?.remove();scene?.stopReaction();}
function finishReaction(){if(!reaction)return;const after=reaction.after;cancelReaction();previewDirty=true;after();}
function secretGuide(){return UI.modal('The secret field guide','Spoilers ahead · '+(progress.secrets?.length||0)+' / 6 discovered',`<p class="muted">Each new secret appears on holes <b>1, 7 and 13</b> in its own course. Look 13–16 metres ahead of the tee, about 10 metres to the indicated side. Aim close to the clue at any height. Rolling nearby or flying over it both count. These diagrams show each location from the tee; markers appear only in this spoiler guide. Fixed challenges and Club Shuffle do not contain these shortcuts.</p><div class="secret-guide">${SECRETS.map(s=>`<article><small>${s.course.toUpperCase()} · ${progress.secrets?.includes(s.id)?'DISCOVERED':'UNDISCOVERED'}</small><h3>${s.name}</h3>${UI.secretMap(s)}<p>${s.clue}</p><p>${s.method}</p></article>`).join('')}</div><p class="muted">Two older shortcuts remain on holes 11 and 17 of every course: the amber arch left of the fairway, about a third of the way down. Roll through or fly over at any height to reach the green. New discoveries award 150 local coins once each; all six earn the Keeper of Secrets trophy.</p>`,UI.button('close','Keep it between us','button primary'),true);}
function shotEnded(){
  lastReplay=replayFrames.slice();phase='ready';
  const penalty=roughPenalty(ball,terrainAt(hole,ball.x,ball.z,simTime),round.shotHazard);
  if(penalty){round.strokes+=penalty;round.roughPenalties++;announce('THAT’S ROUGH!','Dark grass · +1 stroke · play from here');audio.play('hazard');}
  achievements();updateHud();
  if(limitReached(round.strokes,round.strokeLimit,ball.sunk)){endHoleAtLimit();return;}
  setShotDisabled(false);
  if(!ball.sunk){autoClub();updateShotInputs();}
}
function endHoleAtLimit(reason='limit'){
  if(round.failure)return;
  round.failure=reason;round.conceded=reason==='conceded';phase='finished';cancelCharge();keys.clear();ball.moving=false;scene.clearPath();scene.defeat();setShotDisabled(true);
  const player=round.players[round.player];player.combo=1;player.streak=0;
  if(round.mode==='challenge'){failChallenge();return;}
  player.scores[round.position]=failedHoleScore(round.strokes,round.strokeLimit);player.failures[round.position]=true;countLife(true);save();showHoleFailure();
}
function showHoleFailure(){
  const player=round.players[round.player],nextPlayer=round.mode==='multi'&&round.player<round.players.length-1,lastHole=round.position===round.indices.length-1&&!nextPlayer;
  const title=round.failure==='conceded'?'SEE YOU AT THE NEXT TEE.':'GET BETTER, NOOB!';
  const body='<div class="result-hero failed-result">'+UI.icon('target')+'<span>HOLE '+(hole.index+1)+' · DID NOT FINISH</span><h3>'+title+'</h3><p>'+round.strokes+' strokes used · '+round.strokeLimit+' allowed.<br>Marked '+player.scores[round.position]+' strokes on the scorecard. No hole prize.</p><small>Even the ducks are judging that one.</small></div>'+UI.scorecard(round,round.indices.map(i=>roundHole(i)));
  const footer=UI.button('quit','Clubhouse','button secondary')+(lastReplay.length?UI.button('replay','Replay '+UI.icon('replay'),'button secondary'):'')+UI.button('next',nextPlayer?'Next player':lastHole?'Round results':'Next hole','button primary');
  openModal(UI.modal('Stroke limit reached','A fresh tee. A fresh chance.',body,footer,true),'hole-failed');audio.play('hazard');
}
function holeComplete(){
  if(pendingResult||round.failure)return;
  phase='celebrating';audio.play('cup');scene.celebrate(hole.cup.x,hole.cup.z,round.strokes===1?2:1);
  const player=round.players[round.player];player.scores[round.position]=round.strokes;
  countLife(false);
  const under=round.strokes<hole.par;player.streak=under?player.streak+1:0;player.combo=Math.min(2,1+.25*Math.max(0,player.streak-1));
  const breakdown=rewardBreakdown(round.strokes,hole.par,{combo:player.combo,clean:round.hazards===0&&round.roughPenalties===0&&!round.conceded,tricks:round.tricks.length});
  const key='strokes-'+(round.mode==='shuffle'?'short-':round.difficulty==='expert'?'expert-':'')+hole.courseId+'-'+hole.index+'-'+round.chaos+'-'+round.remix,previous=progress.records[key];
  if(previous!==undefined&&round.strokes<previous){breakdown.best=(previous-round.strokes)*50;breakdown.total+=breakdown.best;breakdown.xp+=Math.floor(breakdown.best*.18);}
  progress.records[key]=Math.min(previous??Infinity,round.strokes);
  const reward=breakdown.total;progress.coins+=reward;round.earned+=reward;progress.xp+=breakdown.xp;progress.stats.holes++;if(under)progress.stats.underPar++;if(round.strokes===1)progress.stats.aces++;
  if(round.mode==='challenge'&&!progress.challenges.includes(round.challenge)){progress.challenges.push(round.challenge);progress.coins+=CHALLENGES[round.challenge].reward;round.earned+=CHALLENGES[round.challenge].reward;breakdown.challenge=CHALLENGES[round.challenge].reward;}
  pendingResult={title:UI.resultTitle(round.strokes,hole.par),reward,breakdown};announce(pendingResult.title,'+'+reward+' coins · '+round.strokes+' '+(round.strokes===1?'stroke':'strokes'));achievements();updateHud();
  activeTimeout=setTimeout(()=>{activeTimeout=null;if(screen==='game'&&!overlay&&!replay)showHoleResult();},1300);
}
function showHoleResult(){if(!pendingResult)return;const nextPlayer=round.mode==='multi'&&round.player<round.players.length-1;const lastHole=round.position===round.indices.length-1&&!nextPlayer;
  const body=`<div class="result-hero">${UI.icon(round.strokes===1?'star':'flag')}<span>HOLE ${hole.index+1} COMPLETE</span><h3>${pendingResult.title}</h3><p>${UI.escape(round.players[round.player].name)} · ${round.strokes} strokes · Par ${hole.par}</p><b class="coin-reward">${UI.icon('coin')} +${pendingResult.reward}</b></div>${UI.rewardSummary(pendingResult.breakdown)}${UI.scorecard(round,round.indices.map(i=>roundHole(i)))}`;
  openModal(UI.modal('Looking good out there.','',body,`${UI.button('replay','Replay shot '+UI.icon('replay'),'button secondary')}${UI.button('next',nextPlayer?'Next player '+UI.icon('users'):lastHole?'Round results '+UI.icon('trophy'):'Next hole '+UI.icon('arrow'),'button primary')}`,true),'hole-result');
}
function countLife(failed){if(round.mode==='survival'&&!round.lifeCounted){round.lifeCounted=true;round.lives=survivalLives(round.lives,round.strokes,hole.par,failed);}}
function nextHole(){if(round?.online){nextOnlineHole();return;}removeModal();if(round.mode==='survival'&&round.lives===0){finishRound();return;}if(round.mode==='multi'&&round.player<round.players.length-1){round.player++;loadHole();return;}round.player=0;if(round.position<round.indices.length-1){round.position++;loadHole();}else finishRound();}
function finishRound(){round.finished=true;phase='finished';progress.stats.rounds++;const holes=round.indices.map(i=>roundHole(i));const scores=round.players.map(p=>({name:p.name,total:p.scores.reduce((a,b)=>a+b,0),relative:p.scores.reduce((sum,s,i)=>sum+s-holes[i].par,0)}));
  const score=scores[0].relative;let reward=50,title='THAT WAS A GOOD ROUND.',subtitle='One more? There’s always one more.';
  if(round.mode==='career'){const prev=progress.career[round.course];if(prev===undefined||score<prev)progress.career[round.course]=score;const ci=COURSES.findIndex(c=>c.id===round.course);reward=score<=0?350:score<=9?220:120;title=score<=0?'GOLDEN PERFORMANCE!':score<=9?'ON THE PODIUM!':'TOURNAMENT COMPLETE';subtitle=score<=0?'Gold trophy · at or under par':score<=9?'Silver trophy · within nine over par':'Bronze trophy · all 18 holes complete';if(ci<5&&!progress.unlocked.includes(COURSES[ci+1].id)){progress.unlocked.push(COURSES[ci+1].id);subtitle+=` · ${COURSES[ci+1].name} unlocked`;}}
  if(round.mode==='time'){const key='time-'+round.course,penalized=round.elapsed;const best=progress.records[key];if(best===undefined||penalized<best){progress.records[key]=penalized;title='A NEW PERSONAL BEST!';}else title='TIME IS ON YOUR SIDE.';subtitle=`${formatTime(penalized)} · Personal best ${formatTime(progress.records[key])}`;reward=120;}
  if(round.mode==='multi'){const sorted=[...scores].sort((a,b)=>a.total-b.total);const tied=sorted.filter(p=>p.total===sorted[0].total);title=tied.length>1?'IT’S A TIE!':`${sorted[0].name.toUpperCase()} WINS!`;subtitle='Good swings. Great company.';}
  if(round.mode==='challenge'){title='CHALLENGE COMPLETE!';subtitle=CHALLENGES[round.challenge].name+' · Nailed it.';reward=30;}
  if(round.mode==='survival'){const cleared=round.players[0].scores.filter((_,i)=>!round.players[0].failures[i]).length,key='survival-'+round.course;progress.records[key]=Math.max(progress.records[key]||0,cleared);title=round.lives?'YOU SURVIVED!':'OUT OF LIVES!';subtitle=cleared+' holes finished · Best '+progress.records[key]+' · '+round.lives+' lives left';reward=round.lives?250:cleared*10;}
  if(round.mode==='shuffle'){title='EVERY CLUB. EVERY CHALLENGE.';subtitle='Six holes, six club assignments. Adaptation pays.';reward=150;}
  if(round.mode==='daily'){const key='daily-'+round.dailyDay,total=scores[0].total,best=progress.records[key];progress.records[key]=Math.min(best??Infinity,total);title=best===undefined||total<best?'DAILY PERSONAL BEST!':'DAILY CUP COMPLETE!';subtitle=round.dailyDay+' UTC · '+total+' strokes · Best '+progress.records[key];reward=best===undefined?200:75;}
  progress.coins+=reward;round.earned+=reward;progress.xp+=100;achievements();
  const body=`<div class="result-hero">${UI.icon('trophy')}<span>${MODES.find(m=>m.id===round.mode).name.toUpperCase()} COMPLETE</span><h3>${UI.escape(title)}</h3><p>${UI.escape(subtitle)}</p><b class="coin-reward">${UI.icon('coin')} ${round.earned} coins earned</b></div><div class="leaderboard">${scores.sort((a,b)=>a.total-b.total).map((p,i)=>`<div><span>${i+1}</span><b>${UI.escape(p.name)}</b><span>${p.total} strokes</span><strong>${UI.formatScore(p.relative)}</strong></div>`).join('')}</div>${UI.scorecard(round,holes)}`;
  openModal(UI.modal('A round to remember','',body,`${UI.button('quit','Clubhouse','button secondary')}${UI.button('again','Play again '+UI.icon('replay'),'button primary')}`,true),'round-result');audio.play('win');
}
function failChallenge(){phase='finished';scene.defeat();setShotDisabled(true);save();openModal(UI.modal('So close. Go again?',CHALLENGES[round.challenge].name,`<div class="result-hero">${UI.icon('target')}<h3>GET BETTER, NOOB!</h3><p>The ${CHALLENGES[round.challenge].limit}-stroke limit is up. Try adjusting your power, club, or loft.</p></div>`,`${UI.button('quit','Clubhouse','button secondary')}${UI.button('again','Try again '+UI.icon('replay'),'button primary')}`),'challenge-failed');}
function formatTime(seconds){return `${Math.floor(seconds/60)}:${Math.floor(seconds%60).toString().padStart(2,'0')}`;}
function pause(){if(reaction){finishReaction();return;}if(screen!=='game'||overlay)return;if(round.online){cancelCharge();openModal(UI.modal('Live match','Other players keep playing while this menu is open.',UI.button('close','Back to the match','button primary')+UI.button('settings','Settings','button secondary')+UI.button('quit','Leave match · forfeit','button secondary')),'pause');return;}cancelCharge();openModal(UI.modal('Take a breather.','Your round will be right here.',`<div class="pause-options">${UI.button('close',UI.icon('arrow')+' Back to the fairway','button primary')}${UI.button('settings',UI.icon('settings')+' Settings','button secondary')}${UI.button('scorecard',UI.icon('medal')+' Scorecard','button secondary')}${round.mode==='free'?UI.button('skip',UI.icon('flag')+' Explore next hole','button secondary'):''}${UI.button('concede',UI.icon('flag')+' Concede this hole','button secondary')}${UI.button('quit',UI.icon('home')+' Return to clubhouse','button text-button')}</div>`),'pause');}
function cycleCamera(){const modes=['follow','map','world'];scene.cameraMode=modes[(modes.indexOf(scene.cameraMode)+1)%modes.length];toast({follow:'Follow camera',map:'Overhead camera',world:'Scenery camera · take in the surroundings'}[scene.cameraMode]);}
function startReplay(){if(!lastReplay.length){toast('Hit a shot first. Your last shot will be saved for replay.');return;}if(ball.moving||charging){toast('Wait for the ball to stop before replaying.');return;}const returnOverlay=overlay;removeModal();replay={index:0,returnOverlay};scene.clearPath();document.querySelector('.hud')?.classList.add('replaying');toast('SHOT REPLAY · Press R or Escape to return');}
function stopReplay(){if(!replay)return;const kind=replay.returnOverlay;replay=null;document.querySelector('.hud')?.classList.remove('replaying');previewDirty=true;if(kind==='hole-result')showHoleResult();if(kind==='hole-failed')showHoleFailure();}
function drawMinimap(){const c=document.querySelector('#minimap');if(!c)return;const ctx=c.getContext('2d'),w=c.width,h=c.height,minX=Math.min(-hole.width/2-3.5,ball.x-5),maxX=Math.max(hole.width/2+3.5,ball.x+5),minZ=Math.min(-5,ball.z-5),maxZ=Math.max(hole.length+7,ball.z+5),sx=w/(maxX-minX),sz=(h-28)/(maxZ-minZ),x=v=>(v-minX)*sx,z=v=>h-12-(v-minZ)*sz;ctx.clearRect(0,0,w,h);ctx.fillStyle='#243e37';if(hole.courseId==='sky')ctx.fillRect(x(-18),z(hole.length+10),36*sx,(hole.length+17)*sz);else ctx.fillRect(0,0,w,h);ctx.strokeStyle='#75a672';ctx.lineWidth=10*sx;ctx.beginPath();for(let a=-5;a<hole.length+7;a++){if(a===-5)ctx.moveTo(x(centerAt(hole,a)),z(a));else ctx.lineTo(x(centerAt(hole,a)),z(a));}ctx.stroke();for(const [items,color] of [[hole.sand,'#e8c98f'],[hole.water,hole.courseId==='volcano'?'#ec7552':'#4fabb8'],[hole.sceneryLakes,'#4fabb8'],[hole.sceneryLakes.map(p=>p.island),'#7fa66d'],[hole.sceneryIslands,'#7fa66d'],[hole.bouncers,'#d38be7']]){ctx.fillStyle=color;for(const o of items){ctx.beginPath();ctx.ellipse(x(o.x),z(o.z),o.rx*sx,o.rz*sz,0,0,Math.PI*2);ctx.fill();}}for(const g of hole.gaps){ctx.fillStyle='#13272d';ctx.fillRect(x(-18),z(g.z+g.d/2),36*sx,g.d*sz);}for(const p of hole.platforms){ctx.fillStyle='#e8c66b';ctx.fillRect(x(movingX(p,simTime)-p.w/2),z(p.z+p.d/2),p.w*sx,p.d*sz);}for(const a of hole.walls){ctx.fillStyle='#f98e7b';ctx.fillRect(x(movingX(a,simTime)-a.w/2),z(a.z+.4),a.w*sx,2);}for(const a of hole.ramps){ctx.fillStyle='#cbbb93';ctx.fillRect(x(a.x-a.w/2),z(a.z+a.d/2),a.w*sx,a.d*sz);}for(const [items,color] of [[hole.boosts,'#76fff3'],[hole.bumpers,'#ff68b9'],[hole.tornadoes,'#bcb1ff'],[hole.gravityZones,'#8addff'],[hole.coinRings.filter(r=>!ball.collectedRings.includes(r.id)),'#ffde65']]){ctx.fillStyle=color;for(const a of items){ctx.beginPath();ctx.arc(x(a.x),z(a.z),a.id?2:3,0,Math.PI*2);ctx.fill();}}ctx.fillStyle='#bdd48e';ctx.beginPath();ctx.ellipse(x(hole.cup.x),z(hole.cup.z),6*sx,6*sz,0,0,Math.PI*2);ctx.fill();ctx.fillStyle='#ff8d76';ctx.beginPath();ctx.arc(x(hole.cup.x),z(hole.cup.z),4,0,Math.PI*2);ctx.fill();ctx.strokeStyle='#ffffff';ctx.lineWidth=1.5;ctx.beginPath();ctx.moveTo(x(ball.x),z(ball.z));ctx.lineTo(x(ball.x+Math.sin(shot.angle)*5),z(ball.z+Math.cos(shot.angle)*5));ctx.stroke();ctx.fillStyle='#fff';ctx.beginPath();ctx.arc(x(ball.x),z(ball.z),3.8,0,Math.PI*2);ctx.fill();}

app.addEventListener('click',e=>{
  const button=e.target.closest('[data-action]');if(!button||button.disabled)return;const action=button.dataset.action,id=button.dataset.id;audio.unlock();audio.play('click');
  if(action==='skip-reaction'){finishReaction();return;}
  if(action==='home'){if(screen==='game'){pause();}else{selection.mode ||= 'quick';showHome();}}
  if(action==='online'){joinOnline(id);return;}
  if(action==='online-cancel'){showHome();return;}
  if(action==='online-retry'){if(onlineData?.state==='match')online.resume();else online.join(online.mode,progress.playerName);return;}
  if(action==='online-again'){const mode=onlineData.match.mode;showHome();joinOnline(mode);return;}
  if(action==='mode'){selection.mode=id;if(id==='daily')Object.assign(selection,dailyCup());previewCourse();rerenderHome();}
  if(action==='course'){if(selection.mode==='daily'){toast('Daily Cup uses the same course for everyone today.');return;}selection.course=id;previewCourse();rerenderHome();}
  if(action==='chaos'&&CHAOS_LEVELS.some(c=>c.id===id)){selection.chaos=id;previewCourse();rerenderHome();}
  if(action==='difficulty'){selection.difficulty=id;previewCourse();rerenderHome();return;}
  if(action==='secrets-guide'){openModal(secretGuide(),'secrets');return;}
  if(action==='remix'){selection.remix++;previewCourse();rerenderHome();toast('Fresh obstacle layout · remix #'+selection.remix);}
  if(action==='style'&&canShoot()&&shot.club!=='putter'&&SHOT_STYLES.some(s=>s.id===id)){shot.style=id;updateShotInputs();}
  if(action==='powerup'&&canShoot()&&round.powerCharge&&POWERS.some(p=>p.id===id)){shot.powerUp=shot.powerUp===id?null:id;updateShotInputs();}
  if(action==='start'){
    const c=COURSES.find(x=>x.id===selection.course);
    if(!progress.unlocked.includes(c.id)&&!['free','daily'].includes(selection.mode)){
      if(progress.coins<c.price){toast(`You need ${c.price-progress.coins} more coins. Earn them in Classic or try every world in Free play.`);return;}
      progress.coins-=c.price;progress.unlocked.push(c.id);achievements();rerenderHome();toast(`${c.name} is open. Let’s play!`);return;
    }
    if(['multi','challenge','free'].includes(selection.mode))openModal(UI.setup(selection,progress),'setup');else begin();
  }
  if(action==='begin'){const names=selection.mode==='multi'?Array.from(document.querySelectorAll('.player-names input')).map((el,i)=>el.value.trim()||`Player ${i+1}`):null;begin(names);}
  if(action==='challenge-select'){selection.challenge=Number(id);openModal(UI.setup(selection,progress),'setup');}
  if(action==='select-hole'){selection.hole=Number(id);openModal(UI.setup(selection,progress),'setup');}
  if(action==='settings')openModal(UI.settings(progress),'settings');
  if(action==='sound'){settings.sound=!settings.sound;save();if(screen==='home')rerenderHome();toast(settings.sound?'Sound on':'Sound off');}
  if(action==='help')openModal(UI.help(),'help');
  if(action==='locker'){lockedTab='balls';openModal(UI.locker(progress,lockedTab),'locker');}
  if(action==='locker-tab'){lockedTab=id;openModal(UI.locker(progress,lockedTab),'locker');}
  if(action==='buy'){if(purchase(progress,button.dataset.kind,id)){save();cosmetics();openModal(UI.locker(progress,lockedTab),'locker');}else toast('A few more coins and it’s yours. Play a round to earn some.');}
  if(action==='trophies')openModal(UI.trophies(progress),'trophies');
  if(action==='close')closeModal();
  if(action==='club'&&canShoot()){shot.club=id;shot.loft=CLUBS[id].loft;updateShotInputs();}
  if(action==='pause')pause();
  if(action==='camera')cycleCamera();
  if(action==='replay'){if(replay)stopReplay();else startReplay();}
  if(action==='scorecard'&&round)openModal(UI.modal('The scorecard','Every swing tells a story.',UI.scorecard(round,round.indices.map(i=>roundHole(i))),UI.button('close','Back to the round','button primary'),true),'scorecard');
  if(action==='quit')showHome();
  if(action==='next')nextHole();
  if(action==='again'){const names=round?.mode==='multi'?round.players.map(p=>p.name):null;begin(names);}
  if(action==='skip'&&round.mode==='free'){round.position=(round.position+1)%round.indices.length;loadHole();}
  if(action==='concede'){if(round.online){showHome();return;}removeModal();endHoleAtLimit('conceded');}
});
app.addEventListener('input',e=>{
  const el=e.target;
  if(el.id.startsWith('setting-')){const key=el.id.slice(8);settings[key]=el.type==='checkbox'?el.checked:el.type==='range'?Number(el.value):el.value;if(key==='quality')scene.quality(el.value);if(key==='aimAssist'){previewDirty=true;if(!settings.aimAssist)scene.clearPath();}save();return;}
  if(!canShoot())return;
  if(el.id==='aim')shot.angle=Number(el.value)*Math.PI/180;
  if(el.id==='loft')shot.loft=Number(el.value);
  if(el.id==='power')shot.power=Number(el.value)/100;
  updateShotInputs();
});
app.addEventListener('change',e=>{if(e.target.id==='player-count'){document.querySelector('#player-names').innerHTML=Array.from({length:Number(e.target.value)},(_,i)=>`<label>Player ${i+1}<input maxlength="18" id="player-${i}" value="Player ${i+1}"/></label>`).join('');}});
app.addEventListener('pointerdown',e=>{if(e.target.closest('#swing')&&e.button===0){e.preventDefault();swingPointer=true;startCharge();}});
window.addEventListener('pointerup',()=>{if(swingPointer){swingPointer=false;releaseCharge();}});
window.addEventListener('pointercancel',cancelCharge);
canvas.addEventListener('pointerdown',e=>{if(!canShoot())return;const p=scene.groundPoint(e.clientX,e.clientY);if(p){shot.angle=Math.atan2(p.x-ball.x,p.z-ball.z);updateShotInputs();}});
window.addEventListener('keydown',e=>{
  if(e.key==='Tab'&&overlay){const list=[...document.querySelectorAll('#overlay button:not(:disabled),#overlay input,#overlay select')];if(!list.length)return;const first=list[0],last=list.at(-1);if(e.shiftKey&&document.activeElement===first){e.preventDefault();last.focus();}else if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first.focus();}return;}
  if(e.code==='Escape'){e.preventDefault();if(reaction){finishReaction();return;}if(replay)stopReplay();else if(overlay)closeModal();else pause();return;}
  if(e.target.matches('input,select,textarea')&&!(e.code==='Space'&&e.target.matches('.shot-panel input[type=range]')))return;
  if(screen!=='game'||overlay)return;
  if(['Space','ArrowLeft','ArrowRight','ArrowUp','ArrowDown'].includes(e.code))e.preventDefault();
  if(canShoot()&&!e.repeat&&e.code.startsWith('Arrow')){if(e.code==='ArrowLeft')shot.angle-=.025;if(e.code==='ArrowRight')shot.angle+=.025;if(e.code==='ArrowUp')shot.power=Math.min(1,shot.power+.02);if(e.code==='ArrowDown')shot.power=Math.max(.02,shot.power-.02);shot.angle=Math.atan2(Math.sin(shot.angle),Math.cos(shot.angle));updateShotInputs();}
  if(e.code==='Space'&&!e.repeat)startCharge();
  if(e.code==='KeyC'&&!e.repeat)cycleCamera();
  if(e.code==='KeyR'&&!e.repeat){if(replay)stopReplay();else startReplay();}
  if(['Digit1','Digit2','Digit3','Digit4'].includes(e.code)&&canShoot()){const club=Object.keys(CLUBS)[Number(e.code.at(-1))-1];if(!round.allowedClubs||round.allowedClubs.includes(club)){shot.club=club;shot.loft=CLUBS[club].loft;updateShotInputs();}}
  keys.add(e.code);
});
window.addEventListener('keyup',e=>{keys.delete(e.code);if(e.code==='Space'){releaseCharge();}});
window.addEventListener('blur',()=>{keys.clear();cancelCharge();if(screen==='game'&&!round.online&&!overlay&&!replay&&phase!=='finished')pause();});
document.addEventListener('visibilitychange',()=>{if(document.hidden){keys.clear();cancelCharge();if(screen==='game'&&!round.online&&!overlay&&!replay)pause();}});

function simulate(dt){
  simTime+=dt;
  if(ball.moving){
    stepBall(ball,hole,dt,simTime);
    if(replayFrames.length===0||ball.age-replayFrames.at(-1).t>=1/30)replayFrames.push({x:ball.x,y:ball.y,z:ball.z,t:ball.age,powerUp:ball.powerUp,collectedRings:[...ball.collectedRings]});
    const dist=shotStart?Math.hypot(ball.x-shotStart.x,ball.z-shotStart.z):0;
    progress.stats.longest=Math.max(progress.stats.longest,dist);
    if(dist>75&&!distanceBonus){distanceBonus=true;progress.coins+=20;round.earned+=20;announce('ABSOLUTELY LAUNCHED!','75m distance bonus · +20 coins');}
    const events=ball.events.splice(0);
    for(const event of events){
      if(event==='hazard'){round.shotHazard=true;round.hazards++;round.strokes++;if(round.mode==='time')round.elapsed+=10;announce(hole.courseId==='volcano'?'TOO HOT TO HANDLE!':'A LITTLE DETOUR.','Back to your last lie · +1 penalty stroke');audio.play('hazard');}
      if(event==='shield-save'){round.shotHazard=true;round.hazards++;announce('BUBBLE RESCUE!','Back to your lie · no penalty stroke');audio.play('perfect');}
      if(event.startsWith('ring:')){progress.stats.rings++;progress.coins+=30;round.earned+=30;announce('RING RICHES!','+30 coins · fly through another');audio.play('perfect');}
      const trickNames={boost:'ROCKET RUNWAY!',bumper:'PINBALL WIZARD!',tornado:'TWISTER RIDER!',moon:'ONE SMALL SWING…',bounce:'BOING!',loop:'LOOP THE LOOP!',shortcut:'SECRET SHORTCUT!'};
      if(trickNames[event]&&!round.tricks.includes(event)){round.tricks.push(event);progress.stats.tricks++;announce(trickNames[event],round.tricks.length<=5?'+35 trick coins when you finish':'Five-trick bonus is maxed out!');audio.play('perfect');}
      if(event==='magnet'){announce('CUP MAGNET!','Easy does it…');audio.play('perfect');}
      if(event==='bounce'){audio.play('bounce');}
      if(event==='loop'){audio.play('perfect');}
      if(event==='shortcut'){progress.stats.shortcuts++;audio.play('perfect');}
    }
    if(!ball.moving)completeShotWithReaction();
  }
}
async function joinOnline(mode){
 progress.playerName=document.querySelector('#online-name')?.value.trim()||sessionStorage.getItem('golf-player-name')||progress.playerName||'Golfer';sessionStorage.setItem('golf-player-name',progress.playerName);save();
 onlineNotice=null;onlineSeen=0;onlineAnimation=null;onlineData=null;await online.join(mode,progress.playerName);
}
function onlineError(message){
 if(!online.active)return;cancelCharge();
 if(round?.online){setText('online-connection','CONNECTION LOST · '+message+' · Reconnecting…');setShotDisabled(true);}
 else openModal(queueView({...online.snapshot,mode:online.mode,scope:serverScope},message),'online-queue');
}
function receiveOnline(d){
 if(d.state==='connecting'||d.state==='queue'){openModal(queueView(d),'online-queue');return;}
 if(d.state==='idle'){if(overlay==='online-queue'){openModal(queueView({mode:online.mode,scope:d.scope},'The queue expired. Tap Reconnect to join again.'),'online-queue');}else if(round?.online){phase='finished';setShotDisabled(true);openModal(UI.modal('This match has expired','Return to the clubhouse to find another match.','',UI.button('quit','Clubhouse','button primary')),'online-result');}return;}
 if(d.state!=='match')return;onlineData=d;onlineReceivedAt=Date.now();if(reaction&&performance.now()-reaction.startedAt>=reaction.duration*1000)finishReaction();const m=d.match,p=m.players.find(p=>p.id===d.you);
 const changed=!round?.online||round.matchId!==m.id||round.position!==p.position;
 if(changed){
  cancelReaction();onlineReacted=null;onlineSettled=null;scene.setRivals([]);
  clearTimeout(activeTimeout);pendingResult=null;replay=null;lastReplay=[];removeModal();onlineNotice=null;
  round={online:true,matchId:m.id,mode:m.mode,course:m.course,indices:m.indices,position:p.position,player:m.players.findIndex(p=>p.id===d.you),players:[],difficulty:'expert',chaos:m.mode==='arena'?'mayhem':'wild',remix:m.seed,elapsed:0,earned:0,strokeLimit:8,strokes:p.strokes,roughPenalties:0,hazards:0,tricks:[],powerCharge:p.charge,allowedClubs:null};
  round.pars=round.indices.map(i=>roundHole(i).par);screen='game';document.body.classList.add('playing');hole=makeHole(m.course,m.indices[p.position],{chaos:round.chaos,remix:m.seed,difficulty:'expert'});ball=structuredClone(p.ball);simTime=p.time;scene.build(hole);scene.cameraMode='follow';cosmetics();phase='ready';shot.style='straight';shot.powerUp=null;
  round.players=m.players.map(x=>({...x,combo:1,streak:0}));autoClub(true);renderHud();
  document.querySelector('.right-hud').insertAdjacentHTML('afterbegin','<div id="online-board" class="online-board"></div><div id="online-connection" class="online-connection" role="status"></div>');
  onlineSeen=p.lastShot?.position===p.position&&p.readyAt>d.serverTime?p.sequence-1:p.sequence;announce(p.position?'NEXT HOLE!':'MATCH FOUND!',p.position?hole.name:m.players.map(p=>p.name).join(' vs '));
 }
 round.players=m.players.map(x=>({...x,combo:1,streak:0}));round.earned=p.prize;
 document.querySelector('#online-board').innerHTML=onlineBoard(d);setText('online-connection',d.scope==='public'?'CONNECTED · PUBLIC MATCH':'CONNECTED · LOCAL MATCH');
 if(p.sequence>onlineSeen&&p.lastShot){
  onlineSeen=p.sequence;onlineAnimation={shot:{...p.lastShot,at:performance.now()},end:performance.now()+Math.max(0,p.readyAt-d.serverTime),sequence:p.sequence};
  onlineAnimation.shot.duration=Math.max(50,p.readyAt-d.serverTime);phase='flying';setShotDisabled(true);scene.clearPath();scene.swing();audio.play('hit');
  lastReplay=p.lastShot.frames.map((f,i)=>({...f,t:i/12,powerUp:p.lastShot.powerUp}));
 }
 // Background tabs can suspend requestAnimationFrame; server time still settles shots.
 if(onlineAnimation&&p.readyAt<=d.serverTime)onlineAnimation=null;
 if(overlay==='online-hole'){const body=document.querySelector('.modal-body');if(body)body.innerHTML=onlineBoard(d);}
 if(!onlineAnimation&&phase!=='sending')settleOnline();
}
function settleOnline(){
 if(!round?.online||!onlineData||reaction)return;const d=onlineData,m=d.match,p=m.players.find(p=>p.id===d.you);
 ball=structuredClone(p.ball);simTime=p.time;round.strokes=p.strokes;round.powerCharge=p.charge;round.hazards=p.penalties;round.failure=p.failures[p.position]?'limit':null;
 const stateKey=m.id+'-'+p.position+'-'+p.sequence,needsAim=onlineSettled!==stateKey;onlineSettled=stateKey;if(needsAim)shot.powerUp=null;
 if(needsAim&&onlineReacted!==stateKey&&p.lastShot?.position===p.position){onlineReacted=stateKey;const r=chooseReaction(p.ball.reactions);if(r){startReaction(r,()=>{onlineSettled=null;settleOnline();});return;}}
 const notice=m.status==='finished'?'match':p.holeDone?'hole-'+p.position:null;
 if(notice&&notice!==onlineNotice){
  onlineNotice=notice;phase='finished';setShotDisabled(true);
  if(m.status==='finished'){
   // Persist the claim before showing a replayable result screen.
   Object.assign(progress,loadProgress(localStorage),{settings});progress.onlineClaims ||= [];
   if(!progress.onlineClaims.includes(m.id)){progress.onlineClaims.push(m.id);progress.onlineClaims=progress.onlineClaims.slice(-200);progress.coins+=p.prize;progress.xp+=p.xp;if(p.status!=='forfeit'){for(const id of p.secrets||[])rememberSecret(id,false);progress.stats.birdHits+=p.birdHits||0;progress.stats.rounds++;progress.stats.holes+=p.scores.filter((_,i)=>!p.failures[i]).length;progress.stats.aces+=p.scores.filter((s,i)=>s===1&&!p.failures[i]).length;}achievements();}
   round.finished=true;openModal(onlineResult(d),'online-result');audio.play('win');
  }else{
   if(ball.sunk){scene.celebrate(hole.cup.x,hole.cup.z,p.strokes===1?2:1);audio.play('cup');}else scene.defeat();
   const title=p.failures[p.position]?'GET BETTER, NOOB!':UI.resultTitle(p.strokes,hole.par),waiting=p.position===2;
   openModal(UI.modal(title,waiting?'Your round is done. Waiting for the other players…':`Hole ${p.position+1}/3 · ${p.strokes} strokes · ${p.prize} coins pending`,onlineBoard(d),UI.button('quit','Leave match · forfeit','button secondary')+(waiting?'':UI.button('next','Next hole','button primary')),true),'online-hole');
  }
 }else if(!notice){phase='ready';setShotDisabled(!online.healthy);if(needsAim){autoClub();updateShotInputs();}}
 updateHud();
}
async function submitOnlineShot(params){
 if(online.pending)return;cancelCharge();phase='sending';setShotDisabled(true);scene.clearPath();
 const p=onlineData.match.players.find(p=>p.id===onlineData.you),angle=Math.atan2(Math.sin(params.angle),Math.cos(params.angle));
 try{await online.command('shot',{sequence:p.sequence,nonce:crypto.randomUUID(),shot:{...params,angle,style:params.style||'straight',powerUp:params.powerUp||null}});}catch{phase='ready';}
}
async function nextOnlineHole(){
 const p=onlineData.match.players.find(p=>p.id===onlineData.you);try{await online.command('next',{sequence:p.sequence});}catch(error){toast(error.message);}
}
function updateOnlineFrame(now){
 if(!onlineData)return;const d=onlineData,m=d.match,p=m.players.find(p=>p.id===d.you);
 if(onlineAnimation){const f=frameAt(onlineAnimation.shot,now);if(f)Object.assign(ball,f,{moving:true});simTime=p.time*(Math.min(1,(now-onlineAnimation.shot.at)/onlineAnimation.shot.duration));if(now>=onlineAnimation.end){const events=p.lastShot?.events||[];onlineAnimation=null;if(events.includes('rough'))announce('THAT’S ROUGH!','Dark grass · +1 stroke · play from here');else if(events.includes('hazard'))announce('A LITTLE DETOUR.','Back to your lie · +1 penalty stroke');settleOnline();}}
 const serverNow=d.serverTime+Math.max(0,Date.now()-(onlineReceivedAt||Date.now()));
 scene.setRivals(m.players.filter(x=>x.id!==d.you&&x.position===p.position&&x.status!=='forfeit').map(x=>({id:x.id,name:x.name,color:rivalColors[m.players.indexOf(x)],...(x.lastShot?.position===x.position?frameAt(x.lastShot,serverNow):x.ball)})));
}
let onlineReceivedAt=0;
function frame(now){const realDelta=(now-last)/1000,dt=Math.min(realDelta,.25);last=now;
  if(screen==='home'){simTime+=dt;}
  else if(!reaction&&!overlay&&!replay&&phase!=='finished'&&phase!=='celebrating'){
    if(round.mode==='time'&&!round.finished)round.elapsed+=realDelta;
    if(!round.online){accumulator+=dt;while(accumulator>=STEP){simulate(STEP);accumulator-=STEP;}}
    if(canShoot()&&keys.size){let changed=false;if(keys.has('ArrowLeft')){shot.angle-=dt*.65;changed=true;}if(keys.has('ArrowRight')){shot.angle+=dt*.65;changed=true;}if(keys.has('ArrowUp')){shot.power=Math.min(1,shot.power+dt*.35);changed=true;}if(keys.has('ArrowDown')){shot.power=Math.max(.02,shot.power-dt*.35);changed=true;}if(changed){shot.angle=Math.atan2(Math.sin(shot.angle),Math.cos(shot.angle));updateShotInputs();}}
    if(charging){timing=chargeValue(now-charging);setText('power-value',Math.round(swingStrength(shot.power,timing)*100)+'% / '+Math.round(shot.power*100)+'%');const marker=document.querySelector('#timing-marker');if(marker)marker.style.left=timing*100+'%';}
    if(previewDirty&&now-previewAt>80&&settings.aimAssist&&!ball.moving&&!ball.sunk){const p=predict(ball,hole,shot,simTime,hole.difficulty==='expert'?144:1800).points;scene.showPath(hole.difficulty==='expert'?p.slice(0,12):p,hole.difficulty==='expert');previewDirty=false;previewAt=now;}
  }
  if(reaction){reaction.age=(now-reaction.startedAt)/1000;if(reaction.age>=reaction.duration)finishReaction();}
  if(round?.online)updateOnlineFrame(now);
  let renderedBall=ball;
  if(replay){replay.index+=dt*30*.7;const f=lastReplay[Math.floor(replay.index)];if(f)renderedBall={...ball,...f};else stopReplay();}
  scene.setCharge(charging?Math.min(1,(now-charging)/650):0);
  scene.draw(renderedBall,shot.angle,simTime,dt,{home:screen==='home',moving:ball.moving||!!replay,replay:!!replay});
  if(screen==='game'&&now-lastHud>100){updateHud();lastHud=now;}
  if(!round?.online&&phase==='celebrating'&&!overlay&&!replay&&pendingResult&&!activeTimeout)showHoleResult();
  audio.update();requestAnimationFrame(frame);
}

// The local QA interface drives the same shot and scoring paths as the controls.
if(['localhost','127.0.0.1'].includes(location.hostname)&&new URLSearchParams(location.search).has('qa'))window.golfQA={
  state:()=>({screen,phase,reaction:reaction?{kind:reaction.data.kind,age:reaction.age}:null,selection:{...selection},result:pendingResult,hole:hole.index,course:hole.courseId,ball:{...ball},shot:{...shot},round:round?JSON.parse(JSON.stringify(round)):null,overlay,progress:JSON.parse(JSON.stringify(progress))}),
  start:(mode='quick',course='classic',challenge=0,names,options={})=>{selection={...selection,mode,course,challenge,...options};begin(names);},
  shoot:params=>fireShot(params,true),
  advance:(skipScenes=true)=>{if(round.online)return;for(let i=0;i<3600&&ball.moving;i++){if(round.mode==='time')round.elapsed+=STEP;simulate(STEP);}if(skipScenes&&reaction)finishReaction();},
  skipReaction:()=>finishReaction(),
  next:()=>nextHole(),
  scenery:()=>({counts:scene.sceneryCounts,actors:scene.sceneryActors.map(a=>({type:a.type||a.kind,x:a.root.position.x,y:a.root.position.y,z:a.root.position.z}))}),
  candidates:()=>({hole,ball:{...ball},time:simTime,allowed:round.allowedClubs}),
  predict:params=>predict(ball,hole,params,simTime).ball,
  close:()=>removeModal(),
  home:()=>showHome(),
};
online=new OnlineClient(receiveOnline,onlineError);
showHome();requestAnimationFrame(frame);
if(online.token)online.request('state').then(d=>{if(d.state==='match'&&d.match.status==='playing'){online.active=true;online.deliver(d,online.generation);online.schedule();}}).catch(()=>{});
