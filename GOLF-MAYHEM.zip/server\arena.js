import {makeHole,COURSES,CLUBS,terrainAt} from '../src/courses.js';
import {createBall,strike,stepBall,STEP} from '../src/physics.js';
import {SHOT_STYLES,POWERS} from '../src/mayhem.js';
import {roughPenalty,limitReached,failedHoleScore} from '../src/rules.js';
import {rewardBreakdown} from '../src/progress.js';

export const ARENA_PROTOCOL=1;
export const freshArena=()=>({sessions:{},queue:[],matches:{}});
export class ArenaError extends Error{constructor(status,message){super(message);this.status=status;}}
const reject=(status,message)=>{throw new ArenaError(status,message);};
const cleanName=name=>String(name||'Golfer').normalize('NFC').replace(/[<>\u0000-\u001f\u007f]/g,'').trim().slice(0,18)||'Golfer';
const clone=value=>JSON.parse(JSON.stringify(value));
export function arenaHole(match,player){return makeHole(match.course,match.indices[Math.min(player.position,2)],{chaos:match.mode==='arena'?'mayhem':'wild',remix:match.seed,difficulty:'expert'});}
function newLie(match,p){const h=arenaHole(match,p);p.ball=createBall(h.tee.x,h.tee.z);p.strokes=0;p.charge=1;p.penalties=0;p.time=0;p.holeDone=false;}
function finishMatch(m,now){
 const active=m.players.filter(p=>p.status!=='forfeit');
 if(m.status!=='playing')return;
 if(active.length<=1||m.players.every(p=>p.status!=='playing')){
  m.status='finished';m.finishedAt=now;m.revision++;const totals=active.map(p=>p.scores.reduce((a,b)=>a+b,0));const best=Math.min(...totals);
  m.winners=active.filter(p=>active.length===1||p.scores.reduce((a,b)=>a+b,0)===best).map(p=>p.id);
  for(const p of m.players){p.prize=p.status==='forfeit'?0:p.prize+(m.winners.includes(p.id)?200:75);if(p.status==='forfeit')p.xp=0;}
 }
}
function forfeit(m,id,now){const p=m.players.find(p=>p.id===id);if(!p||p.status==='forfeit'||m.status!=='playing')return;p.status='forfeit';while(p.scores.length<3)p.scores.push(9);m.revision++;finishMatch(m,now);}
function startMatch(state,entries,now){
 const seed=Math.floor(Math.random()*100000),id=crypto.randomUUID(),m={id,mode:entries[0].mode,course:COURSES[seed%6].id,seed,indices:[0,1+seed%8,10+seed%8],revision:1,status:'playing',createdAt:now,players:[],winners:[]};
 for(const e of entries){const s=state.sessions[e.key];if(!s)continue;s.match=id;const p={id:s.id,name:s.name,status:'playing',position:0,scores:[],failures:[],sequence:0,readyAt:0,lastSeen:now,lastShot:null,prize:0,xp:0};newLie(m,p);m.players.push(p);}
 state.queue=state.queue.filter(e=>!entries.includes(e));state.matches[id]=m;return m;
}
function sweep(state,now){
 state.queue=state.queue.filter(e=>state.sessions[e.key]&&now-state.sessions[e.key].seen<30000);
 for(const mode of ['duel','arena']){let q=state.queue.filter(e=>e.mode===mode);while(q.length>=(mode==='duel'?2:4)||(mode==='arena'&&q.length>=2&&now-q[0].joined>=20000)){startMatch(state,q.slice(0,mode==='duel'?2:4),now);q=state.queue.filter(e=>e.mode===mode);}}
 for(const m of Object.values(state.matches)){
  if(m.status==='playing'){for(const p of m.players)if(p.status==='playing'&&now-p.lastSeen>90000)forfeit(m,p.id,now);}
  if(now-(m.finishedAt||m.createdAt)>1800000)delete state.matches[m.id];
 }
 for(const [key,s] of Object.entries(state.sessions))if(now-s.seen>1800000)delete state.sessions[key];
}
function view(state,s,now){
 const m=s.match&&state.matches[s.match];if(m)return {state:'match',you:s.id,match:clone(m),serverTime:now};
 const q=state.queue.find(e=>e.key===s.key);if(q){const members=state.queue.filter(e=>e.mode===q.mode);return {state:'queue',mode:q.mode,waiting:members.length,capacity:q.mode==='duel'?2:4,startsIn:q.mode==='arena'&&members.length>=2?Math.max(0,20000-(now-members[0].joined)):null,serverTime:now};}
 return {state:'idle',you:s.id,serverTime:now};
}
export function arenaCommand(state,action,body,key,now=Date.now()){
 if(action==='session'){
  sweep(state,now);if(Object.keys(state.sessions).length>=200)reject(503,'The clubhouse is full. Try again shortly.');
  const s={key,id:crypto.randomUUID(),name:cleanName(body.name),seen:now,match:null};state.sessions[key]=s;sweep(state,now);return {id:s.id,name:s.name};
 }
 if(action==='status'){sweep(state,now);return {protocol:ARENA_PROTOCOL,players:Object.values(state.sessions).filter(s=>now-s.seen<30000).length,queued:state.queue.length};}
 const s=state.sessions[key];if(!s)reject(401,'Your session expired. Reconnect to the clubhouse.');
 s.seen=now;const current=s.match&&state.matches[s.match];const me=current?.players.find(p=>p.id===s.id);if(me)me.lastSeen=now;sweep(state,now);
 if(action==='state')return view(state,s,now);
 if(action==='join'){
  if(!['duel','arena'].includes(body.mode))reject(400,'Unknown online mode.');
  if(current?.status==='playing'&&me?.status==='playing')return view(state,s,now);
  if(body.name)s.name=cleanName(body.name);s.match=null;state.queue=state.queue.filter(e=>e.key!==key);state.queue.push({key,mode:body.mode,joined:now});sweep(state,now);return view(state,s,now);
 }
 if(action==='leave'){state.queue=state.queue.filter(e=>e.key!==key);if(current)forfeit(current,s.id,now);s.match=null;return view(state,s,now);}
 if(!current||!me)reject(409,'No active match.');
 if(action==='shot'){
  if(typeof body.nonce!=='string'||body.nonce.length<8||body.nonce.length>80)reject(400,'Invalid shot identifier.');
  if(me.lastShot?.nonce===body.nonce)return view(state,s,now);
  if(current.status!=='playing'||me.status!=='playing'||me.holeDone)reject(409,'This hole has already ended.');
  if(body.sequence!==me.sequence)reject(409,'The score changed. Sync the match before swinging.');
  if(now<me.readyAt)reject(429,'Wait for your ball to stop.');
  const a=body.shot||{};if(!Object.hasOwn(CLUBS,a.club)||!SHOT_STYLES.some(x=>x.id===a.style)||![a.power,a.angle,a.loft].every(Number.isFinite))reject(400,'Invalid shot.');
  const club=CLUBS[a.club];if(a.power<.02||a.power>1||Math.abs(a.angle)>Math.PI+.001||a.loft<club.min||a.loft>club.max)reject(400,'Shot is outside the club limits.');
  if(a.powerUp!==null&&a.powerUp!==undefined&&(!POWERS.some(p=>p.id===a.powerUp)||!me.charge))reject(400,'No special shot available.');
  const h=arenaHole(current,me),b=me.ball;strike(b,h,{...a,time:me.time});if(a.powerUp)me.charge=0;me.strokes++;const frames=[{x:b.x,y:b.y,z:b.z}],events=[];let hazard=false;
  for(let i=0;i<3600&&b.moving;i++){me.time+=STEP;stepBall(b,h,STEP,me.time);if(i%10===0)frames.push({x:b.x,y:b.y,z:b.z});for(const e of b.events.splice(0)){events.push(e);if(e==='hazard'){me.strokes++;me.penalties++;hazard=true;}if(e==='shield-save'){me.penalties++;hazard=true;}}}
  frames.push({x:b.x,y:b.y,z:b.z});const rough=roughPenalty(b,terrainAt(h,b.x,b.z,me.time),hazard);me.strokes+=rough;me.penalties+=rough;if(rough)events.push('rough');
  if(b.secretAce)me.strokes=1;me.secrets ||= [];for(const id of b.foundSecrets||[])if(!me.secrets.includes(id))me.secrets.push(id);if(b.reactions?.some(r=>r.kind==='bird'))me.birdHits=(me.birdHits||0)+1;
  const failed=limitReached(me.strokes,8,b.sunk);if(failed||b.sunk){me.holeDone=true;me.scores[me.position]=failed?failedHoleScore(me.strokes,8):me.strokes;me.failures[me.position]=failed;if(!failed){const r=rewardBreakdown(me.strokes,h.par,{clean:me.penalties===0});me.prize+=r.total;me.xp+=r.xp;}if(me.position===2){me.status='finished';}}
  me.sequence++;me.readyAt=now+Math.max(600,Math.min(10000,b.age*1000));me.lastShot={nonce:body.nonce,sequence:me.sequence,position:me.position,frames,events,duration:me.readyAt-now,at:now,powerUp:a.powerUp||null};current.revision++;finishMatch(current,now);return view(state,s,now);
 }
 if(action==='next'){
  if(body.sequence!==me.sequence)reject(409,'The match changed. Sync and try again.');
  if(!me.holeDone||me.position>=2||current.status!=='playing')reject(409,'Finish the current hole first.');
  if(now<me.readyAt)reject(429,'Your ball is still settling.');me.position++;newLie(current,me);current.revision++;return view(state,s,now);
 }
 reject(404,'Unknown matchmaking action.');
}

export class MemoryArenaStore{
 constructor(state=freshArena(),persist=null){this.state=state;this.persist=persist;this.tail=Promise.resolve();}
 transaction(fn){const run=this.tail.then(async()=>{const next=clone(this.state),result=fn(next);if(this.persist)await this.persist(next);this.state=next;return result;});this.tail=run.catch(()=>{});return run;}
}
