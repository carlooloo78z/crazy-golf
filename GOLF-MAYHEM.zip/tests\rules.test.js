import test from 'node:test';
import assert from 'node:assert/strict';
import {strokeLimit,roughPenalty,limitReached,failedHoleScore} from '../src/rules.js';
import {COURSES,CHALLENGES,makeHole,terrainAt} from '../src/courses.js';
import {createBall,strike,stepBall,STEP,RADIUS} from '../src/physics.js';

test('all normal modes share an eight-stroke budget and challenges keep their own limit',()=>{
 for(const mode of ['quick','career','time','free','multi'])assert.equal(strokeLimit(mode,CHALLENGES[0]),8);
 for(const challenge of CHALLENGES)assert.equal(strokeLimit('challenge',challenge),challenge.limit);
 assert.equal(limitReached(7,8),false);assert.equal(limitReached(8,8),true);assert.equal(limitReached(8,8,true),false);assert.equal(limitReached(9,8,true),true);assert.equal(failedHoleScore(8,8),9);assert.equal(failedHoleScore(10,8),10);
});
test('rough costs one stroke only when a live shot settles there, never for a hazard return',()=>{
 const b=createBall();assert.equal(roughPenalty(b,{type:'rough'}),1);assert.equal(roughPenalty({...b,moving:true},{type:'rough'}),0);assert.equal(roughPenalty({...b,sunk:true},{type:'rough'}),0);assert.equal(roughPenalty(b,{type:'rough'},true),0);
 for(const type of ['fairway','green','sand','water','void'])assert.equal(roughPenalty(b,{type}),0);
});
test('landscape lakes are real water and their visible island centres are solid rough',()=>{
 for(const course of COURSES.filter(c=>c.id!=='sky'))for(const index of [0,5,12,17]){
  const h=makeHole(course.id,index);assert.equal(h.sceneryLakes.length,2);
  for(const p of h.sceneryLakes){assert.equal(terrainAt(h,p.x-p.rx*.7,p.z).type,'water');assert.equal(terrainAt(h,p.island.x,p.island.z).type,'rough');
   const b=createBall(p.x-p.rx*.7,p.z);b.y=p.level+RADIUS;b.moving=true;b.safe={...h.tee};stepBall(b,h);assert.ok(b.events.includes('hazard'),'an elevated lake must trigger immediately');
  }
 }
});
test('new floating islands support real landing shots while the surrounding gaps remain void',()=>{
 const h=makeHole('sky',0),island=h.sceneryIslands[0],b=createBall(island.x,island.z);b.y=island.y+3;b.moving=true;
 for(let i=0;i<600&&b.moving;i++)stepBall(b,h,STEP,i*STEP);assert.equal(b.moving,false);assert.equal(b.events.includes('hazard'),false);assert.ok(Math.abs(b.y-island.y-RADIUS)<.001);assert.equal(terrainAt(h,island.x+island.rx+2,island.z).type,'void');
 strike(b,h,{club:'putter',power:.2,angle:0,loft:0});for(let i=0;i<600&&b.moving;i++)stepBall(b,h,STEP,i*STEP);assert.equal(b.events.includes('hazard'),false);
});
