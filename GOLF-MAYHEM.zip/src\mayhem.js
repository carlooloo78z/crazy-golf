export const CHAOS_LEVELS=[
 {id:'chill',name:'Chill',description:'Original obstacles. Your own pace.'},
 {id:'wild',name:'Wild',description:'A rotating stunt event on every hole.'},
 {id:'mayhem',name:'Mayhem',description:'Boosts, bumpers, tornadoes and moon zones together.'},
];
export const SHOT_STYLES=[
 {id:'straight',name:'Straight',mark:'↑',description:'The standard flight and roll.'},
 {id:'draw',name:'Draw',mark:'↶',description:'Curve the ball left in the air.'},
 {id:'fade',name:'Fade',mark:'↷',description:'Curve the ball right in the air.'},
 {id:'backspin',name:'Backspin',mark:'↺',description:'A higher, softer shot that checks on landing.'},
 {id:'punch',name:'Punch',mark:'➝',description:'Stay low under obstacles and run along the fairway.'},
];
export const POWERS=[
 {id:'rocket',name:'Rocket',icon:'bolt',description:'25% more launch speed on your next shot.'},
 {id:'shield',name:'Bubble',icon:'globe',description:'Your next shot gets one penalty-free hazard rescue.'},
 {id:'magnet',name:'Magnet',icon:'target',description:'Slow down and bend toward the cup inside 3 metres.'},
];
const randomFrom=seed=>()=>{seed=(seed*1664525+1013904223)>>>0;return seed/4294967296;};
export function populateMayhem(hole,options={}){
 const chaos=CHAOS_LEVELS.some(l=>l.id===options.chaos)?options.chaos:'chill',remix=Math.max(0,Math.floor(options.remix||0));
 Object.assign(hole,{chaos,remix,boosts:[],bumpers:[],tornadoes:[],gravityZones:[],coinRings:[],eventName:'Classic rules'});
 if(chaos==='chill')return hole;
 const rand=randomFrom(hole.seed+remix*1913),pattern=(hole.index+Math.floor(rand()*6)+remix)%6,lane=(rand()-.5)*4;
 const zAt=f=>{let z=hole.length*f;for(const g of hole.gaps)if(Math.abs(z-g.z)<g.d/2+2)z=g.z-g.d/2-3;return z;};
 const all=chaos==='mayhem';
 hole.eventName=all?'TOTAL MAYHEM':['Rocket runway','Pinball park','Moon pocket','Twister alley','Ring rush','Portal party'][pattern];
 if(all||pattern===0||pattern===4)hole.boosts.push({id:'boost-0',x:lane+2,z:zAt(.32),w:3,d:4,kick:9});
 if(all||pattern===1||pattern===4)for(let i=0;i<2;i++)hole.bumpers.push({id:'bumper-'+i,x:(i?1:-1)*(3+rand()),z:zAt(.48)+i*4,r:1.05,h:1.7,kick:5});
 if(all||pattern===2)hole.gravityZones.push({id:'moon-0',x:lane-3,z:zAt(.36),r:4.5,height:9,gravity:.3});
 if(all||pattern===3)hole.tornadoes.push({id:'twister-0',x:lane+6,z:zAt(.62),r:3.7,height:10,strength:6});
 if(pattern===5&&!all)hole.shortcuts.push({x:-8,z:zAt(.35),toX:hole.cup.x-2,toZ:hole.cup.z-7});
 for(let i=0;i<(all?4:3);i++)hole.coinRings.push({id:'ring-'+i,x:lane+(i%2?2:-2),y:1.8+(i%2)*2.2,z:zAt(.23+i*.16),r:1.3});
 return hole;
}

export function gravityMultiplier(ball,hole){
 return (hole.gravityZones||[]).some(z=>Math.hypot(ball.x-z.x,ball.z-z.z)<z.r&&ball.y<z.height)?.3:1;
}
export function applyMayhem(ball,hole,dt,radius){
 const once=(id,event)=>{ball.stunts ||= [];if(ball.stunts.includes(id))return false;ball.stunts.push(id);ball.events.push(event);return true;};
 for(const b of hole.boosts||[])if(Math.abs(ball.x-b.x)<b.w/2&&Math.abs(ball.z-b.z)<b.d/2&&ball.y<.8&&once(b.id,'boost')){const a=Math.atan2(hole.cup.x-b.x,hole.cup.z-b.z);ball.vx+=Math.sin(a)*b.kick;ball.vz+=Math.cos(a)*b.kick;ball.vy=Math.max(ball.vy,2.5);}
 for(const b of hole.bumpers||[]){const dx=ball.x-b.x,dz=ball.z-b.z,d=Math.hypot(dx,dz);if(d<b.r+radius&&ball.y<b.h+radius){const nx=dx/(d||1),nz=dz/(d||1),normal=ball.vx*nx+ball.vz*nz;ball.x=b.x+nx*(b.r+radius+.01);ball.z=b.z+nz*(b.r+radius+.01);if(normal<0){ball.vx-=normal*1.8*nx;ball.vz-=normal*1.8*nz;ball.vx+=nx*b.kick;ball.vz+=nz*b.kick;ball.vy=Math.max(1.2,ball.vy);once(b.id,'bumper');}}}
 for(const t of hole.tornadoes||[]){const dx=ball.x-t.x,dz=ball.z-t.z,d=Math.hypot(dx,dz);if(d<t.r&&ball.y<t.height){const f=1-d/t.r;ball.vx+=(-dz/(d||1)*t.strength-dx*.6)*f*dt;ball.vz+=(dx/(d||1)*t.strength-dz*.6)*f*dt;ball.vy+=12*f*dt;once(t.id,'tornado');}}
 for(const z of hole.gravityZones||[])if(Math.hypot(ball.x-z.x,ball.z-z.z)<z.r&&ball.y<z.height&&ball.y>.4)once(z.id,'moon');
 for(const ring of hole.coinRings||[])if(!ball.collectedRings.includes(ring.id)&&Math.hypot(ball.x-ring.x,ball.y-ring.y)<ring.r&&Math.abs(ball.z-ring.z)<.45){ball.collectedRings.push(ring.id);ball.events.push('ring:'+ring.id);}
 if(ball.powerUp==='magnet'&&ball.y<.8){const dx=hole.cup.x-ball.x,dz=hole.cup.z-ball.z,d=Math.hypot(dx,dz);if(d<3&&d>.1){const pull=3+2.2/d;ball.vx=(ball.vx+dx*pull*dt)*Math.exp(-2.4*dt);ball.vz=(ball.vz+dz*pull*dt)*Math.exp(-2.4*dt);once('magnet','magnet');}}
}
