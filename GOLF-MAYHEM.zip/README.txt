GOLF MAYHEM
===========
A self-contained 3D browser arcade golf game. Requires Node.js 22+ to serve
and a modern browser with WebGL 2. All rendering code is bundled locally.
There are no package dependencies or runtime CDNs. The included Node server
provides real multiplayer matchmaking; player accounts are not required.

PLAY
  Double-click "Play GOLF MAYHEM.cmd" to start the local server and open
  the game in your browser. The launcher reuses an already running server.
  The http://127.0.0.1 link works on this computer while the server is running.

  Or start it from a terminal:
  cd F:\sure\golf-mayhem
  npm run dev
  Open http://127.0.0.1:5173

BUILD
  npm run build
  npm run preview
  Static hosting supports the nine offline modes. Online modes require the
  included server: npm start. See HOSTING.txt for public deployment. Do not open
  index.html directly using a file:// URL: ES modules require an HTTP server.

CONTROLS
  Arrow left/right or tap course: aim
  Arrow up/down or power slider: shot strength
  1, 2, 3, 4: driver, iron, wedge, putter
  Loft slider: shot height
  Strength slider: maximum power; its setting stays between shots
  Hold Space or Swing: build actual strength; release early for a gentle tap
  Release in green: full selected strength and best accuracy
  Holding beyond green keeps full selected strength; it never cycles to zero
  C: cycle follow, overhead and scenery cameras
  R: replay last shot
  Escape: pause / return from replay
  Touch: all controls are available on screen
  Shot style buttons: Straight, Draw, Fade, Backspin or Punch
  Power buttons: arm Rocket, Bubble or Magnet; tap again to cancel
  Each player gets one optional special shot per hole, consumed on swing.
  Powers refill on the next hole. Challenges use fixed rules without powers.

MODES
  Eight strokes per hole, including penalties. Challenges keep their own
  tighter limits. The final allowed stroke can still go in. If it misses,
  the hole ends with "GET BETTER, NOOB!", a DNF and no hole prize.
  A normal DNF scores at least 9. Continue to the next hole/player.
  Quick play: three holes.
  Career: 18-hole tournaments; finish to unlock the next course.
  Challenges: six trials with stroke limits and club/wind variations.
  Time attack: nine holes; hazards add 10 seconds and a stroke.
  Free play: all six courses available immediately, selectable starting hole.
  Multiplayer: 2-4 local players, nine holes, pass screen after each hole.
  Survival: nine holes, three lives. An over-par hole or DNF costs a life.
  Club Shuffle: six short holes, a required club assigned at each tee.
  Daily Cup: a fixed six-hole route changes daily at midnight UTC. All courses
    are available in this mode. Beat your saved daily personal best.
  Online Duel: a real 1v1, three holes, simultaneous play, lowest total wins.
  Mayhem Arena: 2-4 real players, three holes with maximum chaos. Starts with
    four immediately or at least two after a 20-second lobby countdown.
  Click either online mode to join its queue. Nobody online? The queue waits.
  Live scores and rival balls appear in the game. Reload reconnects to a match;
  90 seconds of inactivity forfeits. Leaving a live match forfeits its rewards.
  Prizes bank at match end: hole prizes +200 for winners or +75 for finishers.
  The local server is not a worldwide public server. See HOSTING.txt.

COURSES
  Classic, Desert, Tropical, Sky, Volcano, Neon: 18 seeded authored layouts
  per theme, 108 total. Moving walls/platforms, ramps, fans, tunnels, loops,
  bounce pads, hazard water/lava, bunkers, and shortcut gates affect physics.
  Dark grass and the surrounding hills are playable rough. The ball slows
  down there. A shot that stops on dark grass costs one extra stroke, and
  your next shot starts where it stops. Replays never repeat the penalty.
  Returning to a rough lie after a water/void hazard does not double-charge.
  Trees now have trunk/crown collisions. Hitting one triggers an angry-bird
  close-up. Water splashes and bunker landings trigger duck/crab reactions.
  Skip or Escape dismisses a reaction; it adds no extra penalty. Solo Time
  Attack pauses for cutscenes. Online opponents continue their own game.
  Water/lava, gaps and falling off floating islands
  remain hazards. Loops use a guided momentum-preserving arcade traversal.
  The surroundings now include two lakes with wooded islands on each land
  course, three extra floating islands in Sky, more trees, deer, foxes,
  rabbits, swimming ducks, flying birds, walking people, benches and shade
  umbrellas. People and wildlife are decorative. Lakes have water physics;
  island ground supports the ball. Scenery camera shows the wider setting.

MORE MAYHEM
  Expert is now the default: smaller cups, faster greens, stronger wind and
  only the first part of the flight preview. Choose Arcade in the clubhouse
  for the earlier putting/preview rules. Online uses Expert; fixed trials
  use Arcade. All 108 holes remain playable.
  Six hidden routes appear on holes 1, 7 and 13 of their respective worlds.
  The oak and coconut nests award secret hole-in-ones even after earlier
  strokes. Other routes take the ball into the cup or leave a two-metre putt.
  Secret entrances catch nearby misses at any height.
  Their clues stay small and hidden; rolling nearby or flying over both count.
  New local discoveries award 150 coins once; all six earn a trophy (+450).
  Full locations and tested starting shots are in SECRET-GUIDE.txt, or
  How to play > Reveal secret guide. No secret markers appear on the map.
  The spoiler guide includes a location diagram for each secret, showing the
  direction and distance from the tee. Amber arches also work at any height.
  Cup detection catches the whole ball path across the opening at any speed,
  including descending airborne shots before they can bounce off the green.
  Choose Chill for original layouts, Wild for a rotating obstacle event,
  or Mayhem for boosts, bumpers, tornadoes and moon-gravity zones together.
  Remix reshuffles the arcade obstacle placement for the selected round.
  Rocket boosts launch speed by 25%; Bubble rescues one hazard without a
  penalty; Magnet slows and pulls a nearby ball toward the cup within 3m.
  Draw/Fade curve airborne shots; Backspin checks on landing; Punch stays
  low and runs. Putter shots remain straight. Shot previews include powers,
  spin, wind, obstacles and surface physics.

REWARDS
  Hole base prizes: hole in one 500, albatross 320+, eagle 220, birdie 120,
  par 50, bogey 30. Each stroke saved below par adds 40 coins. A clean
  par-or-better hole adds 25. A clean par-3 ace starts at 605 coins.
  Consecutive under-par holes add 0.25 to the multiplier after the first,
  up to x2. Each new obstacle trick type adds 35 at the cup, maximum five.
  Airborne gold rings give 30 coins each, once per ring per player/hole.
  Beat your best on the same course/hole/chaos/remix for 50 per stroke
  improved. Higher coin prizes also grant more XP. The result screen
  itemizes hole prizes; in-shot coins and achievement prizes pay separately.
  New achievements reward coin-ring collecting, obstacle tricks and powers.

PROGRESS
  Coins, XP, ranks, cosmetics, trophies, unlocked courses, challenge wins,
  tournament scores and time records are saved in browser localStorage.
  Clearing browser data removes progress. Multiplayer sessions use per-tab
  sessionStorage; server match state is private in .local/arena-state.json.
  Browser profiles share local coins, but there is no global account ranking.
  Club upgrades widen the perfect timing window; four club types are always
  available. Free play permits exploration of locked courses.

REALISTIC PRESENTATION
  Textured turf and sand, surrounding hills, detailed foliage, reflective
  water, cloth flags, dimpled balls and a jointed golfer replace the original
  toy-like course presentation. A lower camera follows shots from the fairway.
  Flight uses 9.81 m/s2 gravity and air drag. Club backspin and the landing
  surface affect the first bounce and roll. The smaller cup needs slower,
  more accurate putting. Fantasy obstacles and all original modes remain.

TESTS
  npm test
    Physics, terrain, hazards, obstacles, save/load, purchases, achievements,
    deterministic layouts, shot styles, powers, rewards, and completion of
    all 108 holes plus all 216 Wild/Mayhem variants through legal shots.
  npm run test:browser
    Chrome browser checks, full rounds of all six original modes, all challenges,
    keyboard/touch controls, replay, pausing, local saves and responsive UI.
  npm run test:modes
    Complete Survival, Shuffle and Daily rounds; life limits; queue cancel.
  npm run test:online
    Two independent browser clients, complete Duel, live scores and prizes,
    Mayhem lobby countdown, reload reconnection, forfeit and mobile layout.
  npm run test:wildlife
    Actual mouse/keyboard/touch strength controls, animated bird reaction,
    all six hidden routes, secret ace scoring, saved discoveries and guide.
  npm run test:reactions
    Real shots trigger duck/crab reactions; close-up and auto-return checks.
  Run browser suites one at a time; they share a dedicated Chrome QA profile.
    CHROME_PATH may point to another Chromium executable. The test uses an
    isolated profile in .local and a software GPU for Windows sandbox QA.
    Browser reports/screenshots are written to test-results.
  npm run test:mayhem
    Chaos/remix controls, power consumption and rescue, replay reward safety,
    ace payouts, streak bonuses, multiplayer resets and mobile powers.
  npm run test:limits
    Stroke caps, last-stroke successes, rough penalties, DNF scoring,
    replay safety, multiplayer handoffs, challenge retry and scenery.

STRUCTURE
  src/main.js       Round lifecycle, controls, scoring, timing, replay
  src/physics.js    Fixed 120 Hz ball integration and collisions
  src/courses.js    Themes and 108 course layouts
  src/scene.js      Three.js models, lighting, cameras and animation
  src/natural.js    Terrain, foliage, material textures and golfer model
  src/mayhem.js     Chaos layouts, special shots and obstacle effects
  src/mayhem-scene.js  Animated arcade obstacles and power visuals
  src/ui.js         Menu, HUD and dialog views
  src/extra-modes.js  Daily route, forced clubs and Survival lives
  src/online.js     Session, matchmaking and reconnect client
  src/online-ui.js  Queue, live scores and match result views
  src/wildlife.js   Shared tree collisions, secret routes and reactions
  src/wildlife-scene.js  Hidden props and animated 3D cutscenes
  src/controls.js   Held-shot strength calculation
  server/arena.js   Authoritative shot simulation, queues and match rules
  server/api.js     Authenticated, same-origin multiplayer HTTP API
  src/progress.js   Local saves, equipment, achievements and ranks
  src/audio.js      Procedural music, effects and crowd reactions
  src/style.css    Responsive desktop/mobile layout
  vendor/          Three.js r180 and its MIT license
  scripts/         Dependency-free HTTP server and build

All game art is generated with code. Three.js is copyright its authors and
distributed under the MIT license in vendor/THREE-LICENSE.txt.
