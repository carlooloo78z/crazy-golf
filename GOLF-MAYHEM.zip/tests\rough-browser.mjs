import assert from 'node:assert/strict';
import {browser,sleep} from './cdp.mjs';
const b=await browser();
try{
 await b.send('Emulation.setDeviceMetricsOverride',{width:1000,height:740,deviceScaleFactor:1,mobile:false});
 await b.send('Page.navigate',{url:'http://127.0.0.1:5173/?qa=1'});
 for(let i=0;i<100;i++){if(await b.evaluate('Boolean(window.golfQA)'))break;await sleep(150);}
 await b.click('[data-action="settings"]');await b.evaluate('document.querySelector("#setting-quality").value="low";document.querySelector("#setting-quality").dispatchEvent(new Event("input",{bubbles:true}))');await b.click('[data-action="close"]');
 for(const mode of ['quick','career','time','free','multi','challenge']){
  await b.evaluate(`golfQA.start(${JSON.stringify(mode)},'classic',4,${mode==='multi'?'["Ada","Bo"]':'undefined'},{chaos:'chill'});golfQA.shoot({club:'driver',power:.8,angle:Math.PI/2,loft:24});golfQA.advance()`);
  const s=await b.evaluate('golfQA.state()');assert.ok(s.ball.x>18);assert.equal(s.round.strokes,2);assert.equal(s.round.hazards,0);assert.equal(s.round.roughPenalties,1);assert.equal(s.phase,'ready');assert.equal(await b.evaluate('document.querySelector("#lie-label").textContent'),'ROUGH');assert.equal(await b.evaluate('document.querySelector("#swing").disabled'),false);
  console.log('PASS',mode+': wide shot stays on dark grass, one rough penalty, next swing available');
 }
 await b.evaluate('golfQA.start("quick","classic",0,undefined,{chaos:"chill"});golfQA.shoot({club:"driver",power:.8,angle:Math.PI/2,loft:24});golfQA.advance()');await sleep(1400);await b.screenshot('playable-rough');
 await b.click('[data-action="camera"]');await sleep(700);await b.screenshot('playable-rough-map');
 const result=await b.evaluate(`(async()=>{const {solveShot}=await import('/tests/solver.mjs');for(let i=0;i<8&&!golfQA.state().ball.sunk;i++){golfQA.close();const c=golfQA.candidates();if(!golfQA.shoot(solveShot(c.ball,c.hole,c.time,c.allowed)))throw Error('Recovery shot rejected');golfQA.advance();}return golfQA.state();})()`);assert.ok(result.ball.sunk);assert.equal(result.round.hazards,0);assert.equal(result.result.breakdown.clean,0);console.log('PASS Recovery from dark grass completes the hole and correctly removes the clean-hole reward');
 assert.deepEqual(b.errors,[]);console.log('PASS No browser exceptions or failed resources');
}finally{await b.close();}
